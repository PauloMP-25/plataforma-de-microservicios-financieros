﻿

## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\shared\components\notificacion-centro\notificacion-centro.html

@if (notificacionService.activa(); as notif) {
  <div class="notif-container">
    <div class="notif-card" [ngClass]="'notif-card--' + notif.tipo">
      <button type="button" class="notif-close" (click)="notificacionService.cerrar()">&times;</button>
      <div class="notif-body">
        <div class="notif-icon-wrapper">
          <i class="fa-solid" [ngClass]="'fa-' + notif.icono"></i>
        </div>
        <div class="notif-content">
          <h3>{{ notif.titulo }}</h3>
          <p>{{ notif.mensaje }}</p>
        </div>
      </div>
      <div class="notif-progress-bar" [style.animation-duration.ms]="notif.duracion"></div>
    </div>
  </div>
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\shared\components\notificacion-centro\notificacion-centro.scss

.notif-container {
  position: fixed;
  top: 24px;
  right: 24px;
  z-index: 99999;
  display: flex;
  flex-direction: column;
  gap: 16px;
  align-items: flex-end;
  pointer-events: none; /* Permite hacer clic a través del contenedor hacia la página */
}

.notif-card {
  pointer-events: auto; /* Reactiva los clics solo en la tarjeta */
  position: relative;
  width: 380px;
  max-width: calc(100vw - 48px);
  background: rgba(255, 255, 255, 0.85);
  border: 1px solid rgba(255, 255, 255, 0.5);
  border-radius: 16px;
  padding: 20px;
  box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1),
              0 0 40px -10px rgba(99, 102, 241, 0.15);
  overflow: hidden;
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  animation: notifSlideIn 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;

  :host-context(.theme-dark) &,
  :host-context([data-theme='dark']) & {
    background: rgba(30, 41, 59, 0.9);
    border-color: rgba(255, 255, 255, 0.08);
    box-shadow: 0 15px 30px -10px rgba(0, 0, 0, 0.3),
                0 0 40px -10px rgba(99, 102, 241, 0.15);
  }
}

.notif-close {
  position: absolute;
  top: 16px;
  right: 16px;
  background: none;
  border: none;
  font-size: 20px;
  color: #94a3b8;
  cursor: pointer;
  transition: color 0.2s;
  line-height: 1;

  &:hover {
    color: #475569;
  }

  :host-context(.theme-dark) &:hover {
    color: #cbd5e1;
  }
}

.notif-body {
  display: flex;
  align-items: center;
  gap: 20px;
}

.notif-icon-wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 56px;
  height: 56px;
  border-radius: 18px;
  font-size: 22px;
  flex-shrink: 0;
  animation: notifIconBounce 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275) 0.1s both;
}

.notif-content {
  flex-grow: 1;

  h3 {
    margin: 0 0 4px 0;
    font-size: 17px;
    font-weight: 800;
    color: #0f172a;
    letter-spacing: -0.01em;

    :host-context(.theme-dark) & {
      color: #f8fafc;
    }
  }

  p {
    margin: 0;
    font-size: 13.5px;
    line-height: 1.4;
    color: #475569;

    :host-context(.theme-dark) & {
      color: #94a3b8;
    }
  }
}

.notif-progress-bar {
  position: absolute;
  bottom: 0;
  left: 0;
  height: 4px;
  background: var(--notif-color, #6366f1);
  width: 100%;
  animation: notifProgress linear forwards;
}

.notif-card--success, .notif-card--gasto {
  --notif-color: #10b981;
  box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.1),
              0 0 50px -10px rgba(16, 185, 129, 0.2);
  .notif-icon-wrapper {
    background: rgba(16, 185, 129, 0.1);
    color: #10b981;
  }
}

.notif-card--ingreso {
  --notif-color: #06b6d4;
  box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.1),
              0 0 50px -10px rgba(6, 182, 212, 0.2);
  .notif-icon-wrapper {
    background: rgba(6, 182, 212, 0.1);
    color: #06b6d4;
  }
}

.notif-card--login {
  --notif-color: #6366f1;
  box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.1),
              0 0 50px -10px rgba(99, 102, 241, 0.2);
  .notif-icon-wrapper {
    background: rgba(99, 102, 241, 0.1);
    color: #6366f1;
  }
}

.notif-card--meta {
  --notif-color: #ec4899;
  box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.1),
              0 0 50px -10px rgba(236, 72, 153, 0.2);
  .notif-icon-wrapper {
    background: rgba(236, 72, 153, 0.1);
    color: #ec4899;
  }
}

.notif-card--presupuesto {
  --notif-color: #a855f7;
  box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.1),
              0 0 50px -10px rgba(168, 85, 247, 0.2);
  .notif-icon-wrapper {
    background: rgba(168, 85, 247, 0.1);
    color: #a855f7;
  }
}

.notif-card--guardado {
  --notif-color: #f59e0b;
  box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.1),
              0 0 50px -10px rgba(245, 158, 11, 0.2);
  .notif-icon-wrapper {
    background: rgba(245, 158, 11, 0.1);
    color: #f59e0b;
  }
}

@keyframes notifSlideIn {
  from { opacity: 0; transform: translateX(50px) scale(0.95); }
  to { opacity: 1; transform: translateX(0) scale(1); }
}

@keyframes notifIconBounce {
  0% { transform: scale(0.4); opacity: 0; }
  70% { transform: scale(1.1); }
  100% { transform: scale(1); opacity: 1; }
}

@keyframes notifProgress {
  from { width: 100%; }
  to { width: 0%; }
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\shared\components\notificacion-centro\notificacion-centro.ts

import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NotificacionService } from '../../../core/services/notificacion.service';

@Component({
  selector: 'app-notificacion-centro',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './notificacion-centro.html',
  styleUrl: './notificacion-centro.scss'
})
export class NotificacionCentroComponent {
  protected readonly notificacionService = inject(NotificacionService);
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\shared\components\planes-modal\planes-modal.html

<div class="planes-modal-backdrop" (click)="cerrarModal()">
  <section class="planes-modal" (click)="$event.stopPropagation()">
    <button type="button" class="planes-modal__close" (click)="cerrarModal()" aria-label="Cerrar modal de planes">
      <i class="fa-solid fa-xmark"></i>
    </button>

    <div class="planes-modal__grid">
      <article class="plan-card plan-card--pro">
        <div class="plan-card__tag">PLAN</div>

        <div class="plan-card__header">
          <div>
            <h2>Pro <i class="fa-solid fa-star"></i></h2>
            <p>Todo lo esencial para organizar tus finanzas con IA.</p>
          </div>

          <div class="plan-card__illustration plan-card__illustration--pro">
            <i class="fa-solid fa-chart-line"></i>
          </div>
        </div>

        <div class="plan-card__price">
          <span>S/</span>
          <strong>14.90</strong>
          <small>/mes</small>
        </div>

        <p class="plan-card__cancel">Cancela cuando quieras.</p>
        <hr />
        <h3>Incluye:</h3>

        <ul class="plan-card__features">
          <li><i class="fa-solid fa-brain"></i><span><strong>Asistente IA Financiero</strong><small>Resuelve dudas y recibe orientación financiera.</small></span></li>
          <li><i class="fa-solid fa-bullseye"></i><span><strong>Recomendaciones personalizadas</strong><small>Sugerencias según tus hábitos y objetivos.</small></span></li>
          <li><i class="fa-solid fa-chart-pie"></i><span><strong>Reportes y análisis inteligentes</strong><small>Visualiza tus finanzas de forma clara.</small></span></li>
        </ul>

        <div class="plan-card__queries">
          <h4>Uso mensual de IA</h4>
          <div><span>Módulos de Analítica</span><strong>20 consultas</strong></div>
          <div><span>Auto Clasificar</span><strong>10 consultas</strong></div>
        </div>

        <button type="button" class="plan-card__button plan-card__button--pro" (click)="comprarPlan('PRO')" [disabled]="comprandoPlan()">
          {{ comprandoPlan() ? 'Redirigiendo...' : '✨ Elegir Plan Pro' }}
        </button>

        <p class="plan-card__secure"><i class="fa-solid fa-lock"></i> Pago seguro y protegido</p>
      </article>

      <article class="plan-card plan-card--premium">
        <div class="plan-card__popular"><i class="fa-solid fa-star"></i> MÁS POPULAR</div>
        <div class="plan-card__tag plan-card__tag--premium">PLAN</div>

        <div class="plan-card__header">
          <div>
            <h2>Premium <i class="fa-solid fa-crown"></i></h2>
            <p>Todo lo que necesitas para tomar mejores decisiones y crecer tu dinero.</p>
          </div>

          <div class="plan-card__illustration plan-card__illustration--premium">
            <i class="fa-solid fa-chart-simple"></i>
          </div>
        </div>

        <div class="plan-card__price plan-card__price--premium">
          <span>S/</span>
          <strong>25.90</strong>
          <small>/mes</small>
        </div>

        <p class="plan-card__cancel">Cancela cuando quieras.</p>
        <hr />
        <h3>Incluye todo lo del plan Pro, más:</h3>

        <ul class="plan-card__features">
          <li><i class="fa-solid fa-wand-magic-sparkles"></i><span><strong>Análisis avanzado con IA</strong><small>Insights más profundos para tomar mejores decisiones.</small></span></li>
          <li><i class="fa-solid fa-star"></i><span><strong>Recomendaciones inteligentes avanzadas</strong><small>Sugerencias contextuales y más precisas.</small></span></li>
          <li><i class="fa-solid fa-chart-pie"></i><span><strong>Reportes avanzados limitados</strong><small>Más detalle, más control, mejores resultados.</small></span></li>
          <li><i class="fa-solid fa-shield-halved"></i><span><strong>Prioridad y nuevas funciones</strong><small>Acceso anticipado a nuevas herramientas.</small></span></li>
        </ul>

        <div class="plan-card__queries plan-card__queries--premium">
          <h4>Uso mensual de IA</h4>
          <div><span>Módulos de Analítica</span><strong>50 consultas</strong></div>
          <div><span>Auto Clasificar</span><strong>20 consultas</strong></div>
        </div>

        <button type="button" class="plan-card__button plan-card__button--premium" (click)="comprarPlan('PREMIUM')" [disabled]="comprandoPlan()">
          {{ comprandoPlan() ? 'Redirigiendo...' : '✨ Elegir Plan Premium' }}
        </button>

        <p class="plan-card__secure"><i class="fa-solid fa-lock"></i> Pago seguro y protegido</p>
      </article>
    </div>
  </section>
</div>


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\shared\components\planes-modal\planes-modal.scss

.planes-modal-backdrop {
  position: fixed;
  inset: 0;
  z-index: 9999;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
  background: rgba(15, 23, 42, 0.58);
  backdrop-filter: blur(8px);
}

.planes-modal {
  position: relative;
  width: min(840px, 92vw);
  max-height: 90vh;
  overflow-y: auto;
  border-radius: 20px;
  background: #ffffff;
  box-shadow: 0 30px 90px rgba(15, 23, 42, 0.28);
  padding: 24px;
}

.planes-modal__close {
  position: absolute;
  top: 14px;
  right: 14px;
  z-index: 5;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 42px;
  height: 42px;
  border-radius: 999px;
  border: 1px solid rgba(15, 23, 42, 0.12);
  background: rgba(255, 255, 255, 0.96);
  color: #0f172a;
  font-size: 20px;
  line-height: 1;
  cursor: pointer;
  box-shadow: 0 12px 26px rgba(15, 23, 42, 0.18);
}

.planes-modal__grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 20px;
}

.plan-card {
  position: relative;
  display: flex;
  flex-direction: column;
  border-radius: 20px;
  padding: 20px;
  background: #ffffff;
  border: 1.5px solid #e5d9ff;
  box-shadow: 0 18px 45px rgba(124, 58, 237, 0.08);
  overflow: hidden;
  color: #0f172a;
}

.plan-card--premium {
  border-color: #f4c76b;
  background: linear-gradient(135deg, #fffaf0, #fff7df);
}

.plan-card__popular {
  position: absolute;
  top: 0;
  right: 0;
  background: linear-gradient(135deg, #facc15, #fde68a);
  color: #b45309;
  padding: 8px 16px;
  border-bottom-left-radius: 16px;
  font-weight: 800;
  font-size: 11px;
}

.plan-card__tag {
  display: inline-flex;
  align-self: flex-start;
  padding: 4px 10px;
  border-radius: 999px;
  background: #f0e7ff;
  color: #6d28d9;
  font-weight: 800;
  font-size: 11px;
}

.plan-card__tag--premium {
  background: #fff1bc;
  color: #c56a00;
}

.plan-card__header {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  margin-top: 18px;
}

.plan-card__header h2 {
  margin: 0 0 12px;
  color: #0b1b35;
  font-size: 26px;
}

.plan-card__header p,
.plan-card__cancel,
.plan-card__features small {
  color: #52637a;
}

.plan-card__illustration {
  display: grid;
  place-items: center;
  width: 60px;
  height: 60px;
  border-radius: 50%;
  flex: 0 0 60px;
  font-size: 28px;
}

.plan-card__illustration--pro {
  background: #efe1ff;
  color: #7c3aed;
}

.plan-card__illustration--premium {
  background: #ffedaa;
  color: #df7a00;
}

.plan-card__price {
  display: flex;
  align-items: baseline;
  gap: 4px;
  margin: 28px 0 14px;
  color: #0b1b35;
}

.plan-card__price strong {
  font-size: 42px;
  color: #5b5cf0;
}

.plan-card__price--premium strong {
  color: #ea8a00;
}

.plan-card hr {
  width: 100%;
  border: 0;
  border-top: 1px solid #dce3ee;
  margin: 20px 0;
}

.plan-card h3,
.plan-card__queries h4 {
  margin: 0 0 14px;
  color: #7c3aed;
  font-size: 16px;
}

.plan-card--premium h3,
.plan-card--premium .plan-card__queries h4 {
  color: #df7a00;
}

.plan-card__features {
  display: grid;
  gap: 14px;
  padding: 0;
  margin: 0;
  list-style: none;
}

.plan-card__features li {
  display: flex;
  gap: 12px;
}

.plan-card__features li > i {
  display: grid;
  place-items: center;
  width: 36px;
  height: 36px;
  border-radius: 12px;
  background: #f0e7ff;
  color: #7c3aed;
  flex: 0 0 36px;
}

.plan-card--premium .plan-card__features li > i {
  background: #fff1bc;
  color: #df7a00;
}

.plan-card__features span {
  display: grid;
  gap: 3px;
}

.plan-card__queries {
  display: grid;
  gap: 12px;
  margin-top: 18px;
  border: 1px solid #e0c9ff;
  border-radius: 14px;
  background: #fbf7ff;
  padding: 16px;
}

.plan-card__queries div {
  display: flex;
  justify-content: space-between;
  color: #28364d;
}

.plan-card__queries strong {
  color: #7c3aed;
}

.plan-card__queries--premium {
  border-color: #f4c76b;
  background: #fffaf0;
}

.plan-card__queries--premium strong {
  color: #df7a00;
}

.plan-card__button {
  width: 100%;
  border: 0;
  border-radius: 13px;
  margin-top: 20px;
  padding: 14px;
  color: #fff;
  font-weight: 800;
  cursor: pointer;
  background: linear-gradient(135deg, #a855f7, #7c3aed);
  box-shadow: 0 14px 28px rgba(124, 58, 237, 0.24);
}

.plan-card__button--premium {
  background: linear-gradient(135deg, #f59e0b, #eab308);
  box-shadow: 0 14px 28px rgba(245, 158, 11, 0.24);
}

.plan-card__secure {
  text-align: center;
  color: #91a0b6;
  font-size: 12px;
}

@media (max-width: 760px) {
  .planes-modal__grid {
    grid-template-columns: 1fr;
  }
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\shared\components\planes-modal\planes-modal.ts

import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Output, signal } from '@angular/core';
import { SuscripcionService } from '../../../core/services/suscripcion.service';

@Component({
  selector: 'app-planes-modal',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './planes-modal.html',
  styleUrl: './planes-modal.scss'
})
export class PlanesModalComponent {
  @Output() cerrar = new EventEmitter<void>();

  comprandoPlan = signal(false);

  constructor(private suscripcionService: SuscripcionService) {}

  cerrarModal(): void {
    this.cerrar.emit();
  }

  comprarPlan(plan: 'PRO' | 'PREMIUM'): void {
    if (this.comprandoPlan()) return;
    this.comprandoPlan.set(true);

    this.suscripcionService.crearSesionCheckout(plan).subscribe({
      next: (sesion) => {
        this.comprandoPlan.set(false);
        if (sesion?.urlCheckout) {
          window.location.href = sesion.urlCheckout;
        }
      },
      error: () => {
        this.comprandoPlan.set(false);
      }
    });
  }
}
