﻿Resolving context...
Initializing services and database connection...
Services initialized.
[
  {
    "c.name": "MicroservicioAuditoriaApplication",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/MicroservicioAuditoriaApplication.java",
    "c.docstring": null
  },
  {
    "c.name": "IpBloqueadaException",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/aplicacion/excepciones/IpBloqueadaException.java",
    "c.docstring": null
  },
  {
    "c.name": "ServicioAuditoriaAccesoImpl",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/aplicacion/servicios/ServicioAuditoriaAccesoImpl.java",
    "c.docstring": null
  },
  {
    "c.name": "ServicioAuditoriaTransaccionalImpl",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/aplicacion/servicios/ServicioAuditoriaTransaccionalImpl.java",
    "c.docstring": null
  },
  {
    "c.name": "ServicioRegistroAuditoriaImpl",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/aplicacion/servicios/ServicioRegistroAuditoriaImpl.java",
    "c.docstring": null
  },
  {
    "c.name": "ServicioSeguridadAuditoriaImpl",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/aplicacion/servicios/ServicioSeguridadAuditoriaImpl.java",
    "c.docstring": null
  },
  {
    "c.name": "AuditoriaAcceso",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/dominio/entidades/AuditoriaAcceso.java",
    "c.docstring": null
  },
  {
    "c.name": "AuditoriaTransaccional",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/dominio/entidades/AuditoriaTransaccional.java",
    "c.docstring": null
  },
  {
    "c.name": "ListaNegraIp",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/dominio/entidades/ListaNegraIp.java",
    "c.docstring": null
  },
  {
    "c.name": "RegistroAuditoria",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/dominio/entidades/RegistroAuditoria.java",
    "c.docstring": null
  },
  {
    "c.name": "AuditoriaSpecs",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/dominio/especificaciones/AuditoriaSpecs.java",
    "c.docstring": null
  },
  {
    "c.name": "ConfiguracionRedis",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/infraestructura/configuracion/ConfiguracionRedis.java",
    "c.docstring": null
  },
  {
    "c.name": "PropiedadesSeguridad",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/infraestructura/configuracion/PropiedadesSeguridad.java",
    "c.docstring": null
  },
  {
    "c.name": "ConfiguracionRabbitMQ",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/infraestructura/mensajeria/ConfiguracionRabbitMQ.java",
    "c.docstring": null
  },
  {
    "c.name": "ConsumidorAuditoria",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/infraestructura/mensajeria/ConsumidorAuditoria.java",
    "c.docstring": null
  },
  {
    "c.name": "PublicadorAuditoria",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/infraestructura/mensajeria/PublicadorAuditoria.java",
    "c.docstring": null
  },
  {
    "c.name": "ConfiguracionSeguridad",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/infraestructura/seguridad/ConfiguracionSeguridad.java",
    "c.docstring": null
  },
  {
    "c.name": "TareaLimpiezaAuditoria",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/infraestructura/tareas/TareaLimpiezaAuditoria.java",
    "c.docstring": null
  },
  {
    "c.name": "AuditoriaAccesoControlador",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/presentacion/controladores/AuditoriaAccesoControlador.java",
    "c.docstring": null
  },
  {
    "c.name": "AuditoriaControlador",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/presentacion/controladores/AuditoriaControlador.java",
    "c.docstring": null
  },
  {
    "c.name": "AuditoriaTransaccionalControlador",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/presentacion/controladores/AuditoriaTransaccionalControlador.java",
    "c.docstring": null
  },
  {
    "c.name": "SeguridadControlador",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/presentacion/controladores/SeguridadControlador.java",
    "c.docstring": null
  },
  {
    "c.name": "ManejadorGlobalExcepciones",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-auditoria/src/main/
java/com/auditoria/presentacion/manejadores/ManejadorGlobalExcepciones.java",
    "c.docstring": null
  }
]
