﻿Resolving context...
Initializing services and database connection...
Services initialized.
[
  {
    "c.name": "BaseLukaClient",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/clientes/bas
e_client.py",
    "c.docstring": null
  },
  {
    "c.name": "ClienteContexto",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/clientes/cli
ente_contexto.py",
    "c.docstring": null
  },
  {
    "c.name": "ClienteNucleoFinanciero",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/clientes/cli
ente_financiero.py",
    "c.docstring": null
  },
  {
    "c.name": "ClienteAuditoria",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/clientes/cli
ente_financiero.py",
    "c.docstring": null
  },
  {
    "c.name": "ClienteFinanciero",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/clientes/luk
a_clients.py",
    "c.docstring": null
  },
  {
    "c.name": "ClientePerfil",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/clientes/luk
a_clients.py",
    "c.docstring": null
  },
  {
    "c.name": "Configuracion",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/configuracio
n.py",
    "c.docstring": null
  },
  {
    "c.name": "RoutingKeys",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/libreria_com
un/configuracion/routing_keys.py",
    "c.docstring": null
  },
  {
    "c.name": "Settings",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/libreria_com
un/configuracion/settings.py",
    "c.docstring": null
  },
  {
    "c.name": "LukaException",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/libreria_com
un/excepciones/base.py",
    "c.docstring": null
  },
  {
    "c.name": "RecursoNoEncontrado",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/libreria_com
un/excepciones/base.py",
    "c.docstring": null
  },
  {
    "c.name": "AccesoDenegado",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/libreria_com
un/excepciones/base.py",
    "c.docstring": null
  },
  {
    "c.name": "NoAutorizado",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/libreria_com
un/excepciones/base.py",
    "c.docstring": null
  },
  {
    "c.name": "ValidacionError",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/libreria_com
un/excepciones/base.py",
    "c.docstring": null
  },
  {
    "c.name": "ServicioExternoError",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/libreria_com
un/excepciones/base.py",
    "c.docstring": null
  },
  {
    "c.name": "ErrorInterno",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/libreria_com
un/excepciones/base.py",
    "c.docstring": null
  },
  {
    "c.name": "ContextoEstrategicoIADTO",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/libreria_com
un/modelos/contexto.py",
    "c.docstring": null
  },
  {
    "c.name": "BaseDTO",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/libreria_com
un/modelos/eventos.py",
    "c.docstring": null
  },
  {
    "c.name": "EventoAuditoriaDTO",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/libreria_com
un/modelos/eventos.py",
    "c.docstring": null
  },
  {
    "c.name": "EventoAccesoDTO",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/libreria_com
un/modelos/eventos.py",
    "c.docstring": null
  },
  {
    "c.name": "EventoTransaccionalDTO",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/libreria_com
un/modelos/eventos.py",
    "c.docstring": null
  },
  {
    "c.name": "PaginacionDTO",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/libreria_com
un/respuesta/resultado_api.py",
    "c.docstring": null
  },
  {
    "c.name": "ResultadoApi",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/libreria_com
un/respuesta/resultado_api.py",
    "c.docstring": null
  },
  {
    "c.name": "TraceabilityMiddleware",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/libreria_com
un/seguridad/middleware.py",
    "c.docstring": null
  },
  {
    "c.name": "ConsumidorIA",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/mensajeria/c
onsumidor_ia.py",
    "c.docstring": null
  },
  {
    "c.name": "EscuchadorCambioDatosIA",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/mensajeria/e
scuchador_cambio_datos_ia.py",
    "c.docstring": null
  },
  {
    "c.name": "ContextoEstrategicoIA",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/mensajeria/e
scuchador_sincronizacion_ia.py",
    "c.docstring": null
  },
  {
    "c.name": "EscuchadorSincronizacionIA",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/mensajeria/e
scuchador_sincronizacion_ia.py",
    "c.docstring": null
  },
  {
    "c.name": "OutboxScheduler",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/mensajeria/o
utbox_scheduler.py",
    "c.docstring": null
  },
  {
    "c.name": "PublicadorAuditoria",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/mensajeria/p
ublicador_auditoria.py",
    "c.docstring": null
  },
  {
    "c.name": "PublicadorMensajeria",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/mensajeria/p
ublicador_mensajeria.py",
    "c.docstring": null
  },
  {
    "c.name": "WorkerIA",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/mensajeria/w
orker_ia.py",
    "c.docstring": null
  },
  {
    "c.name": "PeticionClasificar",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "EstadoCoach",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "SolicitudClasificacionDTO",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "EventoAccesoDTO",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "EjercicioEntrenamiento",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "RespuestaClasificacionDTO",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "ConsejoEstructuradoAutoClasificacion",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "ConsejoEstructuradoEvolucion",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "PeticionBase",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "LimiteGasto",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "ConsejoEstructuradoEstilo",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "PeticionComparacionDTO",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "MetadataGrafico",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "FiltroDeFecha",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "TipoMovimiento",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "NombreModulo",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "EstadoEvento",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "NivelRiesgo",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "TipoGrafico",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "ConsejoEstructuradoHabitos",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "ConsejoEstructuradoReto",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "ConsejoEstructuradoHormiga",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "RecetaCategoria",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "MetaAhorro",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "EventoAuditoriaDTO",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "ConsejoEstructuradoSimularMeta",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "ConsejoEstructuradoPredecir",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "PeticionConFiltroFecha",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "PeticionSimularEscenario",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "ResumenMensual",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "ConsejoEstructuradoReporte",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "PuntoGrafico",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "PerfilUsuario",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "RespuestaModulo",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "ConsejoEstructuradoEspejo",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "PeticionSimularMeta",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "KpiWidget",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "ConsejoEstructuradoEntrenamiento",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "InsightAnalitico",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "EventoTransaccionalDTO",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "TransaccionParaClasificar",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/modelos/esqu
emas.py",
    "c.docstring": null
  },
  {
    "c.name": "IaRetoAhorro",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/persistencia
/postgres/modelos_db.py",
    "c.docstring": null
  },
  {
    "c.name": "OutboxEvento",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/persistencia
/postgres/modelos_db.py",
    "c.docstring": null
  },
  {
    "c.name": "IaHistorialCoaching",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/persistencia
/postgres/modelos_db.py",
    "c.docstring": null
  },
  {
    "c.name": "IaRutinaMensual",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/persistencia
/postgres/modelos_db.py",
    "c.docstring": null
  },
  {
    "c.name": "EstadoOutbox",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/persistencia
/postgres/modelos_db.py",
    "c.docstring": null
  },
  {
    "c.name": "RepositorioHistorialCoaching",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/persistencia
/postgres/repositorio_historial.py",
    "c.docstring": null
  },
  {
    "c.name": "RepositorioRutinas",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/persistencia
/postgres/repositorio_rutinas.py",
    "c.docstring": null
  },
  {
    "c.name": "CacheRedis",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/persistencia
/redis/cache_redis.py",
    "c.docstring": null
  },
  {
    "c.name": "ResumenKPIs",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/routers/dash
board.py",
    "c.docstring": null
  },
  {
    "c.name": "RespuestaGraficos",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/routers/dash
board.py",
    "c.docstring": null
  },
  {
    "c.name": "CategoriaDistribucion",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/routers/dash
board.py",
    "c.docstring": null
  },
  {
    "c.name": "RespuestaKPIs",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/routers/dash
board.py",
    "c.docstring": null
  },
  {
    "c.name": "CashflowPoint",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/routers/dash
board.py",
    "c.docstring": null
  },
  {
    "c.name": "BaseAnalisisService",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/servicios/co
re/base_analisis.py",
    "c.docstring": null
  },
  {
    "c.name": "FabricaModulosAnalisis",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/servicios/co
re/fabrica_modulos.py",
    "c.docstring": null
  },
  {
    "c.name": "ServicioAnalisis",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/servicios/co
re/servicio_analisis.py",
    "c.docstring": null
  },
  {
    "c.name": "AlertaCostosIA",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/servicios/ia
/alerta_costos.py",
    "c.docstring": null
  },
  {
    "c.name": "ClasificadorIAService",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/servicios/ia
/clasificador_ia.py",
    "c.docstring": null
  },
  {
    "c.name": "CoachIA",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/servicios/ia
/coach_ia.py",
    "c.docstring": null
  },
  {
    "c.name": "GestorFallbacks",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/servicios/ia
/fallbacks/gestor_fallbacks.py",
    "c.docstring": null
  },
  {
    "c.name": "AnalisisEstiloVidaService",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/servicios/mo
dulos/analisis_estilo_de_vida.py",
    "c.docstring": null
  },
  {
    "c.name": "AutoClasificacionService",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/servicios/mo
dulos/auto_clasificacion.py",
    "c.docstring": null
  },
  {
    "c.name": "ComprobadorEvolucion",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/servicios/mo
dulos/comprobador_evolucion.py",
    "c.docstring": null
  },
  {
    "c.name": "DeteccionGastosHormigaService",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/servicios/mo
dulos/deteccion_gastos_hormiga.py",
    "c.docstring": null
  },
  {
    "c.name": "EspejoTiempoService",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/servicios/mo
dulos/espejo_tiempo.py",
    "c.docstring": null
  },
  {
    "c.name": "HabitosFinancierosService",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/servicios/mo
dulos/habitos_financieros.py",
    "c.docstring": null
  },
  {
    "c.name": "PrediccionGastosService",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/servicios/mo
dulos/predecir_gastos.py",
    "c.docstring": null
  },
  {
    "c.name": "ReporteCompletoService",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/servicios/mo
dulos/reporte_completo.py",
    "c.docstring": null
  },
  {
    "c.name": "RetoAhorroDinamicoService",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/servicios/mo
dulos/reto_ahorro_dinamico.py",
    "c.docstring": null
  },
  {
    "c.name": "SimularMetaService",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/servicios/mo
dulos/simular_meta.py",
    "c.docstring": null
  },
  {
    "c.name": "ZonaEntrenamiento",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/servicios/mo
dulos/zona_entrenamiento.py",
    "c.docstring": null
  },
  {
    "c.name": "HistorialInsuficienteError",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/utilidades/e
xcepciones.py",
    "c.docstring": null
  },
  {
    "c.name": "LimiteDiarioExcedidoError",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/utilidades/e
xcepciones.py",
    "c.docstring": null
  },
  {
    "c.name": "ContratoDatosError",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/utilidades/e
xcepciones.py",
    "c.docstring": null
  },
  {
    "c.name": "BrokerComunicacionError",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/utilidades/e
xcepciones.py",
    "c.docstring": null
  },
  {
    "c.name": "MapperContextoIA",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/app/utilidades/m
appers.py",
    "c.docstring": null
  },
  {
    "c.name": "HealthCheckFilter",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/main.py",
    "c.docstring": null
  },
  {
    "c.name": "TestConsejoEstructurado",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/tests/test_migra
cion_gasto_hormiga.py",
    "c.docstring": null
  },
  {
    "c.name": "TestCoachIAStructuredOutputs",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/tests/test_migra
cion_gasto_hormiga.py",
    "c.docstring": null
  },
  {
    "c.name": "TestRespuestaModuloConsejoUnion",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/tests/test_migra
cion_gasto_hormiga.py",
    "c.docstring": null
  },
  {
    "c.name": "TestIaHistorialCoachingModel",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/tests/test_migra
cion_gasto_hormiga.py",
    "c.docstring": null
  },
  {
    "c.name": "TestRepositorioHistorialCoaching",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/tests/test_migra
cion_gasto_hormiga.py",
    "c.docstring": null
  },
  {
    "c.name": "TestOrquestadorConMemoria",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/tests/test_migra
cion_gasto_hormiga.py",
    "c.docstring": null
  },
  {
    "c.name": "TestPromptConMemoria",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-ia/tests/test_migra
cion_gasto_hormiga.py",
    "c.docstring": null
  }
]
