INSTRUCCIONES-PROMPTS.md

A partir de ahora, se seguirán estrictamente estas reglas al generar cualquier prompt para Antigravity:

---

## 1. Corto y directo (OBLIGATORIO)
El prompt debe ir directo al grano y tener un máximo de 150 palabras.

El prompt debe describir SOLO una acción principal.

---

## 2. Archivos exactos (REGLA CRÍTICA)
Solo se deben incluir los archivos específicos involucrados en la tarea.

❌ Prohibido:
- Referenciar todo el proyecto
- Explorar archivos no listados
- Abrir archivos adicionales sin autorización
- Hacer auditoría global del sistema

---

## 3. Alcance de la tarea (OBLIGATORIO)

Cada prompt debe contener:

✔ Acción exacta a realizar  
✔ Punto específico del código afectado  
✔ Restricción explícita de NO expansión  

❌ Prohibido:
- Múltiples funcionalidades en una sola tarea
- “Sincronizar todo el módulo”
- “Revisar consistencia general”

---

## 4. Patrón exacto del proyecto LUKA (OBLIGATORIO)

### Nombres en español:
- DTOs:
  - Solicitud...
  - Respuesta...

Ej:
SolicitudLogin, RespuestaAutenticacion

### Backend:
- Controladores: ...Controlador
- Servicios: ...Servicio / ...ServicioImpl

### Frontend:
- core: servicios y modelos
- features: lógica de módulos
- shared: componentes reutilizables
- layout: estructura visual

### Arquitectura:
- aplicacion
- dominio
- infraestructura
- presentacion

---

## 5. Integración Frontend-Backend (SI APLICA)

- Incluir endpoint EXACTO versionado:
  ${environment.gatewayUrl}/api/v1/...

- Incluir servicio Angular involucrado:
  (ej: AuthService, ClientePerfilService)

---

## 6. CONTROL DE ALCANCE (REGLA MÁS IMPORTANTE)

El agente debe operar como “modo quirúrgico”:

✔ Trabajar SOLO dentro de los archivos indicados  
✔ Modificar SOLO la parte necesaria del código  
✔ NO explorar el repositorio  
✔ NO analizar arquitectura global  
✔ NO buscar alternativas de implementación  
✔ NO refactorizar código existente  

El agente NO es un auditor del sistema.

---

## 7. CONTROL DE EXPANSIÓN (NUEVO - CLAVE)

Si la tarea puede interpretarse de múltiples formas:

→ elegir la solución MÁS mínima posible  
→ evitar cualquier implementación adicional  
→ evitar validaciones innecesarias  
→ evitar lectura de archivos no mencionados  

---

## 8. YA IMPLEMENTADO (OPTIMIZACIÓN DE TOKENS)

Si la funcionalidad ya existe correctamente:

→ responder únicamente: "YA IMPLEMENTADO"  
→ NO realizar análisis adicional  
→ NO abrir archivos  
→ NO verificar backend  

---

## 9. CIERRE OBLIGATORIO
El prompt debe terminar siempre con la frase exacta:

"No expliques, solo implementa"