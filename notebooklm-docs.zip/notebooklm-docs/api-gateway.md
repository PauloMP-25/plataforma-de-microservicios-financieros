﻿Resolving context...
Initializing services and database connection...
Services initialized.
[
  {
    "c.name": "ApiGatewayApplication",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/api-gateway/src/main/java/com/fin
anciero/saas/gateway/ApiGatewayApplication.java",
    "c.docstring": null
  },
  {
    "c.name": "ConfiguracionRedis",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/api-gateway/src/main/java/com/fin
anciero/saas/gateway/configuracion/ConfiguracionRedis.java",
    "c.docstring": null
  },
  {
    "c.name": "ConfiguracionSeguridadGateway",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/api-gateway/src/main/java/com/fin
anciero/saas/gateway/configuracion/ConfiguracionSeguridadGateway.java",
    "c.docstring": null
  },
  {
    "c.name": "ConfiguracionWebClient",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/api-gateway/src/main/java/com/fin
anciero/saas/gateway/configuracion/ConfiguracionWebClient.java",
    "c.docstring": null
  },
  {
    "c.name": "ControladorDashboardBFF",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/api-gateway/src/main/java/com/fin
anciero/saas/gateway/controladores/ControladorDashboardBFF.java",
    "c.docstring": null
  },
  {
    "c.name": "FallbackController",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/api-gateway/src/main/java/com/fin
anciero/saas/gateway/controladores/FallbackController.java",
    "c.docstring": null
  },
  {
    "c.name": "FiltroBloqueoIp",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/api-gateway/src/main/java/com/fin
anciero/saas/gateway/filtros/FiltroBloqueoIp.java",
    "c.docstring": null
  },
  {
    "c.name": "FiltroCuotaIA",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/api-gateway/src/main/java/com/fin
anciero/saas/gateway/filtros/FiltroCuotaIA.java",
    "c.docstring": null
  },
  {
    "c.name": "FiltroTrazabilidadGlobal",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/api-gateway/src/main/java/com/fin
anciero/saas/gateway/filtros/FiltroTrazabilidadGlobal.java",
    "c.docstring": null
  },
  {
    "c.name": "FiltroJwtGlobal",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/api-gateway/src/main/java/com/fin
anciero/saas/gateway/seguridad/FiltroJwtGlobal.java",
    "c.docstring": null
  },
  {
    "c.name": "SeguridadClient",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/api-gateway/src/main/java/com/fin
anciero/saas/gateway/seguridad/SeguridadClient.java",
    "c.docstring": null
  },
  {
    "c.name": "ServicioJwtGateway",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/api-gateway/src/main/java/com/fin
anciero/saas/gateway/seguridad/ServicioJwtGateway.java",
    "c.docstring": null
  }
]
