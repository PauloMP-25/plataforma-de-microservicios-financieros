﻿

## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\layout\header\header\header.html

<header class="luka-header" (click)="closeAll()">

  <!-- TITULO + BREADCRUMB -->
  <div class="header-left">
    <button class="mobile-menu-btn" (click)="toggleSidebarMobile()" title="Menú">
      <i class="fa-solid fa-bars"></i>
    </button>

    <h1 class="page-title">{{ pageTitle }}</h1>

    <nav class="breadcrumb" *ngIf="breadcrumbs.length > 0">
      <ng-container *ngFor="let crumb of breadcrumbs; let last = last">

        <a *ngIf="!last" [routerLink]="crumb.route" class="breadcrumb-link">
          {{ crumb.label }}
        </a>

        <span *ngIf="last" class="breadcrumb-current">
          {{ crumb.label }}
        </span>

        <span *ngIf="!last" class="breadcrumb-sep">/</span>

      </ng-container>
    </nav>

  </div>


  <!-- DERECHA — RESUMEN + PERFIL -->
  <div class="header-right" (click)="$event.stopPropagation()">

    <div class="header-pills" aria-label="Resumen mensual">
      <article class="metric-pill metric-pill--income">
        <span class="metric-icon"><i class="fa-solid fa-arrow-trend-up"></i></span>
        <div class="metric-copy">
          <span class="metric-label">Ingresos</span>
          <strong class="metric-value">{{ formatSoles(totalIngresosMes) }}</strong>
        </div>
      </article>

      <article class="metric-pill metric-pill--expense">
        <span class="metric-icon"><i class="fa-solid fa-arrow-trend-down"></i></span>
        <div class="metric-copy">
          <span class="metric-label">Gastos</span>
          <strong class="metric-value">{{ formatSoles(totalGastosMes) }}</strong>
        </div>
      </article>

      <article class="metric-pill metric-pill--balance metric-pill--desktop-only">
        <span class="metric-icon"><i class="fa-solid fa-scale-balanced"></i></span>
        <div class="metric-copy">
          <span class="metric-label">Balance</span>
          <strong class="metric-value">{{ formatSoles(balanceActual) }}</strong>
        </div>
      </article>

      <article class="metric-pill metric-pill--streak" title="Racha de transacciones: días consecutivos registrando movimientos">
        <span class="metric-icon"><i class="fa-solid fa-fire"></i></span>
        <div class="metric-copy">
          <span class="metric-label">Racha</span>
          <strong class="metric-value">{{ rachaDias() }} {{ rachaDias() === 1 ? 'día' : 'días' }}</strong>
        </div>
      </article>

      <!-- PILLS DE CUOTAS DE IA -->
      <article class="metric-pill metric-pill--ia-analitica" title="Consultas de analítica de IA restantes">
        <span class="metric-icon"><i class="fa-solid fa-brain"></i></span>
        <div class="metric-copy">
          <span class="metric-label">Consultas IA</span>
          <strong class="metric-value">{{ iaService.consultasRestantes() }}/{{ iaService.consultasMaximas() }}</strong>
        </div>
      </article>

      <article class="metric-pill metric-pill--ia-clasificar" title="Autoclasificaciones de IA restantes">
        <span class="metric-icon"><i class="fa-solid fa-tags"></i></span>
        <div class="metric-copy">
          <span class="metric-label">Autoclasificar</span>
          <strong class="metric-value">{{ iaService.clasificacionesRestantes() }}/{{ iaService.clasificacionesMaximas() }}</strong>
        </div>
      </article>
    </div>

    <!-- ═════ PERFIL ═════ -->
    <div class="header-action">

      <button class="avatar-btn" (click)="toggleUserMenu()">

        <div class="avatar-letter">
          {{ auth.usuario()?.nombreUsuario?.charAt(0)?.toUpperCase() ?? 'U' }}
        </div>

        <div class="avatar-meta">
          <span class="avatar-name">
            {{ auth.usuario()?.nombreUsuario ?? 'Usuario' }}
          </span>

          <span class="avatar-plan">
            <i class="fa-solid fa-leaf"></i>
            {{ auth.esPremium() ? 'Premium' : (auth.esPro() ? 'Pro' : 'Free') }}
          </span>
        </div>

        <i class="fa-solid fa-chevron-down avatar-chevron"></i>

      </button>


      <div class="dropdown-panel user-panel" *ngIf="showUserMenu">


        <!-- HERO -->
        <div class="user-panel-hero">

          <div class="hero-avatar">
            {{ auth.usuario()?.nombreUsuario?.charAt(0)?.toUpperCase() ?? 'U' }}
          </div>

          <div class="hero-info">

            <p class="hero-name">
              {{ auth.usuario()?.nombreUsuario ?? 'Usuario' }}
            </p>

            <span class="plan-badge">
              <i class="fa-solid fa-leaf"></i>
              {{ auth.esPremium() ? 'Premium' : (auth.esPro() ? 'Pro' : 'Free') }}
            </span>

          </div>

        </div>


        <!-- MENU -->
        <ul class="user-panel-menu">

          <li>
            <a routerLink="/perfil" class="menu-item">
              <i class="fa-solid fa-circle-user menu-item-icon"></i>
              <div>
                <p>Mi Perfil</p>
                <small>Editar datos personales</small>
              </div>
            </a>
          </li>

          <li>
            <a routerLink="/suscripcion/luka" class="menu-item">
              <i class="fa-solid fa-crown menu-item-icon" style="color: #f59e0b;"></i>
              <div>
                <p>Membresía</p>
                <small>Gestionar plan Luka</small>
              </div>
            </a>
          </li>

          <li>
            <a routerLink="/perfil/configuracion" class="menu-item">
              <i class="fa-solid fa-gear menu-item-icon"></i>
              <div>
                <p>Configuración</p>
                <small>Preferencias y seguridad</small>
              </div>
            </a>
          </li>

          <li>
            <a routerLink="/ayuda" class="menu-item">
              <i class="fa-solid fa-circle-question menu-item-icon"></i>
              <div>
                <p>Ayuda</p>
                <small>Tutoriales y soporte</small>
              </div>
            </a>
          </li>

          <li class="menu-divider"></li>

          <li>
            <button class="menu-item menu-item--danger" (click)="logout()">
              <i class="fa-solid fa-right-from-bracket menu-item-icon"></i>
              <div>
                <p>Cerrar sesión</p>
                <small>{{ auth.usuario()?.nombreUsuario }}</small>
              </div>
            </button>
          </li>

        </ul>

      </div>

    </div>


  </div>

</header>


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\layout\header\header\header.scss

// ══════════════════════════════════════════════
// VARIABLES & CONFIG

$header-height: 78px;
$primary-color: var(--accent-primary); // Tema global
$danger-color: var(--color-danger);
$text-main: var(--text-primary);
$text-muted: var(--text-secondary);
$bg-white: var(--bg-card);
$border-color: var(--border-color);
$shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
$shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
$transition: all 0.2s ease-in-out;

// ══════════════════════════════════════════════
// HEADER PRINCIPAL

.luka-header {
  height: $header-height;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 0 1.35rem;
  background: $bg-white;
  border-bottom: 1px solid color-mix(in srgb, $border-color 75%, #ffffff 25%);
  box-shadow: 0 6px 18px rgba(15, 23, 42, 0.06);
  position: sticky;
  top: 0;
  z-index: 1000;

  // Izquierda: Título y Breadcrumb
  .header-left {
    display: flex;
    flex-direction: column;
    min-width: 0;
    flex: 1;

    .page-title {
      font-size: 1.42rem;
      font-weight: 900;
      letter-spacing: 0.01em;
      color: $text-main;
      margin: 0;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .breadcrumb {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      font-size: 0.96rem;
      font-weight: 700;
      margin-top: 4px;

      &-link {
        color: $primary-color;
        text-decoration: none;
        &:hover { text-decoration: underline; }
      }

      &-current {
        color: color-mix(in srgb, $text-main 78%, $text-muted 22%);
        font-weight: 800;
      }
      &-sep { color: #d1d5db; }
    }
  }

  // Derecha: Acciones
  .header-right {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    flex-shrink: 0;
  }
}

.header-pills {
  display: flex;
  align-items: center;
  gap: 0.4rem;
}

.metric-pill {
  display: inline-flex;
  align-items: center;
  gap: 0.35rem;
  border-radius: 999px;
  border: 1px solid transparent;
  padding: 4px 8px;
  min-width: 100px;
  box-shadow: 0 4px 12px rgba(15, 23, 42, 0.08);

  .metric-icon {
    width: 22px;
    height: 22px;
    border-radius: 999px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 0.65rem;
    flex-shrink: 0;
  }

  .metric-copy {
    min-width: 0;
    display: flex;
    flex-direction: column;
    line-height: 1.1;
  }

  .metric-label {
    font-size: 0.68rem;
    font-weight: 800;
    letter-spacing: 0.01em;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .metric-value {
    font-size: 0.82rem;
    font-weight: 900;
    white-space: nowrap;
  }
}

.metric-pill--income {
  background: linear-gradient(120deg, rgba(16, 185, 129, 0.16) 0%, rgba(34, 197, 94, 0.08) 100%);
  border-color: rgba(16, 185, 129, 0.2);

  .metric-icon {
    background: rgba(16, 185, 129, 0.18);
    color: #047857;
  }

  .metric-label,
  .metric-value {
    color: #065f46;
  }
}

.metric-pill--expense {
  background: linear-gradient(120deg, rgba(244, 63, 94, 0.15) 0%, rgba(251, 113, 133, 0.08) 100%);
  border-color: rgba(244, 63, 94, 0.22);

  .metric-icon {
    background: rgba(244, 63, 94, 0.18);
    color: #be123c;
  }

  .metric-label,
  .metric-value {
    color: #9f1239;
  }
}

.metric-pill--balance {
  background: linear-gradient(120deg, rgba(59, 130, 246, 0.16) 0%, rgba(99, 102, 241, 0.1) 100%);
  border-color: rgba(79, 70, 229, 0.22);

  .metric-icon {
    background: rgba(79, 70, 229, 0.18);
    color: #3730a3;
  }

  .metric-label,
  .metric-value {
    color: #312e81;
  }
}

.metric-pill--streak {
  background: linear-gradient(120deg, rgba(249, 115, 22, 0.15) 0%, rgba(239, 68, 68, 0.08) 100%);
  border-color: rgba(249, 115, 22, 0.22);

  .metric-icon {
    background: rgba(249, 115, 22, 0.18);
    color: #c2410c;
  }

  .metric-label,
  .metric-value {
    color: #9a3412;
  }
}

.metric-pill--ia-analitica {
  background: linear-gradient(120deg, rgba(139, 92, 246, 0.15) 0%, rgba(219, 39, 119, 0.08) 100%);
  border-color: rgba(139, 92, 246, 0.22);

  .metric-icon {
    background: rgba(139, 92, 246, 0.18);
    color: #6d28d9;
  }

  .metric-label,
  .metric-value {
    color: #5b21b6;
  }
}

.metric-pill--ia-clasificar {
  background: linear-gradient(120deg, rgba(20, 184, 166, 0.15) 0%, rgba(16, 185, 129, 0.08) 100%);
  border-color: rgba(20, 184, 166, 0.22);

  .metric-icon {
    background: rgba(20, 184, 166, 0.18);
    color: #0f766e;
  }

  .metric-label,
  .metric-value {
    color: #115e59;
  }
}

/* ── Dark mode: pills fosforescentes/neón ── */
body.theme-dark {
  .metric-pill {
    border-width: 1.5px;
    background: color-mix(in srgb, var(--bg-card) 86%, #0b1220 14%);
    box-shadow:
      0 0 0 1px rgba(255, 255, 255, 0.03) inset,
      0 0 18px rgba(56, 189, 248, 0.18);

    .metric-label {
      color: #e2e8f0;
      text-shadow: none;
    }

    .metric-value {
      color: #f8fafc;
      font-weight: 900;
      text-shadow: none;
    }
  }

  .metric-pill--income {
    background: linear-gradient(120deg, rgba(16, 185, 129, 0.32) 0%, rgba(34, 197, 94, 0.22) 100%);
    border-color: rgba(52, 211, 153, 0.55);
    box-shadow:
      0 0 20px rgba(16, 185, 129, 0.35),
      0 0 40px rgba(16, 185, 129, 0.16);

    .metric-icon {
      background: rgba(16, 185, 129, 0.28);
      color: #86efac;
    }

    .metric-label,
    .metric-value {
      color: #ecfdf5;
      text-shadow: 0 0 8px rgba(16, 185, 129, 0.25);
    }
  }

  .metric-pill--expense {
    background: linear-gradient(120deg, rgba(244, 63, 94, 0.28) 0%, rgba(251, 113, 133, 0.2) 100%);
    border-color: rgba(251, 113, 133, 0.52);
    box-shadow:
      0 0 20px rgba(244, 63, 94, 0.34),
      0 0 38px rgba(244, 63, 94, 0.14);

    .metric-icon {
      background: rgba(244, 63, 94, 0.26);
      color: #fecdd3;
    }

    .metric-label,
    .metric-value {
      color: #fff1f2;
      text-shadow: 0 0 8px rgba(244, 63, 94, 0.25);
    }
  }

  .metric-pill--balance {
    background: linear-gradient(120deg, rgba(56, 189, 248, 0.26) 0%, rgba(129, 140, 248, 0.24) 100%);
    border-color: rgba(125, 211, 252, 0.55);
    box-shadow:
      0 0 20px rgba(56, 189, 248, 0.34),
      0 0 42px rgba(99, 102, 241, 0.18);

    .metric-icon {
      background: rgba(56, 189, 248, 0.25);
      color: #bae6fd;
    }

    .metric-label,
    .metric-value {
      color: #eff6ff;
      text-shadow: 0 0 8px rgba(59, 130, 246, 0.24);
    }
  }

  .metric-pill--streak {
    background: linear-gradient(120deg, rgba(249, 115, 22, 0.28) 0%, rgba(239, 68, 68, 0.18) 100%);
    border-color: rgba(251, 146, 60, 0.52);
    box-shadow:
      0 0 20px rgba(249, 115, 22, 0.34),
      0 0 38px rgba(249, 115, 22, 0.14);

    .metric-icon {
      background: rgba(249, 115, 22, 0.26);
      color: #ffedd5;
    }

    .metric-label,
    .metric-value {
      color: #fff7ed;
      text-shadow: 0 0 8px rgba(249, 115, 22, 0.25);
    }
  }

  .metric-pill--ia-analitica {
    background: linear-gradient(120deg, rgba(139, 92, 246, 0.28) 0%, rgba(219, 39, 119, 0.18) 100%);
    border-color: rgba(167, 139, 250, 0.52);
    box-shadow:
      0 0 20px rgba(139, 92, 246, 0.34),
      0 0 38px rgba(139, 92, 246, 0.14);

    .metric-icon {
      background: rgba(139, 92, 246, 0.26);
      color: #ddd6fe;
    }

    .metric-label,
    .metric-value {
      color: #f5f3ff;
      text-shadow: 0 0 8px rgba(139, 92, 246, 0.25);
    }
  }

  .metric-pill--ia-clasificar {
    background: linear-gradient(120deg, rgba(20, 184, 166, 0.28) 0%, rgba(16, 185, 129, 0.18) 100%);
    border-color: rgba(45, 212, 191, 0.52);
    box-shadow:
      0 0 20px rgba(20, 184, 166, 0.34),
      0 0 38px rgba(20, 184, 166, 0.14);

    .metric-icon {
      background: rgba(20, 184, 166, 0.26);
      color: #ccfbf1;
    }

    .metric-label,
    .metric-value {
      color: #f0fdfa;
      text-shadow: 0 0 8px rgba(20, 184, 166, 0.25);
    }
  }
}

.health-badge {
  display: inline-flex;
  align-items: center;
  gap: 0.4rem;
  padding: 6px 10px;
  border-radius: 999px;
  font-size: 0.72rem;
  font-weight: 700;
  border: 1px solid transparent;
  white-space: nowrap;

  i {
    font-size: 0.5rem;
  }
}

.health-badge--good {
  color: #166534;
  background: rgba(34, 197, 94, 0.14);
  border-color: rgba(22, 163, 74, 0.24);
}

.health-badge--warn {
  color: #92400e;
  background: rgba(245, 158, 11, 0.16);
  border-color: rgba(217, 119, 6, 0.24);
}

.health-badge--bad {
  color: #991b1b;
  background: rgba(239, 68, 68, 0.14);
  border-color: rgba(220, 38, 38, 0.24);
}

.mobile-menu-btn {
  display: none;
  width: 38px;
  height: 38px;
  border-radius: 10px;
  border: 1px solid $border-color;
  background: var(--bg-surface-soft);
  color: $text-main;
  align-items: center;
  justify-content: center;
  font-size: 1rem;
  cursor: pointer;
  transition: $transition;

  &:hover {
    background: color-mix(in srgb, var(--c-primary) 12%, var(--bg-surface-soft));
    color: var(--c-primary);
  }
}

// ══════════════════════════════════════════════
// ACCIONES Y DROPDOWNS
// ══════════════════════════════════════════════
.header-action {
  position: relative; // Para posicionar los paneles

  .icon-btn {
    background: transparent;
    border: none;
    font-size: 1.2rem;
    color: $text-muted;
    cursor: pointer;
    padding: 8px;
    border-radius: 50%;
    transition: $transition;
    position: relative;

    &:hover {
      background: var(--bg-surface-soft);
      color: $primary-color;
    }

    .badge-dot {
      position: absolute;
      top: 4px;
      right: 4px;
      background: $danger-color;
      color: white;
      font-size: 10px;
      padding: 2px 5px;
      border-radius: 10px;
      border: 2px solid $bg-white;
    }
  }
}

// Paneles Desplegables (Base)
.dropdown-panel {
  position: absolute;
  top: calc(100% + 12px);
  right: 0;
  background: $bg-white;
  border-radius: 12px;
  box-shadow: $shadow-lg;
  border: 1px solid $border-color;
  min-width: 280px;
  overflow: hidden;
  animation: slideIn 0.2s ease-out;

  .dropdown-title {
    padding: 1rem;
    font-weight: 600;
    margin: 0;
    border-bottom: 1px solid $border-color;
  }
}

// ══════════════════════════════════════════════
// TEMAS, NOTIFICACIONES Y PERFIL
// ══════════════════════════════════════════════
.theme-panel {
  padding: 1rem;
  .theme-swatches {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 10px;
    margin-top: 10px;

    .swatch {
      height: 30px;
      border-radius: 6px;
      border: 2px solid transparent;
      cursor: pointer;
      &.active { border-color: $text-main; transform: scale(1.1); }
    }
  }
}

.notif-panel {
  width: 320px;
  .dropdown-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem;
    border-bottom: 1px solid $border-color;
    
    .btn-link {
      background: none; border: none; color: $primary-color;
      font-size: 0.8rem; cursor: pointer;
      &:hover { text-decoration: underline; }
    }
  }

    .notif-list {
    list-style: none; padding: 0; margin: 0;
    max-height: 300px; overflow-y: auto;

    .notif-item {
      display: flex; gap: 12px; padding: 12px;
      border-bottom: 1px solid var(--border-color);
      &.unread { background: var(--bg-surface-soft); }

      .notif-icon {
        width: 35px; height: 35px; border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        color: white; font-size: 0.9rem; flex-shrink: 0;
      }

      .notif-body {
        p { margin: 0; font-size: 0.9rem; color: $text-main; }
        small { color: $text-muted; }
      }
    }
  }
}

.avatar-btn {
  display: flex;
  align-items: center;
  gap: 10px;
  background: none;
  border: none;
  cursor: pointer;
  padding: 4px 8px;
  border-radius: 8px;
  transition: $transition;

  &:hover { background: var(--bg-surface-soft); }

  .avatar-letter {
    width: 36px; height: 36px; background: $primary-color;
    color: white; border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
    font-weight: bold;
  }

    .avatar-meta {
      text-align: left;
      .avatar-name { display: block; font-weight: 600; font-size: 0.9rem; }
      .avatar-plan { font-size: 0.75rem; color: var(--color-success); display: flex; align-items: center; gap: 4px; }
    }
  .avatar-chevron { font-size: 0.7rem; color: $text-muted; }
}

.user-panel {
  &-hero {
    padding: 1.5rem; background: linear-gradient(135deg, $primary-color, color-mix(in srgb, $primary-color 70%, white));
    color: white; display: flex; align-items: center; gap: 12px;
    
    .hero-avatar {
      width: 45px; height: 45px; background: rgba(255,255,255,0.2);
      border-radius: 50%; display: flex; align-items: center; justify-content: center;
      font-size: 1.2rem; font-weight: bold; border: 2px solid white;
    }
    .hero-name { margin: 0; font-weight: 600; }
    .plan-badge { font-size: 0.7rem; background: rgba(255,255,255,0.2); padding: 2px 8px; border-radius: 10px; }
  }

  &-menu {
    list-style: none; padding: 8px 0; margin: 0;
    
    .menu-item {
      display: flex; align-items: center; gap: 12px; padding: 10px 16px;
      text-decoration: none; color: $text-main; transition: $transition;
      width: 100%; text-align: left; background: none; border: none; cursor: pointer;

      &:hover { background: #f9fafb; }
      &:hover { background: var(--bg-surface-soft); }
      &-icon { font-size: 1.1rem; color: $text-muted; width: 20px; }
      p { margin: 0; font-size: 0.9rem; font-weight: 500; }
      small { color: $text-muted; display: block; }

      &--danger { 
        color: $danger-color; 
        .menu-item-icon { color: $danger-color; }
      }
    }
    .menu-divider { height: 1px; background: $border-color; margin: 8px 0; }
  }
}

// ══════════════════════════════════════════════
// MASCOTA FLOTANTE (LUKA)
// ══════════════════════════════════════════════
.float-mascot {
  position: fixed;
  bottom: 2rem;
  right: 2rem;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  z-index: 2000;

  .float-bubble {
    background: $bg-white;
    padding: 1rem;
    border-radius: 15px;
    box-shadow: $shadow-lg;
    margin-bottom: 1rem;
    max-width: 200px;
    position: relative;
    border: 1px solid $border-color;

    &::after { // Triangulito de la burbuja
      content: '';
      position: absolute; bottom: -8px; right: 20px;
      border-left: 8px solid transparent; border-right: 8px solid transparent;
      border-top: 8px solid $bg-white;
    }

    p { margin: 0; font-size: 0.9rem; color: $text-main; }
    .float-bubble-close {
      position: absolute; top: -8px; right: -8px;
      width: 20px; height: 20px; border-radius: 50%;
      background: $text-main; color: white; border: none;
      font-size: 10px; cursor: pointer;
    }
  }

  &-btn {
    background: none; border: none; cursor: pointer;
    position: relative; transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);

    &:hover { transform: scale(1.1); }
    &.bounce { animation: bounce 2s infinite; }

    .float-mascot-img { width: 60px; height: 60px; object-fit: contain; }
    .float-badge {
      position: absolute; top: 0; right: 0;
      background: $danger-color; color: white;
      font-size: 11px; padding: 2px 6px; border-radius: 10px;
    }
  }
}

// ══════════════════════════════════════════════
// ANIMACIONES
// ══════════════════════════════════════════════
@keyframes slideIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}

@keyframes bounce {
  0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
  40% { transform: translateY(-10px); }
  60% { transform: translateY(-5px); }
}

.float-mascot-img {
  width: 80px;      
  height: 80px;     
  object-fit: contain; 
  display: block;   
}

.float-mascot-btn {
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 0;
  outline: none;
  
  &:hover {
    transform: scale(1.1); 
    transition: transform 0.2s ease;
  }
}

@media (max-width: 1024px) {
  .luka-header {
    height: auto;
    min-height: 74px;
    padding: 10px 1rem;

    .header-left {
      flex-direction: row;
      align-items: center;
      gap: 10px;
    }

    .header-right {
      gap: 0.5rem;
    }

    .header-left .breadcrumb {
      display: none;
    }
  }

  .avatar-btn .avatar-meta {
    display: none;
  }

  .header-pills {
    gap: 0.45rem;
  }

  .metric-pill {
    min-width: 80px;
    padding: 3px 6px;
  }

  .health-badge {
    display: none;
  }
}

@media (max-width: 768px) {
  .mobile-menu-btn {
    display: inline-flex;
  }

  .luka-header {
    height: auto;
    min-height: 72px;
    padding: 10px 12px;
    gap: 0.65rem;

    .header-left {
      flex: 1;
      min-width: 0;
    }

    .header-left .breadcrumb {
      display: none;
    }

    .header-left .page-title {
      font-size: 1.15rem;
      font-weight: 900;
    }

    .header-right {
      gap: 0.35rem;
    }
  }

  .header-pills {
    display: none;
  }

  .metric-pill--desktop-only {
    display: none;
  }

  .dropdown-panel {
    right: -8px;
    min-width: 260px;
  }
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\layout\header\header\header.spec.ts

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Header } from './header';

describe('Header', () => {
  let component: Header;
  let fixture: ComponentFixture<Header>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Header]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Header);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\layout\header\header\header.ts


import { Component, OnInit, OnDestroy, HostListener, signal, effect, inject } from '@angular/core';
import { CommonModule }                     from '@angular/common';
import { RouterModule, Router,
         NavigationEnd, ActivatedRoute }    from '@angular/router';
import { filter, map }                      from 'rxjs/operators';
import { Subscription }                     from 'rxjs';
import { AuthService } from '../../../core/services/auth.service';
import { SidebarStateService } from '../../../core/services/sidebar-state.service';
import { FinancieroService } from '../../../core/services/Financiero.service';
import { AppEventBus } from '../../../core/services/app-event-bus.service';
import { Transacciones } from '../../../core/services/transacciones';
import { IaService } from '../../../core/services/ia.service';

interface Breadcrumb  { label: string; route?: string; }

interface Notificacion {
  id: number; icon: string; color: string;
  text: string; time: string; read: boolean;
}

interface Tema {
  id: string; label: string; color: string;
  vars: Record<string, string>;
}

// TODO: reemplazar con MascotaService.getMensajeDiario()

const FLOAT_MSGS = [
  '¡Hola! 👋 ¿Ya registraste tus gastos de hoy?',
  '🌿 Recuerda: pequeños ahorros hacen grandes metas.',
  '🎯 Estás al 68% de tu meta principal. ¡Casi!',
  '⚠️ Tu gasto en comida subió 12% esta semana.',
  '🔥 ¡14 días de racha! Sigue así, estás imparable.',
  '💡 Tip: Usa presupuestos por categoría para ahorrar más.',
];

@Component({
  selector:    'app-header',
  standalone:  true,
  imports:     [CommonModule, RouterModule],
  templateUrl: './header.html',
  styleUrl:    './header.scss'
})
export class Header implements OnInit, OnDestroy {
  public readonly iaService = inject(IaService);


  pageTitle   = 'Resumen';
  breadcrumbs: Breadcrumb[] = [];


  // ── Estado dropdowns ──
  showNotifications = false;
  showUserMenu      = false;
  showThemePicker   = false;

  // ── Notificaciones mock ──
  // TODO: inyectar NotificacionService
  //       GET  /api/notificaciones?leidas=false  → Notificacion[]
  notificaciones: Notificacion[] = [
    { id: 1, icon: 'fa-solid fa-triangle-exclamation', color: '#f5a623',
      text: 'Estás al 80% de tu presupuesto de comida', time: 'Hace 5 min', read: false },
    { id: 2, icon: 'fa-solid fa-circle-check',         color: '#1db954',
      text: '¡Meta de ahorro "Viaje" completada!',      time: 'Hace 1h',   read: false },
    { id: 3, icon: 'fa-solid fa-arrow-trend-down',     color: '#00d4aa',
      text: 'Tus gastos bajaron un 12% esta semana',    time: 'Ayer',       read: true  },
  ];

  get notifCount(): number {
    return this.notificaciones.filter(n => !n.read).length;
  }

  // ── Temas ──
  // TODO: persistir temaActual en PreferenciasService
  //       GET  /api/usuario/preferencias → { tema: string }
  //       PATCH /api/usuario/preferencias { tema: string }
  temas: Tema[] = [
    { id: 'nature', label: 'Naturaleza', color: '#1db954',
      vars: { '--c-primary': '#1db954', '--c-accent': '#00d4aa' } },
    { id: 'ocean',  label: 'Océano',    color: '#0ea5e9',
      vars: { '--c-primary': '#0ea5e9', '--c-accent': '#06b6d4' } },
    { id: 'sunset', label: 'Sunset',    color: '#f97316',
      vars: { '--c-primary': '#f97316', '--c-accent': '#ef4444' } },
    { id: 'violet', label: 'Violeta',   color: '#8b5cf6',
      vars: { '--c-primary': '#8b5cf6', '--c-accent': '#a78bfa' } },
    { id: 'gold',   label: 'Dorado',    color: '#f59e0b',
      vars: { '--c-primary': '#f59e0b', '--c-accent': '#fbbf24' } },
  ];
  temaActual = 'nature';

  // ── Mascota flotante ──
 
  showFloatMsg    = false;
  floatMascotMsg  = '';
  floatBounce     = false;
  floatBadgeCount = 1;   // mock

  // Racha de transacciones del usuario
  rachaDias = signal<number>(0);

  private txSub?: Subscription;

  constructor(
    public  auth:   AuthService,
    public financiero: FinancieroService,
    public sidebarState: SidebarStateService,
    private router: Router,
    private route:  ActivatedRoute,
    private eventBus: AppEventBus,
    private transaccionesService: Transacciones
  ) {
    // Cargar la racha de forma reactiva ante cambios de usuario
    effect(() => {
      const user = this.auth.usuario();
      if (user) {
        this.cargarRacha();
      } else {
        this.rachaDias.set(0);
      }
    });
  }

  toggleSidebarMobile(): void {
    this.sidebarState.toggleMobile();
  }

  ngOnInit(): void {
    this.financiero.cargarResumen();

    this.txSub = this.eventBus.on('TRANSACTION_MODIFIED').subscribe(() => {
      this.financiero.cargarResumen();
      this.cargarRacha();
    });

    // Escucha cambios de ruta para actualizar título y breadcrumbs
    this.router.events
      .pipe(
        filter(e => e instanceof NavigationEnd),
        map(() => {
          let r = this.route;
          while (r.firstChild) r = r.firstChild;
          return { data: r.snapshot.data, queryParams: r.snapshot.queryParams };
        })
      )
      .subscribe(({data, queryParams}) => {
        this.pageTitle   = data['title']       ?? 'Luka';
        this.breadcrumbs = data['breadcrumbs'] ? [...data['breadcrumbs']] : [];
        this.actualizarBreadcrumbsModulo(queryParams);
        this.closeAll();
      });

    // Carga título inicial (sin esperar evento de navegación)
    let r = this.route;
    while (r.firstChild) r = r.firstChild;
    const data       = r.snapshot.data;
    const queryParams = r.snapshot.queryParams;
    this.pageTitle   = data['title']       ?? 'Resumen';
    this.breadcrumbs = data['breadcrumbs'] ? [...data['breadcrumbs']] : [];
    this.actualizarBreadcrumbsModulo(queryParams);

    // Mascota aparece automáticamente a los 4s
    // TODO: mensaje personalizado desde MascotaService
    setTimeout(() => {
      this.abrirMascota('¡Hola! 👋 ¿Ya registraste tus gastos de hoy?');
    }, 4000);
  }

  ngOnDestroy(): void {
    this.txSub?.unsubscribe();
  }

  private actualizarBreadcrumbsModulo(queryParams: any): void {
    const modulo = queryParams['modulo'];
    if (modulo) {
      const MODULO_NOMBRES: Record<string, string> = {
        'predecir-gastos': 'PREDICCIÓN DE GASTOS',
        'gasto-hormiga': 'GASTOS HORMIGA',
        'simular-meta': 'SIMULAR META',
        'reporte-completo': 'REPORTE EJECUTIVO',
        'estilo-vida': 'ESTILO DE VIDA',
        'habitos-financieros': 'HÁBITOS FINANCIEROS',
        'reto-ahorro': 'RETO DE AHORRO'
      };
      const nombre = MODULO_NOMBRES[modulo] || modulo.replace(/-/g, ' ').toUpperCase();
      this.breadcrumbs.push({ label: nombre });
    }
  }

  get totalIngresosMes(): number {
    return this.financiero.resumen()?.totalIngresos ?? 3850;
  }

  get totalGastosMes(): number {
    return this.financiero.resumen()?.totalGastos ?? 2950;
  }

  get balanceActual(): number {
    return this.totalIngresosMes - this.totalGastosMes;
  }

  get saludTexto(): 'Buena' | 'Atención' | 'Crítica' {
    if (this.totalIngresosMes <= 0) return 'Crítica';
    const ratio = this.totalGastosMes / this.totalIngresosMes;
    if (ratio <= 0.7) return 'Buena';
    if (ratio <= 0.95) return 'Atención';
    return 'Crítica';
  }

  get saludClase(): string {
    switch (this.saludTexto) {
      case 'Buena':
        return 'health-badge--good';
      case 'Atención':
        return 'health-badge--warn';
      default:
        return 'health-badge--bad';
    }
  }

  formatSoles(value: number): string {
    return new Intl.NumberFormat('es-PE', {
      style: 'currency',
      currency: 'PEN',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  }

  // Cierra todos los dropdowns al hacer clic fuera del header
  @HostListener('document:click')
  onDocClick(): void { this.closeAll(); }

  closeAll(): void {
    this.showNotifications = false;
    this.showUserMenu      = false;
    this.showThemePicker   = false;
  }

  toggleNotifications(): void {
    this.showNotifications = !this.showNotifications;
    this.showUserMenu = this.showThemePicker = false;
  }

  toggleUserMenu(): void {
    this.showUserMenu = !this.showUserMenu;
    this.showNotifications = this.showThemePicker = false;
  }

  toggleThemePicker(): void {
    this.showThemePicker = !this.showThemePicker;
    this.showNotifications = this.showUserMenu = false;
  }

  markAllRead(): void {
    // llamar NotificacionService.marcarTodasLeidas()
    //       PATCH /api/notificaciones/leer-todas
    this.notificaciones.forEach(n => n.read = true);
  }

  setTema(tema: Tema): void {
    this.temaActual = tema.id;
    Object.entries(tema.vars).forEach(([k, v]) => {
      document.documentElement.style.setProperty(k, v);
      document.documentElement.style.setProperty(k + '-soft', v + '18');
    });
    
    // TODO: persistir en PreferenciasService
    //       PATCH /api/usuario/preferencias { tema: tema.id }
    this.showThemePicker = false;
  }

  toggleFloatMsg(): void {
    if (!this.showFloatMsg) {
      // TODO: obtener mensaje desde MascotaService
      const idx = Math.floor(Math.random() * FLOAT_MSGS.length);
      this.floatMascotMsg  = FLOAT_MSGS[idx];
      this.floatBadgeCount = 0;
    }
    this.showFloatMsg = !this.showFloatMsg;
    this.floatBounce  = true;
    setTimeout(() => this.floatBounce = false, 700);
  }

  closeFloatMsg(): void { this.showFloatMsg = false; }

  abrirMascota(msg: string): void {
    this.floatMascotMsg  = msg;
    this.showFloatMsg    = true;
    this.floatBounce     = true;
    this.floatBadgeCount = 0;
    setTimeout(() => this.floatBounce = false, 700);
  }

  calcularRacha(transacciones: any[]): number {
    if (!transacciones || transacciones.length === 0) {
      return 0;
    }

    // Extraer fechas en formato YYYY-MM-DD
    const fechasSet = new Set<string>();
    transacciones.forEach(t => {
      const fechaStr = t.fechaRegistro || t.fechaTransaccion;
      if (fechaStr) {
        const fecha = new Date(fechaStr);
        if (!isNaN(fecha.getTime())) {
          const yyyy = fecha.getFullYear();
          const mm = String(fecha.getMonth() + 1).padStart(2, '0');
          const dd = String(fecha.getDate()).padStart(2, '0');
          fechasSet.add(`${yyyy}-${mm}-${dd}`);
        }
      }
    });

    const fechasOrdenadas = Array.from(fechasSet).sort((a, b) => b.localeCompare(a));
    if (fechasOrdenadas.length === 0) {
      return 0;
    }

    const hoyObj = new Date();
    const hoyStr = `${hoyObj.getFullYear()}-${String(hoyObj.getMonth() + 1).padStart(2, '0')}-${String(hoyObj.getDate()).padStart(2, '0')}`;
    
    const ayerObj = new Date();
    ayerObj.setDate(ayerObj.getDate() - 1);
    const ayerStr = `${ayerObj.getFullYear()}-${String(ayerObj.getMonth() + 1).padStart(2, '0')}-${String(ayerObj.getDate()).padStart(2, '0')}`;

    const masReciente = fechasOrdenadas[0];
    
    // Si la más reciente no es hoy ni ayer, racha es 0
    if (masReciente !== hoyStr && masReciente !== ayerStr) {
      return 0;
    }

    let racha = 1;
    let fechaActual = new Date(masReciente + 'T00:00:00');

    for (let i = 1; i < fechasOrdenadas.length; i++) {
      const fechaSiguiente = new Date(fechasOrdenadas[i] + 'T00:00:00');
      const difTiempo = fechaActual.getTime() - fechaSiguiente.getTime();
      const difDias = Math.round(difTiempo / (1000 * 60 * 60 * 24));

      if (difDias === 1) {
        racha++;
        fechaActual = fechaSiguiente;
      } else if (difDias > 1) {
        break; // Hueco en la racha
      }
    }

    return racha;
  }

  cargarRacha(): void {
    const usuarioId = this.auth.usuario()?.id;
    if (!usuarioId) {
      this.rachaDias.set(0);
      return;
    }

    // Listar las últimas 100 transacciones para computar la racha
    this.transaccionesService.listarHistorial({ pagina: 0, tamanio: 100 }).subscribe({
      next: (pagina) => {
        if (pagina && pagina.content) {
          const racha = this.calcularRacha(pagina.content);
          this.rachaDias.set(racha);
          localStorage.setItem('luka_racha_mock', racha.toString());
        } else {
          this.rachaDias.set(0);
        }
      },
      error: (err) => {
        console.error('Error al recuperar historial para racha:', err);
        const localRacha = localStorage.getItem('luka_racha_mock');
        this.rachaDias.set(localRacha ? parseInt(localRacha, 10) : 14);
      }
    });
  }

  logout(): void {
    // TODO: AuthService.logout() debe limpiar token y llamar
    //       POST /api/auth/logout antes de redirigir
    this.auth.logout();
    this.router.navigate(['/login']);
  }
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\layout\layout\layout\layout.html


<div class="luka-layout">

  <app-sidebar></app-sidebar>

  <div class="luka-main" [class.collapsed]="sidebarState.collapsed()">
    <app-header></app-header>

    <main class="luka-content">
      <div class="content-inner">
        <router-outlet></router-outlet>
      </div>
    </main>
  </div>

</div>


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\layout\layout\layout\layout.scss


.luka-layout {
  display: flex;
  min-height: 100vh;
  background: var(--bg-body);
  color: var(--text-primary);
  position: relative;
  overflow: hidden;

  // Fondo decorativo sutil
  &::before {
    content: '';
    position: fixed;
    top: -200px;
    right: -200px;
    width: 600px;
    height: 600px;
    border-radius: 50%;
    background: radial-gradient(circle, color-mix(in srgb, var(--color-primary) 12%, transparent) 0%, transparent 70%);
    pointer-events: none;
    z-index: 0;
  }

  &::after {
    content: '';
    position: fixed;
    bottom: -150px;
    left: 100px;
    width: 400px;
    height: 400px;
    border-radius: 50%;
    pointer-events: none;
    z-index: 0;
  }
}

.luka-main {
  flex: 1;
  margin-left: var(--sidebar-w);
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  transition: margin-left 0.35s cubic-bezier(0.4, 0, 0.2, 1);
  position: relative;

&.sidebar-collapsed,
&.collapsed {
  margin-left: var(--sidebar-w-col, 80px);
}
}

.luka-content {
  flex: 1;
  margin-top: 0;
  overflow: auto;
  background: linear-gradient(180deg, var(--bg-body) 0%, var(--bg-surface-soft) 100%);
  padding: 24px 24px 32px;
}

.content-inner {
  width: 100%;
  max-width: 1800px;
  margin: 0;
}

/* ── Dark mode: quitar fondo extra para que no "ensucie" las secciones ── */
body.theme-dark {
  .luka-layout {
    &::before,
    &::after {
      display: none;
    }
  }

  .luka-content {
    background: transparent;
  }
}

/* ── Responsive ── */
@media (max-width: 1024px) {
  .luka-main {
    margin-left: var(--sidebar-w-col);
  }

  .luka-content {
    padding: 16px 16px 28px;
  }
}

@media (max-width: 768px) {
  .luka-main {
    margin-left: 0;
  }

  .luka-content {
    margin-top: 0;
    padding: 16px 12px 24px;
  }

  .content-inner {
    max-width: 100%;
  }
}



## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\layout\layout\layout\layout.spec.ts

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Layout } from './layout';

describe('Layout', () => {
  let component: Layout;
  let fixture: ComponentFixture<Layout>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Layout]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Layout);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\layout\layout\layout\layout.ts

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { RouterOutlet } from '@angular/router';
import { Sidebar } from '../../sidebar/sidebar/sidebar';
import { Header } from '../../header/header/header';
import { SidebarStateService } from '../../../core/services/sidebar-state.service';


@Component({
  selector: 'app-layout',
  standalone:true,
  imports: [RouterOutlet,CommonModule, RouterModule,Sidebar,Header],
  templateUrl: './layout.html',
  styleUrls: ['./layout.scss'],
})
export class Layout {
  constructor(public sidebarState: SidebarStateService){}
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\layout\sidebar\sidebar\sidebar.html

<div class="sidebar-backdrop" *ngIf="sidebarState.mobileOpen()" (click)="closeMobile()"></div>

<nav class="sidebar" [class.collapsed]="sidebarState.collapsed()" [class.mobile-open]="sidebarState.mobileOpen()" [class.modal-open]="modalPlanesAbierto()">

  <!-- ── LOGO  ── -->
  <div class="sidebar-header">

    <div class="logo-wrap">
<img src="assets/avatares/figuras/panda.png" alt="Luka" class="logo-img" />    </div>

    <div class="brand" *ngIf="sidebarState.expanded()">
      <span class="brand-name">LUKA</span>
      <span class="brand-sub">Finanzas personales</span>
    </div>

  </div>

  <div class="brand-divider" *ngIf="sidebarState.expanded()"></div>


<!-- ══ NAVEGACIÓN PRINCIPAL ══ -->
<ng-container *ngIf="!isPerfilSection">

  <p class="nav-section-label" *ngIf="sidebarState.expanded()">Principal</p>

  <ul class="nav-list">
    <li *ngFor="let item of navItems">
      <a
        [routerLink]="item.route"
        routerLinkActive="active"
        [routerLinkActiveOptions]="{ exact: !!item.exact }"
        [title]="sidebarState.collapsed() ? item.label : ''"
        [title]="sidebarState.collapsed() ? item.label : ''"
        class="nav-link"
        (click)="onNavClick()"
      >
        <i [className]="item.icon" class="nav-icon"></i>
        <span class="nav-text" *ngIf="sidebarState.expanded()">{{ item.label }}</span>
        <span class="nav-badge" *ngIf="item.badge && sidebarState.expanded()">
          {{ item.badge }}
        </span>
      </a>
    </li>
  </ul>

</ng-container>


<!-- ══ NAVEGACIÓN MI CUENTA ══ -->
<ng-container *ngIf="isPerfilSection">
  <a

    routerLink="/dashboard"
    class="nav-link back-link"
    (click)="onNavClick()"
  >
    <i class="fa-solid fa-arrow-left nav-icon"></i>
    <span class="nav-text" *ngIf="sidebarState.expanded()">Volver</span>
  </a>

  <p class="nav-section-label" *ngIf="sidebarState.expanded()">Mi cuenta</p>

  <ul class="nav-list">
    <li *ngFor="let item of perfilNavItems">
      <a
        [routerLink]="item.route"
        routerLinkActive="active"
        [title]="sidebarState.collapsed() ? item.label : ''"
        class="nav-link"
        (click)="onNavClick()"
      >
        <i [className]="item.icon" class="nav-icon"></i>
        <span class="nav-text" *ngIf="sidebarState.expanded()">{{ item.label }}</span>
      </a>
    </li>
  </ul>

</ng-container>



  <!-- ── MASCOTA LUKA ── -->
  <div class="sidebar-spacer"></div>

  <div class="sidebar-mascot" *ngIf="sidebarState.expanded()" (click)="toggleMascotMsg()">

    <div class="mascot-bubble" *ngIf="showMascotMsg()">
      <p>{{ mascotMsg() }}</p>
    </div>

        <div class="mascot-row">
<img src="assets/avatares/figuras/panda.png" alt="Luka" class="logo-img" />      <span class="mascot-hint" *ngIf="!showMascotMsg()">¡Toca a Luka!</span>
    </div>

  </div>
<article class="sidebar-premium"
         *ngIf="sidebarState.expanded() && !auth.esPremium() && !auth.esPro()"
         >

  <div class="premium-head">
    <i class="fa-solid fa-crown"></i>
    <span>LUKA Premium</span>
  </div>

  <p>Mejora tu experiencia con reportes avanzados y alertas inteligentes.</p>

  <div class="premium-actions">
    <button type="button" class="btn-premium" (click)="abrirModalPlanes()">
      Ver planes
    </button>

    <button type="button" class="btn-support" routerLink="/ayuda" (click)="$event.stopPropagation(); onNavClick()">
      Soporte
    </button>
  </div>

</article>

@if (modalPlanesAbierto()) {
  <div class="planes-modal-backdrop" (click)="cerrarModalPlanes()">
    <section class="planes-modal" (click)="$event.stopPropagation()">

      <button type="button" class="planes-modal__close" (click)="cerrarModalPlanes()">
        <i class="fa-solid fa-xmark"></i>
      </button>

      <div class="planes-modal__grid">

        <!-- PLAN PRO -->
        <article class="plan-card plan-card--pro">
          <div class="plan-card__tag">PLAN</div>

          <div class="plan-card__header">
            <div>
              <h2>Pro <i class="fa-solid fa-star"></i></h2>
              <p>Todo lo esencial para organizar tus finanzas con IA.</p>
            </div>

            <div class="plan-card__illustration plan-card__illustration--pro">
              <i class="fa-solid fa-chart-line"></i>
            </div>
          </div>

          <div class="plan-card__price">
            <span>S/</span>
            <strong>14.90</strong>
            <small>/mes</small>
          </div>

          <p class="plan-card__cancel">Cancela cuando quieras.</p>

          <hr />

          <h3>Incluye:</h3>

          <ul class="plan-card__features">
            <li>
              <i class="fa-solid fa-brain"></i>
              <span>
                <strong>Asistente IA Financiero</strong>
                <small>Resuelve dudas y recibe orientación financiera.</small>
              </span>
            </li>

            <li>
              <i class="fa-solid fa-bullseye"></i>
              <span>
                <strong>Recomendaciones personalizadas</strong>
                <small>Sugerencias según tus hábitos y objetivos.</small>
              </span>
            </li>

            <li>
              <i class="fa-solid fa-chart-pie"></i>
              <span>
                <strong>Reportes y análisis inteligentes</strong>
                <small>Visualiza tus finanzas de forma clara.</small>
              </span>
            </li>
          </ul>

          <div class="plan-card__queries">
            <h4>Uso mensual de IA</h4>

            <div>
              <span>Módulos de Analítica</span>
              <strong>20 consultas</strong>
            </div>

            <div>
              <span>Auto Clasificar</span>
              <strong>10 consultas</strong>
            </div>
          </div>

          <button type="button" class="plan-card__button plan-card__button--pro" (click)="comprarPlan('PRO')" [disabled]="comprandoPlan()">
            {{ comprandoPlan() ? 'Redirigiendo...' : '✨ Elegir Plan Pro' }}
          </button>

          <p class="plan-card__secure">
            <i class="fa-solid fa-lock"></i>
            Pago seguro y protegido
          </p>
        </article>

        <!-- PLAN PREMIUM -->
        <article class="plan-card plan-card--premium">
          <div class="plan-card__popular">
            <i class="fa-solid fa-star"></i>
            MÁS POPULAR
          </div>

          <div class="plan-card__tag plan-card__tag--premium">PLAN</div>

          <div class="plan-card__header">
            <div>
              <h2>Premium <i class="fa-solid fa-crown"></i></h2>
              <p>Todo lo que necesitas para tomar mejores decisiones y crecer tu dinero.</p>
            </div>

            <div class="plan-card__illustration plan-card__illustration--premium">
              <i class="fa-solid fa-chart-simple"></i>
            </div>
          </div>

          <div class="plan-card__price plan-card__price--premium">
            <span>S/</span>
            <strong>25.90</strong>
            <small>/mes</small>
          </div>

          <p class="plan-card__cancel">Cancela cuando quieras.</p>

          <hr />

          <h3>Incluye todo lo del plan Pro, más:</h3>

          <ul class="plan-card__features">
            <li>
              <i class="fa-solid fa-wand-magic-sparkles"></i>
              <span>
                <strong>Análisis avanzado con IA</strong>
                <small>Insights más profundos para tomar mejores decisiones.</small>
              </span>
            </li>

            <li>
              <i class="fa-solid fa-star"></i>
              <span>
                <strong>Recomendaciones inteligentes avanzadas</strong>
                <small>Sugerencias contextuales y más precisas.</small>
              </span>
            </li>

            <li>
              <i class="fa-solid fa-chart-pie"></i>
              <span>
                <strong>Reportes avanzados limitados</strong>
                <small>Más detalle, más control, mejores resultados.</small>
              </span>
            </li>

            <li>
              <i class="fa-solid fa-shield-halved"></i>
              <span>
                <strong>Prioridad y nuevas funciones</strong>
                <small>Acceso anticipado a nuevas herramientas.</small>
              </span>
            </li>
          </ul>

          <div class="plan-card__queries plan-card__queries--premium">
            <h4>Uso mensual de IA</h4>

            <div>
              <span>Módulos de Analítica</span>
              <strong>50 consultas</strong>
            </div>

            <div>
              <span>Auto Clasificar</span>
              <strong>20 consultas</strong>
            </div>
          </div>

          <button type="button" class="plan-card__button plan-card__button--premium" (click)="comprarPlan('PREMIUM')" [disabled]="comprandoPlan()">
            {{ comprandoPlan() ? 'Redirigiendo...' : '✨ Elegir Plan Premium' }}
          </button>

          <p class="plan-card__secure">
            <i class="fa-solid fa-lock"></i>
            Pago seguro y protegido
          </p>
        </article>

      </div>
    </section>
  </div>
}



</nav>


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\layout\sidebar\sidebar\sidebar.scss

/* =============================================
   LUKA — Sidebar SCSS
   ============================================= */

.sidebar {
  position: fixed;
  top: 0; left: 0;
  width: var(--sidebar-w);
  height: 100vh;
  background:
    radial-gradient(120% 90% at 0% 0%, rgba(56, 189, 248, 0.09) 0%, rgba(56, 189, 248, 0) 46%),
    radial-gradient(110% 90% at 100% 100%, rgba(45, 212, 191, 0.08) 0%, rgba(45, 212, 191, 0) 45%),
    var(--bg-sidebar);
  border-right: 1px solid var(--border-light);
  display: flex;
  flex-direction: column;
  padding: 18px 12px 14px;
  gap: 4px;
  overflow-y: auto;
  overflow-x: hidden;
  z-index: 1000;
  box-shadow: 10px 0 30px rgba(15, 23, 42, 0.08);
  transition: width 0.35s cubic-bezier(0.4,0,0.2,1), box-shadow 0.25s ease;

  &.modal-open {
    z-index: 99999;
  }

  &.collapsed {
    width: var(--sidebar-w-col);

    .toggle-btn   { right: -14px; }
    .brand-divider,
    .nav-section-label,
    .sidebar-premium {
      display: none;
    }

    .nav-list {
      gap: 6px;
    }

    .nav-link {
      justify-content: center;
      padding: 12px 10px;
      border-radius: 14px;
    }

    .nav-icon {
      margin-right: 0;
      font-size: 1rem;
    }
  }
}

.sidebar-backdrop {
  position: fixed;
  inset: 0;
  background: rgba(15, 23, 42, 0.45);
  backdrop-filter: blur(2px);
  z-index: 998;
}


/* ── Header / Logo ── */
.sidebar-header {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 6px 8px 12px;
  position: relative;
  flex-shrink: 0;
}

.logo-wrap { flex-shrink: 0; }

.logo-img {
  width: 42px; height: 42px;
  border-radius: 12px;
  object-fit: cover;
  box-shadow:
    0 10px 22px rgba(16, 185, 129, 0.18),
    0 2px 8px rgba(15, 23, 42, 0.15);
}

.brand {
  flex: 1;
  overflow: hidden;
}

.brand-name {
  font-family: var(--font-h);
  font-size: 1.12rem;
  font-weight: 800;
  color: var(--c-primary);
  letter-spacing: 0.12em;
  line-height: 1;
  display: block;
}

.brand-sub {
  font-size: 0.6rem;
  color: var(--text-muted);
  font-weight: 500;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  display: block;
  margin-top: 2px;
}

.brand-divider {
  height: 1px;
  margin: 2px 8px 10px;
  background: linear-gradient(90deg, rgba(148, 163, 184, 0.15) 0%, rgba(148, 163, 184, 0.55) 50%, rgba(148, 163, 184, 0.15) 100%);
}

/* ── Botón colapsar ── */
.toggle-btn {
  position: absolute;
  top: 10px; right: -14px;
  width: 28px; height: 28px;
  border-radius: 50%;
  background: var(--bg-card);
  border: 1.5px solid var(--border);
  color: var(--text-muted);
  display: flex; align-items: center; justify-content: center;
  cursor: pointer; font-size: 0.6rem;
  box-shadow: var(--shadow-sm);
  transition: var(--t);
  z-index: 10;

  &:hover {
    background: var(--c-primary);
    color: #fff;
    border-color: var(--c-primary);
    transform: scale(1.1);
  }
}


/* ── Perfil rápido ── */
.sidebar-profile {
  display: flex;
  align-items: center;
  gap: 10px;
  background: var(--c-primary-soft);
  border: 1.5px solid rgba(29,185,84,0.15);
  border-radius: var(--r-md);
  padding: 10px 12px;
  margin-bottom: 6px;
}

.avatar {
  width: 36px; height: 36px;
  border-radius: 50%;
  background: linear-gradient(135deg, var(--c-primary) 0%, var(--c-accent) 100%);
  color: #fff;
  font-family: var(--font-h);
  font-weight: 800;
  font-size: 1rem;
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0;
}

.profile-info { overflow: hidden; }

.profile-name {
  font-size: 0.82rem;
  font-weight: 700;
  color: var(--text-h);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}

.profile-plan {
  font-size: 0.65rem;
  color: var(--c-primary);
  font-weight: 600;
  display: flex; align-items: center; gap: 4px;
  margin-top: 2px;
  i { font-size: 0.6rem; }
}


/* ── Etiqueta de sección ── */
.nav-section-label {
  font-size: 0.62rem;
  font-weight: 800;
  color: var(--text-muted);
  text-transform: uppercase;
  letter-spacing: 0.11em;
  padding: 10px 10px 6px;
}


/* ── Navegación ── */
.nav-list {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 4px;
  flex-shrink: 0;
}

.nav-link {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 13px;
  border-radius: 14px;
  border: 1px solid transparent;
  color: var(--text-muted);
  text-decoration: none;
  font-size: 0.95rem;
  font-weight: 600;
  transition: background-color .22s ease, color .22s ease, transform .22s ease, border-color .22s ease, box-shadow .22s ease;
  cursor: pointer;
  position: relative;
  overflow: hidden;

  &:hover {
    background: color-mix(in srgb, var(--c-primary-soft) 80%, #ffffff 20%);
    border-color: color-mix(in srgb, var(--c-primary) 16%, transparent);
    color: var(--c-primary);
    transform: translateX(3px);
    box-shadow: 0 10px 22px rgba(15, 23, 42, 0.07);

    .nav-icon {
      color: var(--c-primary);
      transform: scale(1.04);
    }
  }

  &.active {
    background: linear-gradient(98deg, rgba(20, 184, 166, 0.18) 0%, rgba(34, 197, 94, 0.2) 100%);
    border-color: rgba(16, 185, 129, 0.34);
    color: color-mix(in srgb, var(--c-primary) 86%, #0f172a 14%);
    font-weight: 700;
    box-shadow:
      0 10px 24px rgba(16, 185, 129, 0.14),
      inset 0 0 0 1px rgba(255, 255, 255, 0.25);

    &::before {
      content: '';
      position: absolute;
      left: 8px;
      top: 10px;
      bottom: 10px;
      width: 4px;
      background: linear-gradient(180deg, #14b8a6 0%, #22c55e 100%);
      border-radius: 999px;
      box-shadow: 0 0 12px rgba(20, 184, 166, 0.35);
    }

    .nav-icon {
      color: var(--c-primary);
    }
  }
}

.nav-icon {
  width: 20px;
  text-align: center;
  font-size: 1rem;
  flex-shrink: 0;
  color: var(--text-muted);
  transition: color .2s ease, transform .2s ease;
}

.nav-text {
  flex: 1;
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}

.nav-badge {
  background: var(--c-primary);
  color: #fff;
  font-size: 0.62rem;
  font-weight: 800;
  padding: 3px 8px;
  border-radius: var(--r-f);
  box-shadow: 0 6px 16px rgba(16, 185, 129, 0.32);
}


/* ── Spacer ── */
.sidebar-spacer { flex: 1; }


/* ── Mascota ── */
.sidebar-mascot {
  padding: 12px 2px 8px;
  display: flex;
  flex-direction: column;
  align-items: center;
  cursor: pointer;
  position: relative;
  gap: 4px;
  flex-shrink: 0;
}

/* ── Premium card ── */
.sidebar-premium {
  margin-top: 10px;
  border-radius: 16px;
  border: 1px solid rgba(94, 234, 212, 0.38);
  background:
    linear-gradient(130deg, rgba(6, 95, 70, 0.93) 0%, rgba(13, 148, 136, 0.9) 48%, rgba(20, 184, 166, 0.84) 100%);
  color: #f8fafc;
  padding: 12px 12px 13px;
  box-shadow: 0 16px 36px rgba(13, 148, 136, 0.26);
  flex-shrink: 0;
}

.premium-head {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-size: 0.78rem;
  font-weight: 800;
  letter-spacing: 0.04em;
  text-transform: uppercase;

  i {
    color: #fde68a;
    font-size: 0.8rem;
    filter: drop-shadow(0 2px 8px rgba(251, 191, 36, 0.35));
  }
}

.sidebar-premium p {
  margin-top: 8px;
  font-size: 0.73rem;
  line-height: 1.4;
  color: rgba(241, 245, 249, 0.95);
}

.premium-actions {
  margin-top: 10px;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
}

.btn-premium,
.btn-support {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 10px;
  padding: 7px 8px;
  font-size: 0.72rem;
  font-weight: 700;
  text-decoration: none;
  border: 1px solid transparent;
  transition: transform .2s ease, background-color .2s ease, border-color .2s ease;

  &:hover {
    transform: translateY(-1px);
  }
}

.sidebar-pro-modal-backdrop {
  position: fixed;
  inset: 0;
  background: rgba(2, 6, 23, 0.65);
  display: grid;
  place-items: center;
  padding: 16px;
  z-index: 1300;
}

.sidebar-pro-modal {
  width: min(760px, 100%);
  border-radius: 18px;
  border: 1px solid rgba(99, 102, 241, 0.55);
  background: linear-gradient(165deg, #0b1020 0%, #0f172a 55%, #101a37 100%);
  color: #e2e8f0;
  padding: 18px;
  position: relative;
  box-shadow: 0 22px 52px rgba(15, 23, 42, 0.55);

  h3 {
    margin: 10px 0 4px;
    font-size: clamp(24px, 3vw, 34px);
    color: #f8fafc;
    display: flex;
    align-items: center;
    gap: 8px;

    i {
      color: #fbbf24;
      font-size: 16px;
    }
  }
}

.sidebar-pro-close {
  position: absolute;
  top: 10px;
  right: 10px;
  width: 34px;
  height: 34px;
  border-radius: 10px;
  border: 1px solid rgba(148, 163, 184, 0.35);
  background: rgba(15, 23, 42, 0.75);
  color: #cbd5e1;
  font-size: 20px;
}

.sidebar-pro-chip {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: 30px;
  border-radius: 999px;
  padding: 0 12px;
  background: linear-gradient(135deg, #7c3aed 0%, #6366f1 100%);
  color: #f5f3ff;
  font-size: 12px;
  font-weight: 800;
  letter-spacing: .03em;
}

.sidebar-pro-sub {
  margin: 0;
  color: #94a3b8;
  font-size: 14px;
}

.sidebar-pro-price {
  margin: 14px 0 12px;
  color: #f8fafc;
  font-size: clamp(42px, 5vw, 56px);
  font-weight: 900;
  line-height: .95;

  span {
    font-size: 30px;
    margin-right: 4px;
    color: #94a3b8;
  }

  small {
    font-size: 24px;
    color: #64748b;
    margin-left: 4px;
    font-weight: 700;
  }
}

.sidebar-pro-beneficios {
  list-style: none;
  margin: 0;
  padding: 14px 0 0;
  border-top: 1px solid rgba(71, 85, 105, 0.45);
  display: grid;
  gap: 10px;

  li {
    font-size: 15px;
    color: #dbe4f0;
    display: flex;
    align-items: center;
    gap: 8px;

    &::before {
      content: '✓';
      color: #818cf8;
      font-weight: 900;
    }
  }
}

.sidebar-pro-cta {
  margin-top: 14px;
  width: 100%;
  min-height: 46px;
  border: none;
  border-radius: 14px;
  background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
  color: #fff;
  font-size: 16px;
  font-weight: 800;
  box-shadow: 0 10px 24px rgba(79, 70, 229, 0.35);
}

.sidebar-pro-layout {
  display: grid;
  grid-template-columns: 1.1fr .9fr;
  gap: 12px;
  align-items: start;
}

.sidebar-pro-panel-info {
  border: 1px solid rgba(148, 163, 184, 0.22);
  border-radius: 16px;
  background: rgba(15, 23, 42, 0.32);
  padding: 12px;

  h4 {
    margin: 0;
    font-size: 20px;
    color: #f1f5f9;
  }

  ul {
    list-style: none;
    margin: 12px 0 0;
    padding: 0;
    display: grid;
    gap: 8px;
  }

  li {
    font-size: 13px;
    line-height: 1.28;
    color: #dbe4f0;
    display: flex;
    gap: 10px;

    i {
      color: #a78bfa;
      margin-top: 2px;
    }
  }
}

.sidebar-pro-seguro {
  margin-top: 12px;
  min-height: 36px;
  border-radius: 12px;
  background: rgba(139, 92, 246, 0.16);
  border: 1px solid rgba(167, 139, 250, 0.35);
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 0 12px;
  font-size: 13px;
  font-weight: 700;
  color: #ddd6fe;
}

@media (max-width: 980px) {
  .sidebar-pro-layout {
    grid-template-columns: 1fr;
  }

  .sidebar-pro-beneficios li {
    font-size: 15px;
  }

  .sidebar-pro-panel-info h4 {
    font-size: 22px;
  }

  .sidebar-pro-panel-info li {
    font-size: 14px;
  }
}

.btn-premium {
  background: rgba(255, 255, 255, 0.95);
  color: #0f766e;

  &:hover {
    background: #ffffff;
  }
}

.btn-support {
  background: rgba(15, 23, 42, 0.18);
  color: #ffffff;
  border-color: rgba(255, 255, 255, 0.32);

  &:hover {
    background: rgba(15, 23, 42, 0.28);
  }
}

.mascot-bubble {
  background: var(--bg-card);
  border: 1.5px solid var(--border);
  border-radius: var(--r-lg);
  padding: 10px 14px;
  width: 190px;
  box-shadow: var(--shadow-md);
  animation: chat-pop 0.3s ease both;

  p {
    font-size: 0.75rem;
    font-weight: 600;
    color: var(--text-h);
    line-height: 1.4;
    text-align: center;
  }
}

.mascot-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.mascot-img {
  width: 52px; height: 52px;
  object-fit: contain;
  filter: drop-shadow(0 2px 8px rgba(29,185,84,0.25));
  transition: var(--t-bounce);
  &:hover { transform: scale(1.1); }
}

.mascot-hint {
  font-size: 0.65rem;
  color: var(--text-muted);
  font-weight: 600;
}


/* ── Racha footer ── */
.sidebar-streak {
  background: var(--c-gold-soft);
  border: 1.5px solid rgba(245,166,35,0.2);
  border-radius: var(--r-md);
  padding: 10px 12px;
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
  margin-top: 6px;
}

.streak-fire { font-size: 1.2rem; flex-shrink: 0; }

.streak-info {
  flex: 1;
  display: flex; flex-direction: column;
}

.streak-num {
  font-family: var(--font-h);
  font-size: 0.85rem;
  font-weight: 800;
  color: var(--c-gold);
}

.streak-label {
  font-size: 0.62rem;
  color: var(--text-muted);
  font-weight: 600;
}

.streak-bar-track {
  width: 100%;
  height: 4px;
  background: rgba(245,166,35,0.2);
  border-radius: var(--r-f);
  overflow: hidden;
  margin-top: 4px;
}

.streak-bar-fill {
  height: 100%;
  background: linear-gradient(90deg, var(--c-gold) 0%, #ffd166 100%);
  border-radius: var(--r-f);
  transition: width 1s cubic-bezier(0.34,1.56,0.64,1);
}


/* ── Animaciones ── */
@keyframes chat-pop {
  from { opacity: 0; transform: translateY(6px) scale(0.96); }
  to   { opacity: 1; transform: translateY(0)   scale(1); }
}

/* ── Responsive Mobile Sidebar ── */
@media (max-width: 768px) {
  .sidebar {
    width: min(72vw, 270px);
    transform: translateX(-105%);
    transition: transform 0.3s ease;
    box-shadow: 0 20px 45px rgba(2, 6, 23, 0.32);
    padding: 14px 10px 12px;

    &.collapsed {
      width: min(72vw, 270px);

      .nav-link {
        justify-content: flex-start;
        padding: 11px 12px;
      }
    }

    &.mobile-open {
      transform: translateX(0);
    }
  }

  .premium-actions {
    grid-template-columns: 1fr;
  }

  .toggle-btn {
    display: none;
  }


}


.planes-modal-backdrop {
  position: fixed;
  inset: 0;
  z-index: 99999;
  background: rgba(15, 23, 42, 0.45);
  backdrop-filter: blur(8px);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
}

.planes-modal {
  width: min(840px, 92vw);
  max-height: 90vh;
  overflow-y: auto;
  background: #ffffff;
  border-radius: 20px;
  padding: 24px;
  position: relative;
  box-shadow: 0 30px 90px rgba(15, 23, 42, 0.28);
}

.planes-modal__close {
  position: absolute;
  top: 14px;
  right: 14px;
  z-index: 5;
  width: 42px;
  height: 42px;
  min-width: 42px;
  min-height: 42px;
  border-radius: 999px;
  border: 1px solid rgba(15, 23, 42, 0.12);
  background: rgba(255, 255, 255, 0.96);
  color: #0f172a;
  font-size: 20px;
  line-height: 1;
  cursor: pointer;
  box-shadow: 0 12px 26px rgba(15, 23, 42, 0.18);
  display: flex;
  align-items: center;
  justify-content: center;

  i {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 1em;
    height: 1em;
  }
}

.planes-modal__grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 20px;
}

.plan-card {
  position: relative;
  border-radius: 20px;
  padding: 20px;
  background: #ffffff;
  border: 1.5px solid #e5d9ff;
  box-shadow: 0 18px 45px rgba(124, 58, 237, 0.08);
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

.plan-card--premium {
  border-color: #f4c76b;
  background: linear-gradient(135deg, #fffaf0, #fff7df);
}

.plan-card__popular {
  position: absolute;
  top: 0;
  right: 0;
  background: linear-gradient(135deg, #facc15, #fde68a);
  color: #b45309;
  padding: 8px 16px;
  border-bottom-left-radius: 16px;
  font-weight: 800;
  font-size: 11px;
}

.plan-card__tag {
  display: inline-flex;
  align-self: flex-start;
  padding: 4px 10px;
  border-radius: 999px;
  background: #f0e7ff;
  color: #6d28d9;
  font-weight: 800;
  font-size: 11px;
}

.plan-card__tag--premium {
  background: #fff1bc;
  color: #b45309;
}

.plan-card__header {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  margin-top: 12px;
}

.plan-card h2 {
  font-size: 24px;
  font-weight: 800;
  color: #0f172a;
  margin: 0 0 6px 0;
  display: flex;
  align-items: center;
  gap: 8px;
}

.plan-card h2 i {
  color: #7c3aed;
  font-size: 20px;
}

.plan-card--premium h2 i {
  color: #d97706;
}

.plan-card__header p {
  color: #64748b;
  font-size: 13px;
  line-height: 1.4;
  margin: 0;
}

.plan-card__illustration {
  width: 54px;
  height: 54px;
  border-radius: 50%;
  display: grid;
  place-items: center;
  font-size: 22px;
  flex-shrink: 0;
}

.plan-card__illustration--pro {
  background: radial-gradient(circle, #f3e8ff, #ede9fe);
  color: #7c3aed;
}

.plan-card__illustration--premium {
  background: radial-gradient(circle, #fef3c7, #fde68a);
  color: #d97706;
}

.plan-card__price {
  margin-top: 16px;
  display: flex;
  align-items: baseline;
  gap: 4px;
  color: #0f172a;
}

.plan-card__price span {
  font-size: 20px;
  font-weight: 800;
}

.plan-card__price strong {
  font-size: 36px;
  font-weight: 900;
  background: linear-gradient(135deg, #7c3aed, #2563eb);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.plan-card__price--premium strong {
  background: linear-gradient(135deg, #d97706, #facc15);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.plan-card__price small {
  font-size: 15px;
  font-weight: 700;
}

.plan-card__cancel {
  color: #64748b;
  margin-top: 4px;
  font-size: 12px;
}

.plan-card hr {
  border: none;
  border-top: 1px solid #e5e7eb;
  margin: 16px 0;
}

.plan-card h3 {
  color: #6d28d9;
  font-size: 14px;
  margin: 0 0 12px 0;
}

.plan-card--premium h3 {
  color: #d97706;
}

.plan-card__features {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 0;
  margin: 0;
}

.plan-card__features li {
  display: flex;
  align-items: flex-start;
  gap: 12px;
}

.plan-card__features li > i {
  width: 34px;
  height: 34px;
  border-radius: 10px;
  background: #f3e8ff;
  color: #7c3aed;
  display: grid;
  place-items: center;
  font-size: 14px;
  flex-shrink: 0;
  margin-top: 2px;
}

.plan-card--premium .plan-card__features li > i {
  background: #fff3d6;
  color: #d97706;
}

.plan-card__features strong {
  display: block;
  color: #0f172a;
  font-size: 14px;
  line-height: 1.2;
}

.plan-card__features small {
  display: block;
  color: #64748b;
  font-size: 12px;
  margin-top: 2px;
  line-height: 1.3;
}

.plan-card__queries {
  margin-top: 16px;
  padding: 12px 16px;
  border-radius: 12px;
  border: 1px solid #e2d6ff;
  background: #fbf8ff;
}

.plan-card__queries--premium {
  border-color: #f3d58b;
  background: #fffaf0;
}

.plan-card__queries h4 {
  margin: 0 0 8px 0;
  color: #6d28d9;
  font-size: 13px;
  font-weight: 800;
}

.plan-card__queries--premium h4 {
  color: #d97706;
}

.plan-card__queries div {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 4px 0;
  color: #334155;
  font-size: 12px;
}

.plan-card__queries strong {
  color: #7c3aed;
  font-size: 14px;
}

.plan-card__queries--premium strong {
  color: #d97706;
}

.plan-card__button {
  width: 100%;
  margin-top: 18px;
  border: none;
  border-radius: 12px;
  padding: 12px 18px;
  color: #ffffff;
  font-size: 15px;
  font-weight: 800;
  cursor: pointer;
  box-shadow: 0 8px 16px rgba(124, 58, 237, 0.2);
  transition: all 0.2s ease;

  &:hover {
    transform: translateY(-1px);
    box-shadow: 0 10px 20px rgba(124, 58, 237, 0.3);
  }

  &:active {
    transform: translateY(0);
  }

  &:disabled {
    opacity: 0.65;
    cursor: not-allowed;
    transform: none !important;
    box-shadow: none !important;
  }
}

.plan-card__button--pro {
  background: linear-gradient(135deg, #9333ea, #7c3aed);
}

.plan-card__button--premium {
  background: linear-gradient(135deg, #f59e0b, #eab308);
  box-shadow: 0 8px 16px rgba(217, 119, 6, 0.2);

  &:hover {
    box-shadow: 0 10px 20px rgba(217, 119, 6, 0.3);
  }
}

.plan-card__secure {
  margin-top: 10px;
  text-align: center;
  color: #94a3b8;
  font-size: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
}

@media (max-width: 1000px) {
  .planes-modal__grid {
    grid-template-columns: 1fr;
    gap: 16px;
  }

  .planes-modal {
    padding: 16px;
    max-height: 95vh;
  }

  .plan-card__header {
    flex-direction: row;
    align-items: center;
  }

  .plan-card__illustration {
    width: 44px;
    height: 44px;
    font-size: 18px;
  }
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\layout\sidebar\sidebar\sidebar.spec.ts

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Sidebar } from './sidebar';

describe('Sidebar', () => {
  let component: Sidebar;
  let fixture: ComponentFixture<Sidebar>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Sidebar]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Sidebar);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\layout\sidebar\sidebar\sidebar.ts

// =============================================
// LUKA — Sidebar Component
// =============================================
import { Component, OnInit, signal } from '@angular/core';
import { CommonModule }               from '@angular/common';
import { RouterModule }               from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { SidebarStateService } from '../../../core/services/sidebar-state.service';
import { NAV_ITEMS, BOTTOM_NAV_ITEMS } from '../../../config/navigation.config';
import { Router } from '@angular/router';
import { filter } from 'rxjs';
import { NavigationEnd } from '@angular/router';
import { SuscripcionService } from '../../../core/services/suscripcion.service';


// TODO: reemplazar con MascotaService.getMensajeDiario()
const MASCOT_MSGS = [
  '¡Hola! 🌿 Registra tus gastos hoy y mantén tu racha.',
  '💡 Tip: Guarda al menos el 20% de tus ingresos.',
  '🎉 ¡Vas genial! Sigue así y llega al próximo nivel.',
  '⚠️ ¿Revisaste tu presupuesto esta semana?',
  '🌟 Cada sol ahorrado cuenta. ¡Tú puedes!',
  '📊 Mira tus estadísticas — ¡aprendes más de lo que crees!',
];

@Component({
  selector:    'app-sidebar',
  standalone:  true,
  imports:     [CommonModule, RouterModule],
  templateUrl: './sidebar.html',
  styleUrl:    './sidebar.scss'
})
export class Sidebar implements OnInit {

modalPlanesAbierto = signal(false);
comprandoPlan = signal(false);

abrirModalPlanes(): void {
  this.modalPlanesAbierto.set(true);
}

cerrarModalPlanes(): void {
  this.modalPlanesAbierto.set(false);
}

comprarPlan(plan: 'PRO' | 'PREMIUM'): void {
  if (this.comprandoPlan()) return;
  this.comprandoPlan.set(true);

  this.suscripcionService.crearSesionCheckout(plan)
    .subscribe({
      next: (sesion) => {
        this.comprandoPlan.set(false);
        if (sesion && sesion.urlCheckout) {
          window.location.href = sesion.urlCheckout;
        } else {
          console.error('No se recibió la URL de Stripe Checkout');
        }
      },
      error: (err) => {
        this.comprandoPlan.set(false);
        console.error('Error al iniciar Checkout de Stripe:', err);
      }
    });
}





  // TODO: reemplazar con MenuService.getNavItems(usuarioRol)
  navItems = [
    ...NAV_ITEMS,
    { route: '/perfil/historial', label: 'Historial', icon: 'fa-solid fa-clock-rotate-left' }
  ];
  bottomNavItems = BOTTOM_NAV_ITEMS;

  // ── Mascota —  usar showMascotMsg() y mascotMsg() ──
  showMascotMsg = signal(false);
  mascotMsg     = signal('');

  // TODO: obtener desde GamificacionService

  rachaActual = 14;   // mock
  metaRacha   = 30;   // mock

// dentro de la clase, agrega:
isPerfilSection = false;

readonly perfilNavItems = [
  { route: '/perfil/cliente',       label: 'Perfil Cliente',    icon: 'fa-solid fa-user' },
  { route: '/perfil/financiero',    label: 'Perfil Financiero', icon: 'fa-solid fa-chart-pie' },
  { route: '/perfil/configuracion', label: 'Configuración',     icon: 'fa-solid fa-gear' },
  { route: '/ayuda',               label: 'Ayuda',             icon: 'fa-solid fa-circle-question' },
];

  constructor(
    private router: Router,
    public auth:         AuthService,
    public sidebarState: SidebarStateService,
    private suscripcionService: SuscripcionService
  ) {
    this.router.events
      .pipe(filter(e => e instanceof NavigationEnd))
      .subscribe((e: any) => {
        this.isPerfilSection = (e.url.startsWith('/perfil') && !e.url.startsWith('/perfil/historial'))
          || e.url.startsWith('/suscripcion/luka')
          || e.url.startsWith('/ayuda');
      });
  }

  ngOnInit(): void {
    // Muestra mensaje automático al cargar (después de 2s)
    // TODO: traer mensaje desde MascotaService en lugar del array local
    setTimeout(() => {
      this.mostrarMensajeAleatorio();
      this.showMascotMsg.set(true);
      // Auto-ocultar después de 5s
      setTimeout(() => this.showMascotMsg.set(false), 5000);
    }, 2000);
  }

  toggle(): void {
    this.sidebarState.toggle();
  }

  closeMobile(): void {
    this.sidebarState.closeMobile();
  }

  onNavClick(): void {
    this.sidebarState.closeMobile();
  }

  toggleMascotMsg(): void {
    if (!this.showMascotMsg()) {
      this.mostrarMensajeAleatorio();
    }
    this.showMascotMsg.update(v => !v);
  }

  private mostrarMensajeAleatorio(): void {
    const idx = Math.floor(Math.random() * MASCOT_MSGS.length);
    this.mascotMsg.set(MASCOT_MSGS[idx]);
  }
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\layout\sidebar\sidebar\ia-panel\ia-panel.html

<!-- =============================================
     LUKA — IA Panel: Bloque completo autocontenido
     Diseñado para insertarse en sidebar.html sin tocar nada más
     ============================================= -->

<!-- ── BOTÓN DISPARADOR DEL PANEL IA ── -->
<div class="ia-trigger" (click)="togglePanel()" [class.ia-trigger--active]="panelAbierto()" [class.ia-trigger--collapsed]="!expanded">
  <div class="ia-trigger-left">
    <div class="ia-orb">
      <i class="fa-solid fa-microchip-ai"></i>
    </div>
    <div class="ia-trigger-info" *ngIf="expanded">
      <span class="ia-trigger-label">Inteligencia Artificial</span>
      <span class="ia-trigger-sub">{{ IA_MODULOS_COUNT }} módulos · Gemini Pro</span>
    </div>
  </div>
  <i *ngIf="expanded"
     class="fa-solid ia-chevron"
     [class.fa-chevron-down]="!panelAbierto()"
     [class.fa-chevron-up]="panelAbierto()">
  </i>
</div>

<!-- ── PANEL DESPLEGABLE ── -->
<div class="ia-panel" [class.ia-panel--open]="panelAbierto()">

  <!-- Cabecera del panel -->
  <div class="ia-panel-header">
    <div class="ia-panel-title-row">
      <span class="ia-panel-title">
        <i class="fa-solid fa-sparkles"></i> Centro de IA
      </span>
      <span class="ia-badge-gemini">Gemini Pro</span>
    </div>
    <p class="ia-panel-desc">
      El cerebro de Luka. Analiza tus finanzas en tiempo real con IA generativa.
    </p>
  </div>

  <!-- Tabs de filtro -->
  <div class="ia-tabs">
    <button
      *ngFor="let tab of tabs"
      class="ia-tab"
      [class.ia-tab--active]="tabActiva() === tab"
      (click)="cambiarTab(tab)"
    >
      <i [className]="tabIcons[tab]"></i>
      <span>{{ tab }}</span>
      <span class="ia-tab-count">{{ conteoPor(tab) }}</span>
    </button>
  </div>

  <!-- Lista de módulos -->
  <div class="ia-modulos-list">
    <button
      *ngFor="let m of modulosFiltrados()"
      class="ia-modulo-card"
      (click)="abrirModulo(m)"
    >
      <div class="ia-modulo-icon" [style.color]="m.tagColor">
        <i [className]="m.icon"></i>
      </div>
      <div class="ia-modulo-body">
        <span class="ia-modulo-nombre">{{ m.label }}</span>
        <span class="ia-modulo-desc">{{ m.descripcion }}</span>
      </div>
    </button>
  </div>

  <!-- Footer del panel -->
  <div class="ia-panel-footer">
    <i class="fa-solid fa-shield-check"></i>
    <span>Análisis con caché Redis · Auditoría AMQP</span>
  </div>

</div>


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\layout\sidebar\sidebar\ia-panel\ia-panel.scss

/* =============================================
   LUKA — IA Panel SCSS
   ============================================= */

// Acentos
$accent-cyan: #22d3ee;
$accent-purple: #a855f7;
$accent-emerald: #10b981;
$transition-smooth: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);

:host {
  display: block;
  width: 100%;
  max-width: 232px;
  box-sizing: border-box;
}

.ia-trigger {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 14px;
  margin: 4px 0;
  border-radius: var(--r-md, 12px);
  cursor: pointer;
  background: transparent;
  transition: $transition-smooth;
  border: 1px solid transparent;
  width: 100%;
  box-sizing: border-box;

  &:hover {
    background: var(--bg-hover, rgba(91, 106, 240, 0.05));
    border-color: var(--border-light, rgba(232, 234, 255, 0.5));

    .ia-orb {
      transform: scale(1.1);
      box-shadow: 0 0 12px rgba(34, 211, 238, 0.5);
    }
  }

  &--active {
    background: var(--bg-surface-soft, rgba(91, 106, 240, 0.08));
    border-color: rgba(34, 211, 238, 0.2);

    .ia-chevron {
      color: $accent-cyan;
    }
  }

  &--collapsed {
    justify-content: center;
    padding: 11px;
    margin: 4px auto;
    width: 44px;
    height: 44px;

    .ia-trigger-left {
      gap: 0;
      justify-content: center;
    }
  }
}

.ia-trigger-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.ia-orb {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background: linear-gradient(135deg, rgba(34, 211, 238, 0.2) 0%, rgba(168, 85, 247, 0.2) 100%);
  border: 1px solid rgba(34, 211, 238, 0.4);
  display: flex;
  align-items: center;
  justify-content: center;
  color: $accent-cyan;
  font-size: 0.9rem;
  transition: $transition-smooth;
  position: relative;

  // Pulsing dot inside
  &::after {
    content: '';
    position: absolute;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: $accent-cyan;
    top: 2px;
    right: 2px;
    box-shadow: 0 0 6px $accent-cyan;
    animation: orbPulse 1.8s infinite alternate ease-in-out;
  }
}

.ia-trigger-info {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  line-height: 1.2;
}

.ia-trigger-label {
  font-size: 0.88rem;
  font-weight: 700;
  color: var(--text-primary);
}

.ia-trigger-sub {
  font-size: 0.68rem;
  color: var(--text-muted);
}

.ia-chevron {
  font-size: 0.75rem;
  color: var(--text-muted);
  transition: $transition-smooth;
}

/* Panel Desplegable */
.ia-panel {
  max-height: 0;
  overflow: hidden;
  transition: $transition-smooth;
  opacity: 0;
  background: var(--bg-card, #ffffff);
  border-radius: var(--r-md, 12px);
  border: 1px solid transparent;
  padding: 0 10px;
  margin: 0 4px;
  max-width: 232px;
  box-sizing: border-box;

  &--open {
    max-height: 280px;
    opacity: 1;
    padding: 14px 10px;
    margin: 6px 4px 12px;
    border-color: var(--border-color, rgba(232, 234, 255, 0.8));
    box-shadow: var(--shadow-md, 0 10px 20px rgba(0,0,0,0.05));
    overflow-y: auto;
  }
}

.ia-panel-header {
  margin-bottom: 12px;
  padding-bottom: 8px;
  border-bottom: 1px solid var(--border-light, rgba(232, 234, 255, 0.5));
}

.ia-panel-title-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 4px;
}

.ia-panel-title {
  font-size: 0.82rem;
  font-weight: 800;
  color: var(--text-primary);
  display: flex;
  align-items: center;
  gap: 6px;
  text-transform: uppercase;
  letter-spacing: 0.05em;

  i {
    color: $accent-cyan;
    animation: starTwinkle 2s infinite alternate;
  }
}

.ia-badge-gemini {
  font-size: 0.6rem;
  font-weight: 800;
  padding: 2px 6px;
  border-radius: var(--r-full, 9999px);
  background: linear-gradient(135deg, rgba(34, 211, 238, 0.15) 0%, rgba(168, 85, 247, 0.15) 100%);
  border: 1px solid rgba(34, 211, 238, 0.25);
  color: $accent-cyan;
  text-transform: uppercase;
}

.ia-panel-desc {
  font-size: 0.72rem;
  color: var(--text-secondary);
  line-height: 1.3;
}

/* Tabs */
.ia-tabs {
  display: flex;
  gap: 4px;
  overflow-x: auto;
  margin-bottom: 12px;
  padding-bottom: 4px;
  scrollbar-width: none;

  &::-webkit-scrollbar {
    display: none;
  }
}

.ia-tab {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 6px 10px;
  font-size: 0.65rem;
  font-weight: 700;
  color: var(--text-secondary);
  border-radius: var(--r-sm, 6px);
  background: var(--bg-hover, rgba(0,0,0,0.02));
  border: 1px solid transparent;
  cursor: pointer;
  transition: $transition-smooth;

  i {
    font-size: 0.7rem;
  }

  &--active {
    background: var(--bg-surface-soft, rgba(91, 106, 240, 0.08));
    border-color: rgba(34, 211, 238, 0.25);
    color: $accent-cyan;

    .ia-tab-count {
      background: $accent-cyan;
      color: #020617;
    }
  }

  &:hover:not(&--active) {
    background: var(--bg-hover, rgba(91, 106, 240, 0.05));
    color: var(--text-primary);
  }
}

.ia-tab-count {
  font-size: 0.55rem;
  font-weight: 800;
  padding: 1px 4px;
  border-radius: 4px;
  background: var(--border-color, rgba(232, 234, 255, 0.8));
  color: var(--text-secondary);
  transition: $transition-smooth;
}

/* Lista de Módulos */
.ia-modulos-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.ia-modulo-card {
  width: 100%;
  max-width: 212px;
  box-sizing: border-box;
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 8px 10px;
  border-radius: var(--r-md, 10px);
  background: var(--bg-card, #ffffff);
  border: 1px solid var(--border-light, rgba(232, 234, 255, 0.4));
  text-align: left;
  cursor: pointer;
  transition: $transition-smooth;

  &:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.04);
    border-color: rgba(34, 211, 238, 0.25);
    background: var(--bg-hover, rgba(91, 106, 240, 0.02));
  }
}

.ia-modulo-icon {
  width: 28px;
  height: 28px;
  border-radius: 6px;
  background: rgba(255,255,255,0.05);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.85rem;
  flex-shrink: 0;
}

.ia-modulo-body {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.ia-modulo-nombre {
  font-size: 0.78rem;
  font-weight: 700;
  color: var(--text-primary);
}

.ia-modulo-desc {
  font-size: 0.65rem;
  color: var(--text-secondary);
  line-height: 1.2;
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.ia-modulo-tag {
  font-size: 0.52rem;
  font-weight: 800;
  padding: 1px 5px;
  border-radius: 4px;
  text-transform: uppercase;
  flex-shrink: 0;
}

.ia-panel-footer {
  margin-top: 12px;
  padding-top: 8px;
  border-top: 1px solid var(--border-light, rgba(232, 234, 255, 0.5));
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  font-size: 0.6rem;
  color: var(--text-muted);
}

// Animaciones
@keyframes orbPulse {
  0% {
    transform: scale(0.9);
    opacity: 0.7;
    box-shadow: 0 0 4px $accent-cyan;
  }
  100% {
    transform: scale(1.1);
    opacity: 1;
    box-shadow: 0 0 10px $accent-cyan, 0 0 16px rgba(34, 211, 238, 0.3);
  }
}

@keyframes starTwinkle {
  0% {
    opacity: 0.5;
    transform: scale(0.9) rotate(0deg);
  }
  100% {
    opacity: 1;
    transform: scale(1.1) rotate(15deg);
  }
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\layout\sidebar\sidebar\ia-panel\ia-panel.ts

// =============================================
// LUKA — IA Panel Component (Standalone)
// Módulo de Inteligencia Artificial en el Sidebar
// NO modifica ningún archivo existente del equipo.
// =============================================
import { Component, Input, signal, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';

export interface IaModulo {
  id:          string;
  label:       string;
  descripcion: string;
  icon:        string;
  tag:         'ANÁLISIS' | 'COACH' | 'CLASIFICACIÓN';
  tagColor:    string;
  endpoint:    string;
  filtroFecha: boolean;
  params?:     string[];
}

const IA_MODULOS: IaModulo[] = [
  // ─── Grupo ANÁLISIS ──────────────────────────────────
  {
    id:          'gasto-hormiga',
    label:       'Gasto Hormiga',
    descripcion: 'Detecta pequeños gastos recurrentes que erosionan tu presupuesto.',
    icon:        'fa-solid fa-bug',
    tag:         'ANÁLISIS',
    tagColor:    '#f59e0b',
    endpoint:    '/api/v1/ia/gasto-hormiga',
    filtroFecha: true,
  },
  {
    id:          'predecir-gastos',
    label:       'Predicción de Gastos',
    descripcion: 'Proyecta tus gastos futuros con base en tus patrones históricos.',
    icon:        'fa-solid fa-chart-line',
    tag:         'ANÁLISIS',
    tagColor:    '#f59e0b',
    endpoint:    '/api/v1/ia/predecir-gastos',
    filtroFecha: true,
  },
  {
    id:          'habitos-financieros',
    label:       'Hábitos Financieros',
    descripcion: 'Evalúa la calidad de tus hábitos de ahorro y gasto.',
    icon:        'fa-solid fa-brain',
    tag:         'ANÁLISIS',
    tagColor:    '#f59e0b',
    endpoint:    '/api/v1/ia/habitos-financieros',
    filtroFecha: true,
  },
  {
    id:          'estilo-vida',
    label:       'Estilo de Vida',
    descripcion: 'Analiza si tus finanzas reflejan el estilo de vida que deseas.',
    icon:        'fa-solid fa-person-walking',
    tag:         'ANÁLISIS',
    tagColor:    '#f59e0b',
    endpoint:    '/api/v1/ia/estilo-vida',
    filtroFecha: true,
  },
  {
    id:          'reporte-completo',
    label:       'Reporte Ejecutivo',
    descripcion: 'Informe 360° que combina todos los módulos de análisis.',
    icon:        'fa-solid fa-file-chart-column',
    tag:         'ANÁLISIS',
    tagColor:    '#f59e0b',
    endpoint:    '/api/v1/ia/reporte-completo',
    filtroFecha: true,
  },
  // ─── Grupo COACH ─────────────────────────────────────
  {
    id:          'simular-meta',
    label:       'Simular Meta',
    descripcion: 'Simula cuánto tiempo necesitas para alcanzar una meta de ahorro.',
    icon:        'fa-solid fa-bullseye-arrow',
    tag:         'COACH',
    tagColor:    '#10b981',
    endpoint:    '/api/v1/ia/simular-meta',
    filtroFecha: false,
    params:      ['nombre_meta', 'monto_objetivo', 'aporte_mensual_deseado'],
  },
  {
    id:          'reto-ahorro',
    label:       'Reto de Ahorro',
    descripcion: 'Genera un plan de reto personalizado para mejorar tu ahorro.',
    icon:        'fa-solid fa-trophy',
    tag:         'COACH',
    tagColor:    '#10b981',
    endpoint:    '/api/v1/ia/reto-ahorro',
    filtroFecha: true,
  },
  // ─── Grupo CLASIFICACIÓN ─────────────────────────────
  {
    id:          'clasificar-transaccion',
    label:       'Auto-Clasificar',
    descripcion: 'Sugiere categorías para tus transacciones usando IA Gemini.',
    icon:        'fa-solid fa-tags',
    tag:         'CLASIFICACIÓN',
    tagColor:    '#8b5cf6',
    endpoint:    '/api/v1/ia/clasificar-transaccion',
    filtroFecha: false,
    params:      ['descripcion', 'monto'],
  },
];

type TabGroup = 'TODOS' | 'ANÁLISIS' | 'COACH' | 'CLASIFICACIÓN';

@Component({
  selector:    'app-ia-panel',
  standalone:  true,
  imports:     [CommonModule, RouterModule],
  templateUrl: './ia-panel.html',
  styleUrl:    './ia-panel.scss',
})
export class IaPanelComponent {
  private _expanded = true;
  @Input() set expanded(val: boolean) {
    this._expanded = val;
    if (!val) {
      this.panelAbierto.set(false);
    }
  }
  get expanded(): boolean {
    return this._expanded;
  }

  private router = inject(Router);
  IA_MODULOS_COUNT = 8;

  // ── Estado del panel ──────────────────────────────────────────────────
  panelAbierto   = signal(false);
  moduloActivo   = signal<IaModulo | null>(null);
  modalAbierto   = signal(false);
  tabActiva      = signal<TabGroup>('TODOS');
  fechaInicio    = signal('');
  fechaFin       = signal('');
  cargando       = signal(false);
  resultadoMock  = signal('');

  // ── Tabs ──────────────────────────────────────────────────────────────
  tabs: TabGroup[] = ['TODOS', 'ANÁLISIS', 'COACH', 'CLASIFICACIÓN'];

  tabIcons: Record<TabGroup, string> = {
    'TODOS':          'fa-solid fa-layer-group',
    'ANÁLISIS':       'fa-solid fa-magnifying-glass-chart',
    'COACH':          'fa-solid fa-graduation-cap',
    'CLASIFICACIÓN':  'fa-solid fa-tags',
  };

  // ── Módulos filtrados ─────────────────────────────────────────────────
  modulosFiltrados = computed(() => {
    const tab = this.tabActiva();
    return tab === 'TODOS' ? IA_MODULOS : IA_MODULOS.filter(m => m.tag === tab);
  });

  // Conteo por grupo
  conteoPor = (tag: string) =>
    tag === 'TODOS' ? IA_MODULOS.length : IA_MODULOS.filter(m => m.tag === tag).length;

  // ── Acciones ──────────────────────────────────────────────────────────
  togglePanel(): void {
    if (!this.expanded) {
      this.router.navigate(['/inteligencia-artificial']);
    } else {
      this.panelAbierto.update(v => !v);
    }
  }

  abrirModulo(modulo: IaModulo): void {
    // Cerrar panel del sidebar al navegar
    this.panelAbierto.set(false);
    // Redirigir a la página de IA con el módulo activo
    this.router.navigate(['/inteligencia-artificial'], { queryParams: { modulo: modulo.id } });
  }

  cerrarModal(): void {
    this.modalAbierto.set(false);
    this.moduloActivo.set(null);
  }

  cambiarTab(tab: TabGroup): void {
    this.tabActiva.set(tab);
  }

  // ── Simular consulta (estático por ahora) ─────────────────────────────
  ejecutarConsulta(): void {
    this.cargando.set(true);
    this.resultadoMock.set('');
    // Simulación de respuesta de Gemini (estático por ahora)
    setTimeout(() => {
      this.cargando.set(false);
      this.resultadoMock.set(this._generarRespuestaMock(this.moduloActivo()!));
    }, 1800);
  }

  private _generarRespuestaMock(modulo: IaModulo): string {
    const respuestas: Record<string, string> = {
      'gasto-hormiga':        '🐜 **Detectamos 8 gastos hormiga** en los últimos 30 días. El café diario (S/. 7 × 22 días = **S/. 154**) es tu mayor fuga invisible. Redirige ese monto a tu meta de emergencia.',
      'predecir-gastos':      '📈 **Proyección del próximo mes:** S/. 2,340. Tus gastos en entretenimiento crecen +18% vs. promedio. Considera establecer un límite de S/. 200 en esa categoría.',
      'habitos-financieros':  '🧠 **Puntuación de hábitos: 72/100 (Bueno)**. Fortaleza: constancia en registro de gastos. Área de mejora: el 34% de tus compras son impulsivas los viernes.',
      'estilo-vida':          '🌿 **Tu perfil:** "Explorador Consciente". Gastas bien en experiencias pero descuidas el ahorro estructurado. Recomendamos el método 50/30/20.',
      'reporte-completo':     '📊 **Reporte Ejecutivo — Mayo 2026**: Ingresos S/. 3,200 | Gastos S/. 2,480 | Ahorro neto: S/. 720 (22.5%). ✅ Meta de ahorro alcanzada. 3 alertas de gasto hormiga activas.',
      'simular-meta':         '🎯 **Meta: Laptop gamer S/. 3,500**. Con tu aporte de S/. 350/mes la logras en **10 meses** (Mar 2027). Si ahorras S/. 500/mes, la alcanzas en 7 meses.',
      'reto-ahorro':          '🏆 **Reto 30 días activo**: Semana 1: no-cafeterías. Semana 2: cocina en casa 4 días. Semana 3: revisar suscripciones. Semana 4: reto de los S/. 5 diarios.',
      'clasificar-transaccion':'🏷️ **Sugerencias de categoría**: "RAPPI S/. 45" → 🍔 Alimentación (92% confianza) | "Netflix S/. 35" → 🎬 Suscripciones (99%) | "UBER S/. 22" → 🚗 Transporte (88%)',
    };
    return respuestas[modulo.id] ?? '✅ Análisis completado exitosamente por Gemini Pro.';
  }
}
