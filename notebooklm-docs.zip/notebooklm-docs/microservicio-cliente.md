﻿Resolving context...
Initializing services and database connection...
Services initialized.
[
  {
    "c.name": "MicroservicioClienteApplication",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/MicroservicioClienteApplication.java",
    "c.docstring": null
  },
  {
    "c.name": "EscuchaSincronizacionIA",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/aplicacion/eventos/EscuchaSincronizacionIA.java",
    "c.docstring": null
  },
  {
    "c.name": "EventoContextoActualizado",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/aplicacion/eventos/EventoContextoActualizado.java",
    "c.docstring": null
  },
  {
    "c.name": "ClienteNoEncontradoException",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/aplicacion/excepciones/ClienteNoEncontradoException.java",
    "c.docstring": null
  },
  {
    "c.name": "DatosPersonalesNoEncontradosException",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/aplicacion/excepciones/DatosPersonalesNoEncontradosException.java",
    "c.docstring": null
  },
  {
    "c.name": "DniDuplicadoException",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/aplicacion/excepciones/DniDuplicadoException.java",
    "c.docstring": null
  },
  {
    "c.name": "LimiteGastoException",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/aplicacion/excepciones/LimiteGastoException.java",
    "c.docstring": null
  },
  {
    "c.name": "LimiteGastoNoEncontradoException",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/aplicacion/excepciones/LimiteGastoNoEncontradoException.java",
    "c.docstring": null
  },
  {
    "c.name": "MetaNoEncontradaException",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/aplicacion/excepciones/MetaNoEncontradaException.java",
    "c.docstring": null
  },
  {
    "c.name": "ContextoMapper",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/aplicacion/mappers/ContextoMapper.java",
    "c.docstring": null
  },
  {
    "c.name": "ServicioContextoImpl",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/aplicacion/servicios/ServicioContextoImpl.java",
    "c.docstring": null
  },
  {
    "c.name": "ServicioDatosPersonalesImpl",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/aplicacion/servicios/ServicioDatosPersonalesImpl.java",
    "c.docstring": null
  },
  {
    "c.name": "ServicioLimiteGastoImpl",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/aplicacion/servicios/ServicioLimiteGastoImpl.java",
    "c.docstring": null
  },
  {
    "c.name": "ServicioMetaAhorroImpl",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/aplicacion/servicios/ServicioMetaAhorroImpl.java",
    "c.docstring": null
  },
  {
    "c.name": "ServicioPerfilFinancieroImpl",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/aplicacion/servicios/ServicioPerfilFinancieroImpl.java",
    "c.docstring": null
  },
  {
    "c.name": "BandejaSalidaAuditoria",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/dominio/entidades/BandejaSalidaAuditoria.java",
    "c.docstring": null
  },
  {
    "c.name": "DatosPersonales",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/dominio/entidades/DatosPersonales.java",
    "c.docstring": null
  },
  {
    "c.name": "LimiteGasto",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/dominio/entidades/LimiteGasto.java",
    "c.docstring": null
  },
  {
    "c.name": "MetaAhorro",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/dominio/entidades/MetaAhorro.java",
    "c.docstring": null
  },
  {
    "c.name": "PerfilFinanciero",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/dominio/entidades/PerfilFinanciero.java",
    "c.docstring": null
  },
  {
    "c.name": "ConfiguracionAsync",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/infraestructura/configuracion/ConfiguracionAsync.java",
    "c.docstring": null
  },
  {
    "c.name": "PropiedadesInfraestructura",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/infraestructura/configuracion/PropiedadesInfraestructura.java",
    "c.docstring": null
  },
  {
    "c.name": "NucleoFinanciero",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/infraestructura/configuracion/PropiedadesInfraestructura.java",
    "c.docstring": null
  },
  {
    "c.name": "PropiedadesJwt",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/infraestructura/configuracion/PropiedadesJwt.java",
    "c.docstring": null
  },
  {
    "c.name": "ConfiguracionRabbitMQ",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/infraestructura/mensajeria/ConfiguracionRabbitMQ.java",
    "c.docstring": null
  },
  {
    "c.name": "PublicadorAmqpAsincrono",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/infraestructura/mensajeria/PublicadorAmqpAsincrono.java",
    "c.docstring": null
  },
  {
    "c.name": "PublicadorAuditoria",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/infraestructura/mensajeria/PublicadorAuditoria.java",
    "c.docstring": null
  },
  {
    "c.name": "PublicadorSincronizacionIA",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/infraestructura/mensajeria/PublicadorSincronizacionIA.java",
    "c.docstring": null
  },
  {
    "c.name": "ConfiguracionSeguridad",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/infraestructura/seguridad/ConfiguracionSeguridad.java",
    "c.docstring": null
  },
  {
    "c.name": "ServicioSeguridad",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/infraestructura/seguridad/ServicioSeguridad.java",
    "c.docstring": null
  },
  {
    "c.name": "TareaDesactivacionLimitesVencidos",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/infraestructura/tareas/TareaDesactivacionLimitesVencidos.java",
    "c.docstring": null
  },
  {
    "c.name": "TareaReintentadorAuditoria",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/infraestructura/tareas/TareaReintentadorAuditoria.java",
    "c.docstring": null
  },
  {
    "c.name": "ControladorInterno",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/presentacion/controladores/ControladorInterno.java",
    "c.docstring": null
  },
  {
    "c.name": "ControladorLimiteGasto",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/presentacion/controladores/ControladorLimiteGasto.java",
    "c.docstring": null
  },
  {
    "c.name": "ControladorMetaAhorro",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/presentacion/controladores/ControladorMetaAhorro.java",
    "c.docstring": null
  },
  {
    "c.name": "ControladorPerfil",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/presentacion/controladores/ControladorPerfil.java",
    "c.docstring": null
  },
  {
    "c.name": "ControladorPerfilFinanciero",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/presentacion/controladores/ControladorPerfilFinanciero.java",
    "c.docstring": null
  },
  {
    "c.name": "ManejadorGlobalExcepciones",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-cliente/src/main/ja
va/com/cliente/presentacion/manejadores/ManejadorGlobalExcepciones.java",
    "c.docstring": null
  }
]
