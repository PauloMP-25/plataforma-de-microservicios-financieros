﻿Resolving context...
Initializing services and database connection...
Services initialized.
[
  {
    "c.name": "MicroservicioMensajeriaApplication",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/MicroservicioMensajeriaApplication.java",
    "c.docstring": null
  },
  {
    "c.name": "CodigoExpiradoException",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/aplicacion/excepciones/CodigoExpiradoException.java",
    "c.docstring": null
  },
  {
    "c.name": "CodigoInvalidoException",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/aplicacion/excepciones/CodigoInvalidoException.java",
    "c.docstring": null
  },
  {
    "c.name": "CodigoPendienteNotFoundException",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/aplicacion/excepciones/CodigoPendienteNotFoundException.java",
    "c.docstring": null
  },
  {
    "c.name": "LimiteCodigosExcedidoException",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/aplicacion/excepciones/LimiteCodigosExcedidoException.java",
    "c.docstring": null
  },
  {
    "c.name": "LimiteIntentosExcedidoException",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/aplicacion/excepciones/LimiteIntentosExcedidoException.java",
    "c.docstring": null
  },
  {
    "c.name": "MensajeriaExternaException",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/aplicacion/excepciones/MensajeriaExternaException.java",
    "c.docstring": null
  },
  {
    "c.name": "TelefonoInvalidoException",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/aplicacion/excepciones/TelefonoInvalidoException.java",
    "c.docstring": null
  },
  {
    "c.name": "UsuarioBloqueadoExcepcion",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/aplicacion/excepciones/UsuarioBloqueadoExcepcion.java",
    "c.docstring": null
  },
  {
    "c.name": "FabricaCodigoVerificacion",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/aplicacion/fabricas/FabricaCodigoVerificacion.java",
    "c.docstring": null
  },
  {
    "c.name": "EmailServiceImpl",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/aplicacion/servicios/EmailServiceImpl.java",
    "c.docstring": null
  },
  {
    "c.name": "MensajeriaServiceAuditoriaDecorator",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/aplicacion/servicios/MensajeriaServiceAuditoriaDecorator.java",
    "c.docstring": null
  },
  {
    "c.name": "MensajeriaServiceImpl",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/aplicacion/servicios/MensajeriaServiceImpl.java",
    "c.docstring": null
  },
  {
    "c.name": "NotificacionDispatcherImpl",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/aplicacion/servicios/NotificacionDispatcherImpl.java",
    "c.docstring": null
  },
  {
    "c.name": "SmsServiceImpl",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/aplicacion/servicios/SmsServiceImpl.java",
    "c.docstring": null
  },
  {
    "c.name": "ThrottlingServiceImpl",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/aplicacion/servicios/ThrottlingServiceImpl.java",
    "c.docstring": null
  },
  {
    "c.name": "WhatsAppServiceImpl",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/aplicacion/servicios/WhatsAppServiceImpl.java",
    "c.docstring": null
  },
  {
    "c.name": "ValidadorBloqueo",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/aplicacion/servicios/validadores/ValidadorBloqueo.java",
    "c.docstring": null
  },
  {
    "c.name": "ValidadorCanal",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/aplicacion/servicios/validadores/ValidadorCanal.java",
    "c.docstring": null
  },
  {
    "c.name": "ValidadorLimiteDiario",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/aplicacion/servicios/validadores/ValidadorLimiteDiario.java",
    "c.docstring": null
  },
  {
    "c.name": "ValidadorThrottling",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/aplicacion/servicios/validadores/ValidadorThrottling.java",
    "c.docstring": null
  },
  {
    "c.name": "BandejaSalidaMensajeria",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/dominio/entidades/BandejaSalidaMensajeria.java",
    "c.docstring": null
  },
  {
    "c.name": "CodigoVerificacion",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/dominio/entidades/CodigoVerificacion.java",
    "c.docstring": null
  },
  {
    "c.name": "IntentoValidacion",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/dominio/entidades/IntentoValidacion.java",
    "c.docstring": null
  },
  {
    "c.name": "MensajeriaSpecs",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/dominio/especificaciones/MensajeriaSpecs.java",
    "c.docstring": null
  },
  {
    "c.name": "ClienteActualizarTelefonoFallback",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/clientes/ClienteActualizarTelefonoFallback.java",
    "c.docstring": null
  },
  {
    "c.name": "ClienteUsuarioFallback",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/clientes/ClienteUsuarioFallback.java",
    "c.docstring": null
  },
  {
    "c.name": "ConfiguracionGeneral",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/configuracion/ConfiguracionGeneral.java",
    "c.docstring": null
  },
  {
    "c.name": "PropiedadesEmail",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/configuracion/PropiedadesEmail.java",
    "c.docstring": null
  },
  {
    "c.name": "Nombre",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/configuracion/PropiedadesEmail.java",
    "c.docstring": null
  },
  {
    "c.name": "PropiedadesJwt",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/configuracion/PropiedadesJwt.java",
    "c.docstring": null
  },
  {
    "c.name": "PropiedadesOtp",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/configuracion/PropiedadesOtp.java",
    "c.docstring": null
  },
  {
    "c.name": "PropiedadesTwilio",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/configuracion/PropiedadesTwilio.java",
    "c.docstring": null
  },
  {
    "c.name": "Account",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/configuracion/PropiedadesTwilio.java",
    "c.docstring": null
  },
  {
    "c.name": "Phone",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/configuracion/PropiedadesTwilio.java",
    "c.docstring": null
  },
  {
    "c.name": "Auth",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/configuracion/PropiedadesTwilio.java",
    "c.docstring": null
  },
  {
    "c.name": "ApiKey",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/configuracion/PropiedadesTwilio.java",
    "c.docstring": null
  },
  {
    "c.name": "Whatsapp",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/configuracion/PropiedadesTwilio.java",
    "c.docstring": null
  },
  {
    "c.name": "TwilioInitializer",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/configuracion/TwilioInitializer.java",
    "c.docstring": null
  },
  {
    "c.name": "ConfiguracionRabbitMQ",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/mensajeria/ConfiguracionRabbitMQ.java",
    "c.docstring": null
  },
  {
    "c.name": "PublicadorAuditoria",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/mensajeria/PublicadorAuditoria.java",
    "c.docstring": null
  },
  {
    "c.name": "ConsumidorEmail",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/mensajeria/consumidores/ConsumidorEmail.java",
    "c.docstring": null
  },
  {
    "c.name": "ConsumidorEventoPago",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/mensajeria/consumidores/ConsumidorEventoPago.java",
    "c.docstring": null
  },
  {
    "c.name": "ConsumidorOtp",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/mensajeria/consumidores/ConsumidorOtp.java",
    "c.docstring": null
  },
  {
    "c.name": "GmailHealthIndicator",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/salud/GmailHealthIndicator.java",
    "c.docstring": null
  },
  {
    "c.name": "TwilioHealthIndicator",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/salud/TwilioHealthIndicator.java",
    "c.docstring": null
  },
  {
    "c.name": "ConfiguracionSeguridad",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/seguridad/ConfiguracionSeguridad.java",
    "c.docstring": null
  },
  {
    "c.name": "TareaDesbloqueoUsuarios",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/tareas/TareaDesbloqueoUsuarios.java",
    "c.docstring": null
  },
  {
    "c.name": "TareaLimpiezaMensajeria",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/tareas/TareaLimpiezaMensajeria.java",
    "c.docstring": null
  },
  {
    "c.name": "TareaReintentadorAuditoria",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/infraestructura/tareas/TareaReintentadorAuditoria.java",
    "c.docstring": null
  },
  {
    "c.name": "ControladorAdminMensajeria",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/presentacion/controladores/ControladorAdminMensajeria.java",
    "c.docstring": null
  },
  {
    "c.name": "ControladorMensajeria",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/presentacion/controladores/ControladorMensajeria.java",
    "c.docstring": null
  },
  {
    "c.name": "ManejadorGlobalExcepciones",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/java/com/mensajeria/presentacion/excepciones/ManejadorGlobalExcepciones.java",
    "c.docstring": null
  },
  {
    "c.name": "otp-box",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/resources/templates/activacion-cuenta.html",
    "c.docstring": null
  },
  {
    "c.name": "container",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/resources/templates/layout-base.html",
    "c.docstring": null
  },
  {
    "c.name": "header",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/resources/templates/layout-base.html",
    "c.docstring": null
  },
  {
    "c.name": "footer",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/resources/templates/layout-base.html",
    "c.docstring": null
  },
  {
    "c.name": "content",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/resources/templates/layout-base.html",
    "c.docstring": null
  },
  {
    "c.name": "warning",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/resources/templates/recuperacion-password.html",
    "c.docstring": null
  },
  {
    "c.name": "otp-box",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-mensajeria/src/main
/resources/templates/recuperacion-password.html",
    "c.docstring": null
  }
]
