﻿Resolving context...
Initializing services and database connection...
Services initialized.
[
  {
    "c.name": "MicroservicioNucleoFinancieroApplication",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/MicroservicioNucleoFinancieroApplication.java",
    "c.docstring": null
  },
  {
    "c.name": "CategoriaMapper",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/aplicacion/mappers/CategoriaMapper.java",
    "c.docstring": null
  },
  {
    "c.name": "TransaccionMapper",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/aplicacion/mappers/TransaccionMapper.java",
    "c.docstring": null
  },
  {
    "c.name": "CategoriaServiceImpl",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/aplicacion/servicios/CategoriaServiceImpl.java",
    "c.docstring": null
  },
  {
    "c.name": "ServicioIaImpl",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/aplicacion/servicios/ServicioIaImpl.java",
    "c.docstring": null
  },
  {
    "c.name": "TransaccionServiceImpl",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/aplicacion/servicios/TransaccionServiceImpl.java",
    "c.docstring": null
  },
  {
    "c.name": "Categoria",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/dominio/entidades/Categoria.java",
    "c.docstring": null
  },
  {
    "c.name": "Transaccion",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/dominio/entidades/Transaccion.java",
    "c.docstring": null
  },
  {
    "c.name": "TransaccionSpecs",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/dominio/especificaciones/TransaccionSpecs.java",
    "c.docstring": null
  },
  {
    "c.name": "CargadorDatosIniciales",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/infraestructura/configuracion/CargadorDatosIniciales.java",
    "c.docstring": null
  },
  {
    "c.name": "ConfiguracionGeneral",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/infraestructura/configuracion/ConfiguracionGeneral.java",
    "c.docstring": null
  },
  {
    "c.name": "ConfiguracionRabbitMQ",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/infraestructura/configuracion/ConfiguracionRabbitMQ.java",
    "c.docstring": null
  },
  {
    "c.name": "ConfiguracionSeguridad",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/infraestructura/configuracion/ConfiguracionSeguridad.java",
    "c.docstring": null
  },
  {
    "c.name": "PropiedadesInfraestructura",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/infraestructura/configuracion/PropiedadesInfraestructura.java",
    "c.docstring": null
  },
  {
    "c.name": "PropiedadesJwt",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/infraestructura/configuracion/PropiedadesJwt.java",
    "c.docstring": null
  },
  {
    "c.name": "ConsumidorEventoPago",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/infraestructura/mensajeria/ConsumidorEventoPago.java",
    "c.docstring": null
  },
  {
    "c.name": "PublicadorAuditoria",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/infraestructura/mensajeria/PublicadorAuditoria.java",
    "c.docstring": null
  },
  {
    "c.name": "TareaDiagnosticoBalance",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/infraestructura/tareas/TareaDiagnosticoBalance.java",
    "c.docstring": null
  },
  {
    "c.name": "CategoriaController",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/presentacion/controladores/CategoriaController.java",
    "c.docstring": null
  },
  {
    "c.name": "IaController",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/presentacion/controladores/IaController.java",
    "c.docstring": null
  },
  {
    "c.name": "TransaccionController",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/presentacion/controladores/TransaccionController.java",
    "c.docstring": null
  },
  {
    "c.name": "ManejadorGlobalExcepciones",
    "c.path": 
"D:/CURSOS/7MO/INTEGRADOR/plataforma-de-microservicios-financieros/estructura-backend/microservicio-nucleo-financiero/s
rc/main/java/com/nucleo/financiero/presentacion/excepciones/ManejadorGlobalExcepciones.java",
    "c.docstring": null
  }
]
