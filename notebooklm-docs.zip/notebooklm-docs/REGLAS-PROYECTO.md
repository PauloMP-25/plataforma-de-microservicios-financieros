**Documento de Reglas y Convenciones del Proyecto LUKA**

Este documento define los estándares arquitectónicos, patrones de diseño y convenciones de nomenclatura utilizados en la plataforma LUKA, sirviendo como contexto base para el desarrollo.

### 1. Estructura de Carpetas y Nomenclatura

**Backend (Java Spring Boot - Arquitectura por Capas/Hexagonal):**
Cada microservicio sigue una estructura modular estricta dividida en cuatro capas principales:
*   **`aplicacion/`**: Contiene los casos de uso del negocio. Incluye `servicios/` (implementaciones), `mappers/` (conversión Entidad-DTO), `excepciones/` específicas del módulo y `eventos/`.
*   **`dominio/`**: El núcleo puro. Contiene `entidades/` (modelos JPA), `repositorios/` (interfaces) y `especificaciones/` (filtros de búsqueda).
*   **`infraestructura/`**: Detalles técnicos externos. Incluye `configuracion/` (RabbitMQ, Redis, Seguridad), `mensajeria/` (Productores/Consumidores AMQP), `tareas/` (ShedLock, CRON) y `clientes/` (Feign Clients o integraciones externas).
*   **`presentacion/`**: Puertos de entrada. Contiene `controladores/` (endpoints REST) y `manejadores/` (`ManejadorGlobalExcepciones` con `@ControllerAdvice`).
*   *Convención de nombres:* Clases en **PascalCase** (`ServicioContextoImpl`, `ControladorPerfil`). Paquetes en **minúsculas** sin caracteres especiales.

**Frontend (Angular 17+ - Arquitectura basada en Features):**
*   **`core/`**: Código singleton de uso global. Contiene `models/` (interfaces centralizadas), `services/` (lógica de acceso a datos y estado global) y `interceptors/`.
*   **`features/`**: Módulos independientes por dominio del negocio (ej. `admin`, `autenticacion`, `dashboard`, `gastos`, `metas`). Cada feature tiene sus propias subcarpetas de `components/`, `pages/`, `services/` y su archivo de rutas (`*.routes.ts`).
*   **`layout/`**: Componentes de estructura principal como `header`, `sidebar` y el `layout` base.
*   **`shared/`**: Componentes reutilizables a lo largo de múltiples features (ej. modales genéricos).
*   *Convención de nombres:* Archivos y carpetas en **kebab-case** (`perfil-cliente.component.ts`), Clases en **PascalCase** (`PerfilCliente`), Standalone components por defecto.

### 2. Conexión Frontend - Backend

*   **Patrón HTTP y URLs Base:** El frontend utiliza `HttpClient` inyectado en los servicios del directorio `core/services/`. Las peticiones se dirigen siempre al **API Gateway** usando una variable de entorno y un prefijo versionado: `environment.gatewayUrl + '/api/v1/[modulo]'`. Ejemplos: `/api/v1/auth`, `/api/v1/clientes/metas`, `/api/v1/financiero/transacciones`.
*   **Autenticación y Headers JWT:** El token JWT se almacena en el `localStorage` (`luka_token`). Existe un **`jwtInterceptor`** en Angular que intercepta cada petición saliente y adjunta automáticamente el header **`Authorization: Bearer ${token}`** si el usuario está logueado.
*   **Estandarización de Respuestas:** El backend siempre envuelve las respuestas exitosas en una estructura global llamada **`ResultadoApi<T>`**, que contiene los campos: `exito` (boolean), `estado` (number), `mensaje` (string), `datos` (T) y opcionalmente `pagina`. En el frontend, se suele mapear la respuesta para extraer directamente la propiedad `datos` usando `pipe(map(res => res.datos))`.

### 3. Patrones de Servicios Angular Más Usados

*   **Estado Reactivo con Signals:** El proyecto ha migrado de RxJS (Subjects/BehaviorSubjects) a **Angular Signals** (`signal`, `computed`, `effect`) para el manejo del estado.
*   **Servicios de Estado (State Services):** Se utiliza el patrón de separar los servicios HTTP puros de los servicios de estado. Por ejemplo, `GastosStateService` o `DashboardStateService` mantienen signals estables (ej. `readonly resumen = signal<DashboardResumenDTO | null>(null);`) y manejan el caché local y la bandera de `cargando`, exponiendo los datos a los componentes sin que estos hagan las llamadas HTTP directamente.
*   **Gestión de Carga (Loading States):** Los servicios de estado siempre exponen un signal `cargando = signal<boolean>(false)` y un signal de `error = signal<string | null>(null)` para que la UI reaccione automáticamente.

### 4. Convenciones de Nombres en Español del Equipo

El equipo mantiene el código casi íntegramente en **español**:
*   **Sufijos de DTOs:** Los objetos de transferencia usan sufijos estrictos. Lo que ingresa desde el frontend se denomina `Solicitud...` o `...RequestDTO` (ej. `SolicitudLogin`, `TransaccionRequestDTO`). Lo que el backend devuelve se denomina `Respuesta...` o termina en `DTO` (ej. `RespuestaAutenticacion`, `TransaccionDTO`).
*   **Clases Backend:** Utilizan sufijos explícitos de su rol arquitectónico: `...Controlador` (o `Controller`), `...ServiceImpl`, `...Repositorio`, `Excepcion...` (ej. `ExcepcionRecursoNoEncontrado`), `Filtro...`.
*   **Métodos CRUD:** Se emplea la nomenclatura estándar en español: `crear...`, `actualizar...`, `eliminar...`, `obtener...` (para uno), `listar...` (para listas paginadas).
*   **Interfaces de Paginación:** Se utiliza la interfaz `Pagina<T>` o `PaginaDTO<T>` (con atributos `content`, `totalElements`, `totalPages`, `size`, `number`) para manejar grillas y listas.

### 5. Flujo Típico de una Petición (Angular a Microservicio Java)

1.  **Componente UI (Angular):** El usuario interactúa con la UI. El componente invoca un método de un servicio de estado (ej. `stateService.cargarDatos()`) o un servicio HTTP directo.
2.  **Interceptor (Angular):** La petición HTTP pasa por el `jwtInterceptor`, el cual extrae el JWT del `AuthService` e inyecta el header `Authorization: Bearer <token>`.
3.  **API Gateway (Java):** La petición llega al puerto del Gateway (ej. 8080). El `FiltroJwtGlobal` intercepta la solicitud, valida la firma del token contra una clave secreta y el `ConfiguracionSeguridadGateway` verifica si el endpoint exige autorización o es público.
4.  **Enrutamiento interno:** Si el token es válido, el Gateway aplica reglas de Rate Limiting (`FiltroCuotaIA`, `FiltroBloqueoIp`) y reenvía la petición al microservicio correspondiente usando balanceo de carga con Eureka (ej. microservicio-nucleo-financiero en el puerto 8085).
5.  **Microservicio - Seguridad Local:** La petición llega al microservicio destino. `ConfiguracionSeguridad` y el `FiltroJwt` local validan nuevamente la identidad y verifican si el usuario tiene el rol necesario (ej. `.hasAnyRole("FREE", "PREMIUM", "PRO")`).
6.  **Capa de Presentación (Controlador):** El `Controlador...` recibe la petición mapeada a un objeto `Solicitud...` y la delega a la capa de Aplicación.
7.  **Capa de Aplicación y Dominio:** El `Servicio...Impl` ejecuta la lógica de negocio, mapea el DTO a una Entidad (usando un `Mapper`), interactúa con el `Repositorio` para guardar en base de datos PostgreSQL, y opcionalmente publica eventos en RabbitMQ a través de la Bandeja de Salida (Outbox Pattern).
8.  **Respuesta hacia el Cliente:** El resultado se convierte de nuevo a DTO, se envuelve en un objeto `ResultadoApi<T>`, y retorna con un estado HTTP 200/201. El frontend recibe este JSON y actualiza sus Signals, repintando la UI reactivamente.