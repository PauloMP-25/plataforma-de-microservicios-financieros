﻿

## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\guards\auth.guard.ts

import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { map } from 'rxjs';

/**
 * Guard para proteger rutas que requieren autenticación.
 * Redirige al inicio si el usuario no ha autenticado su sesión.
 */
export const authGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  return authService.esperarInicializacion().pipe(
    map((logueado) => {
      if (logueado) {
        return true;
      }
      console.warn('[AuthGuard] Acceso denegado a ruta protegida:', state.url);
      router.navigate(['/']);
      return false;
    })
  );
};


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\guards\pending-changes.guard.ts

import { CanDeactivateFn } from '@angular/router';

/**
 * Interfaz que deben implementar los componentes que desean proteger
 * la pérdida accidental de datos no guardados al navegar fuera.
 */
export interface HasUnsavedChanges {
  hasUnsavedChanges(): boolean;
}

/**
 * Guard para impedir la navegación accidental si existen cambios sin guardar en un formulario.
 */
export const pendingChangesGuard: CanDeactivateFn<HasUnsavedChanges> = (component) => {
  if (component && component.hasUnsavedChanges && component.hasUnsavedChanges()) {
    return confirm('Tienes cambios sin guardar en el formulario. ¿Estás seguro de que deseas salir de esta página? Todo el progreso no guardado se perderá.');
  }
  return true;
};


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\guards\role.guard.ts

import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { map } from 'rxjs';

/**
 * Guard para proteger rutas restringidas por roles específicos.
 * Redirige al dashboard si el usuario no tiene los roles requeridos.
 */
export const roleGuard = (allowedRoles: string[]): CanActivateFn => {
  return (route, state) => {
    const authService = inject(AuthService);
    const router = inject(Router);

    return authService.esperarInicializacion().pipe(
      map((logueado) => {
        if (!logueado) {
          router.navigate(['/']);
          return false;
        }

        const usuario = authService.usuario();
        const hasRole = usuario?.roles?.some(r => allowedRoles.includes(r));
        if (hasRole) {
          return true;
        }

        console.warn('[RoleGuard] Rol no autorizado para la ruta:', state.url);
        router.navigate(['/dashboard']);
        return false;
      })
    );
  };
};


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\interceptors\sanitize.interceptor.ts

import { HttpInterceptorFn, HttpRequest, HttpHandlerFn, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';

/**
 * Interceptor global para desinfectar (sanitize) de forma sistemática y recursiva
 * todos los cuerpos de solicitud (JSON payloads) de tipo POST, PUT y PATCH.
 * Elimina etiquetas <script> y de marcado HTML para mitigar vulnerabilidades XSS.
 */
export const sanitizeInterceptor: HttpInterceptorFn = (req: HttpRequest<unknown>, next: HttpHandlerFn): Observable<HttpEvent<unknown>> => {
  if (req.body && (req.method === 'POST' || req.method === 'PUT' || req.method === 'PATCH')) {
    const sanitizedBody = sanitizeValue(req.body);
    const clonedReq = req.clone({ body: sanitizedBody });
    return next(clonedReq);
  }
  return next(req);
};

function sanitizeValue(val: any): any {
  if (val === null || val === undefined) {
    return val;
  }
  if (typeof val === 'string') {
    return sanitizeString(val);
  }
  if (Array.isArray(val)) {
    return val.map(item => sanitizeValue(item));
  }
  if (typeof val === 'object') {
    const sanitizedObj: any = {};
    for (const key in val) {
      if (Object.prototype.hasOwnProperty.call(val, key)) {
        sanitizedObj[key] = sanitizeValue(val[key]);
      }
    }
    return sanitizedObj;
  }
  return val;
}

function sanitizeString(str: string): string {
  if (!str) return str;
  // Eliminar etiquetas <script> y sus contenidos
  let sanitized = str.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
  // Eliminar cualquier otra etiqueta HTML (ej. <img src="..." onerror="..." /> o <div>)
  sanitized = sanitized.replace(/<[^>]+>/g, '');
  return sanitized;
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\index.ts

export * from './auth';
export * from './auditoria';
export * from './cliente';
export * from './financiero';
export * from './mensajeria';
export * from './shared';



## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\auditoria\auditoria.model.ts

import { PaginaDTO } from '../shared/pagina.model';

export type EstadoAcceso = 'EXITO' | 'FALLO';

export interface AuditoriaAccesoRequestDTO {
  usuarioId?: string;
  ipOrigen: string;
  navegador?: string;
  estado: EstadoAcceso;
  detalleError?: string;
  fecha?: string;
}

export interface AuditoriaAccesoDTO {
  id: string;
  usuarioId: string;
  ipOrigen: string;
  navegador: string;
  estado: EstadoAcceso;
  detalleError: string;
  fecha: string;
}

export interface AuditoriaTransaccionalRequestDTO {
  usuarioId: string;
  servicioOrigen: string;
  entidadAfectada: string;
  entidadId: string;
  valorAnterior?: string;
  valorNuevo?: string;
  fecha?: string;
}

export interface AuditoriaTransaccionalDTO {
  id: string;
  usuarioId: string;
  servicioOrigen: string;
  entidadAfectada: string;
  entidadId: string;
  valorAnterior: string;
  valorNuevo: string;
  fecha: string;
}

export interface RegistroAuditoriaRequestDTO {
  fechaHora?: string;
  nombreUsuario: string;
  accion: string;
  modulo: string;
  ipOrigen?: string;
  detalles?: string;
}

export interface RegistroAuditoriaDTO {
  id: string;
  fechaHora: string;
  usuario: string;
  accion: string;
  modulo: string;
  ipOrigen: string;
  detalles: string;
}

export interface RespuestaVerificacionIpDTO {
  bloqueada: boolean;
}

export type PaginaAuditoriaAcceso = PaginaDTO<AuditoriaAccesoDTO>;
export type PaginaAuditoriaTransaccional = PaginaDTO<AuditoriaTransaccionalDTO>;
export type PaginaRegistroAuditoria = PaginaDTO<RegistroAuditoriaDTO>;



## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\auditoria\index.ts

export * from './auditoria.model';



## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\auth\index.ts

export * from './user.model';



## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\auth\user.model.ts

// =============================================
// microservicio-usuarios  → puerto 8081
// microservicio-nucleo-financiero → puerto 8085
// =============================================

// ── Auth (microservicio-usuarios) ──
export interface SolicitudLogin {
  correo:   string;
  password: string;
}

export interface SolicitudRegistro {
  nombreUsuario:    string;
  correo:           string;
  password:         string;
  confirmarPassword: string;
}

export interface RespuestaAutenticacion {
  tokenAcceso:     string;
  refreshToken:    string;
  tipoToken:       string;   
  expiraEn:        number;
  refreshExpiraEn: number;
  idUsuario:       string;   
  nombreUsuario:   string;
  roles:           string[];
}

// ── Usuario en sesión ──
export interface UsuarioSesion {
  id:           string;
  nombreUsuario: string;
  roles:        string[];
  token:        string;
  refreshToken: string;
  expiraEn:     number;
}

export interface SolicitudRefreshToken {
  refreshToken: string;
}

// ── Recuperación de contraseña ──
export interface SolicitudRecuperacion {
  correo: string;
}

export interface SolicitudCambioPassword {
  passwordActual: string;
  nuevoPassword: string;
  confirmarPassword: string;
}

export interface ResultadoApi<T> {
  exito:   boolean;
  estado:  number;
  error?:  string;
  mensaje: string;
  datos:   T;
  pagina?: any;
}



## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\cliente\index.ts

export * from './meta-limite.model';
export * from './perfil-cliente.model';



## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\cliente\meta-limite.model.ts

export interface SolicitudMetaAhorro {
  nombre: string;
  montoObjetivo: number;
  montoActual?: number;
  fechaLimite: string;
  proposito?: string;
}

export interface Pagina<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  size: number;
  number: number;
}

export interface RespuestaMetaAhorro {
  id: string;
  nombre: string;
  montoObjetivo: number;
  montoActual: number;
  porcentajeProgreso: number;
  fechaLimite: string;
  completada: boolean;
  proposito?: string;
  fechaCreacion?: string;
  fechaActualizacion?: string;
}

export interface SolicitudLimiteGasto {
  montoLimite: number;
  porcentajeAlerta: number;
  fechaInicio: string;
  fechaFin: string;
}

export interface RespuestaLimiteGasto {
  id: string;
  usuarioId: string;
  montoLimite: number;
  porcentajeAlerta: number;
  fechaInicio: string;
  fechaFin: string;
  activo: boolean;
  fechaCreacion: string;
}



## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\cliente\perfil-cliente.model.ts

export interface SolicitudDatosPersonales {
  dni: string;
  nombres: string;
  apellidos: string;
  genero: string;
  edad: number;
  telefono: string;
  fotoPerfilUrl?: string;
  pais?: string;
  ciudad?: string;
}

export interface RespuestaDatosPersonales {
  dni: string;
  nombres: string;
  apellidos: string;
  genero: string;
  edad: number;
  telefono: string;
  fotoPerfilUrl: string;
  pais: string;
  ciudad: string;
  datosCompletos: boolean;
  fechaCreacion?: string;
  fechaActualizacion?: string;
}

export interface SolicitudPerfilFinanciero {
  ocupacion: string;
  ingresoMensual: number;
  estiloVida: string;
  tonoIA: string;
}

export interface RespuestaPerfilFinanciero {
  ocupacion: string;
  ingresoMensual: number;
  estiloVida: string;
  tonoIA: string;
  fechaCreacion?: string;
  fechaActualizacion?: string;
}



## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\dashboard\dashboard.model.ts

import { TransaccionDTO } from '../financiero/transaccion.model';

/**
 * Resumen consolidado avanzado para las tarjetas KPI del Dashboard V2.
 */
export interface DashboardResumenDTO {
  desde: string; // ISO LocalDateTime
  hasta: string; // ISO LocalDateTime
  tasaAhorro: number; // Porcentaje de ahorro
  gastoPromedioDiario: number; // Nuevo KPI
  cumplimientoPresupuesto: number; // % consumido
  proyeccionFinDeMes: number; // Balance proyectado
}

export interface CashflowPointDTO {
  mes: string;
  ingresos: number;
  gastos: number;
}

export interface CategoriaDistribucionDTO {
  categoria: string;
  total: number;
  porcentaje: number;
  color: string;
}



/** [NUEVO] Mapa de calor de gastos por día de semana */
export interface HeatmapPointDTO {
  dia: string; // Lunes, Martes, etc.
  intensidad: number; // 0-10 o monto
}

/** [NUEVO] Progreso de metas */
export interface MetaProgressDTO {
  nombre: string;
  objetivo: number;
  actual: number;
  porcentaje: number;
  color: string;
}

/** [NUEVO] Comparativa histórica mensual */
export interface ComparativaMensualDTO {
  mes: string;
  actual: number; // Gasto este año
  anterior: number; // Gasto el año pasado
}

/**
 * DTO contenedor principal (Enriquecido)
 */
export interface DashboardAnaliticaDTO {
  resumen: DashboardResumenDTO;
  flujoCaja: CashflowPointDTO[];
  distribucionGastos: CategoriaDistribucionDTO[];
  heatmap: HeatmapPointDTO[];
  metas: MetaProgressDTO[];
  comparativa: ComparativaMensualDTO[];
  transaccionesMetodo?: { metodo: string; cantidad: number; color: string }[];
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\financiero\categoria.model.ts


// ── Categoría (microservicio-nucleo-financiero) ──
export type TipoMovimiento = 'INGRESO' | 'GASTO';

export interface CategoriaDTO {
  id:          string;   // UUID
  nombre:      string;
  descripcion: string;
  icono:       string;
  tipo:        TipoMovimiento;
}

export interface CategoriaRequestDTO {
  nombre:      string;
  descripcion: string;
  icono:       string;
  tipo:        TipoMovimiento;
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\financiero\ia.model.ts

export type TipoSolicitudIa = 'TRANSACCION_RECIENTE' | 'CONSULTA_MODULO';

export type ModuloIa =
  | 'TRANSACCION_AUTOMATICA'
  | 'PREDICCION_GASTOS'
  | 'GASTO_HORMIGA'
  | 'AUTOCLASIFICACION'
  | 'COMPARACION_MENSUAL'
  | 'CAPACIDAD_AHORRO'
  | 'METAS_FINANCIERAS'
  | 'ANOMALIAS'
  | 'ESTACIONALIDAD'
  | 'PRESUPUESTO_DINAMICO'
  | 'REPORTE_COMPLETO'
  | 'HABITOS_FINANCIEROS'
  | 'RETO_AHORRO_DINAMICO'
  | 'ANALISIS_ESTILO_VIDA'
  | 'ESPEJO_TEMPORAL'
  | 'ZONA_ENTRENAMIENTO';

export interface SolicitudIaDTO {
  idUsuario: string;
  tipoSolicitud: TipoSolicitudIa;
  moduloSolicitado?: ModuloIa;
}

// ── DTOs de Entrada para ms-ia ──

export interface PeticionConFiltroFechaDTO {
  usuario_id?: string; // Autocompletado del JWT
  token?: string; // Autocompletado del JWT
  mes?: number; // 1-12
  anio?: number; // 2020-2100
  tamanio_pagina?: number; // 10-1000
  frecuencia?: 'SEMANAL' | 'QUINCENAL' | 'MENSUAL';
}

export interface PeticionSimularMetaDTO {
  usuario_id?: string;
  nombre_meta: string;
  monto_objetivo: number;
  monto_actual_ahorrado?: number;
  aporte_mensual_deseado?: number;
}

export interface PeticionComparacionDTO {
  rangoA_inicio: string;
  rangoA_fin: string;
  rangoB_inicio: string;
  rangoB_fin: string;
}

export interface SolicitudClasificacionDTO {
  id_temporal: string;
  tipo_movimiento: 'INGRESO' | 'GASTO';
  etiquetas?: string;
  notas?: string;
  descripcion?: string;
}

// ── DTOs de Salida de ms-ia ──

export interface PuntoGraficoIaDTO {
  etiqueta: string;
  valor: number;
  color?: string;
}

export interface MetadataGraficoIaDTO {
  tipoGrafico: string;
  titulo: string;
  datos: PuntoGraficoIaDTO[];
  datosAux?: PuntoGraficoIaDTO[];
  unidad?: string;
  metaLinea?: number;
}

export interface KpiWidgetDTO {
  valor: number;
  etiqueta: string;
  tendencia?: string; // "ALZA" | "BAJA" | "ESTABLE"
  variacion_porcentaje?: number;
  unidad?: string;
}

export interface RespuestaModuloDTO {
  id_respuesta: string;
  usuario_id: string;
  modulo: string;
  fecha_generacion: string;
  consejo: any | string | null;
  estado_coach: 'EXITOSO' | 'CUOTA_AGOTADA' | 'AUTH_ERROR' | 'TIMEOUT' | 'NO_DISPONIBLE';
  usando_fallback: boolean;
  insight: any; // Datos analíticos puros devueltos por Pandas
  grafico?: MetadataGraficoIaDTO;
  kpi?: KpiWidgetDTO;
}

export interface RespuestaClasificacionDTO {
  id_temporal: string;
  sugerencias: string[];
  usando_fallback: boolean;
}

// Compatibilidad heredada
export interface RespuestaIaDTO {
  id: string;
  idUsuario: string;
  consejoTexto: string;
  tipoModulo: string;
  fechaGeneracion: string;
  metadataGrafico?: MetadataGraficoIaDTO;
  kpiPrincipal?: number;
  kpiLabel?: string;
}

// ── Modelos Específicos para Módulo: Zona de Entrenamiento ──

export interface EjercicioEntrenamientoDTO {
  nombre: string;
  descripcion: string;
  duracion_dias: number;
  frecuencia: string;
  metrica_exito: string;
}

export interface ConsejoEntrenamientoDTO {
  pensamiento_interno_ia: string;
  estado_fisico: string;
  evaluacion_previa?: string;
  rutina: EjercicioEntrenamientoDTO[];
}

// ── Modelos Específicos para Módulo: Predicción de Gastos ──
export interface ConsejoPredecirGastosDTO {
  pensamiento_interno_ia: string;
  introduccion: string;
  analisis_tendencia: string;
  impacto_meta: string;
  recomendacion_matematica: string;
  mensaje_motivacional: string;
}

// ── Modelos Específicos para Módulo: Simular Meta ──
export interface ConsejoSimularMetaDTO {
  pensamiento_interno_ia: string;
  introduccion: string;
  diagnostico_viabilidad: string;
  plan_accion: string;
  tecnica_sugerida?: string;
  mensaje_motivacional: string;
}

// ── Modelos Específicos para Módulo 5: Espejo Temporal ──

export interface DatosPresenteDTO {
  scoreActual: number;
  saldoActual: number;
  metasActivas: number;
}

export interface ProyeccionHitoDTO {
  scoreProyectado: number;
  ahorroAcumulado: number;
  metasCumplidas: string[];
  metasFracasadas: string[];
}

export interface ProyeccionFuturaDTO {
  hitos3Meses: ProyeccionHitoDTO;
  hitos6Meses: ProyeccionHitoDTO;
  hitos12Meses: ProyeccionHitoDTO;
}

export interface NarrativasGeminiDTO {
  cartaContinuidad: string;
  cartaTransformacion: string;
}

export interface InsightEspejoTemporalDTO {
  datosPresente: DatosPresenteDTO;
  proyeccionContinuidad: ProyeccionFuturaDTO;
  proyeccionTransformacion: ProyeccionFuturaDTO;
  narrativasGemini: NarrativasGeminiDTO;
}

// ── Modelos Específicos para Módulo: Gasto Hormiga ──
export interface ConsejoGastoHormigaDTO {
  pensamiento_interno_ia: string;
  introduccion: string;
  analisis_ia: string;
  conexion_emocional: string;
  plan_accion_titulo: string;
  plan_accion_pasos: string[];
  comentario_positivo: string;
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\financiero\index.ts

export * from './categoria.model';
export * from '../ia_coach/ia-base.model';
export * from '../ia_coach/ia-gasto-hormiga.model';
export * from '../ia_coach/ia-habitos.model';
export * from '../ia_coach/ia-espejo.model';
export * from '../ia_coach/ia-predecir-gastos.model';
export * from '../ia_coach/ia-simular-meta.model';
export * from '../ia_coach/ia-zona-entrenamiento.model';
export * from './presupuesto.model';
export * from './resumen.model';
export * from './transaccion.model';



## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\financiero\presupuesto.model.ts

export interface SolicitudPresupuesto {
  nombre?: string;
  montoLimite: number;
  porcentajeAlerta: number;
  fechaInicio: string;
  fechaFin: string;
}

export interface PresupuestoDTO {
  id: string;
  usuarioId: string;
  nombre: string;
  montoLimite: number;
  porcentajeAlerta: number;
  fechaInicio: string;
  fechaFin: string;
  activo: boolean;
  fechaCreacion: string;
}



## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\financiero\resumen.model.ts

export interface ResumenFinancieroDTO {
  desde:               string;   // LocalDateTime → ISO string
  hasta:               string;
  totalIngresos:       number;
  totalGastos:         number;
  balance:             number;
  cantidadIngresos:    number;
  cantidadGastos:      number;
  totalTransacciones:  number;
  promedioIngreso:     number;
  promedioGasto:       number;
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\financiero\suscripcion-gasto.model.ts

/**
 * Modelo de Suscripción de Gastos
 * Representa suscripciones recurrentes como Netflix, Spotify, Gimnasio, etc.
 */

export type EstadoSuscripcion = 'ACTIVA' | 'PAUSADA' | 'VENCIDA';
export type FrecuenciaSuscripcion = 'DIARIO' | 'SEMANAL' | 'QUINCENAL' | 'MENSUAL' | 'TRIMESTRAL' | 'SEMESTRAL' | 'ANUAL';

export interface SuscripcionGasto {
  id: string;
  nombre: string;
  descripcion: string;
  categoria: string; // food, transport, health, home, leisure, study
  monto: number;
  frecuencia: FrecuenciaSuscripcion;
  fechaInicio: string; // ISO 8601
  proximoVencimiento: string; // ISO 8601
  estado: EstadoSuscripcion;
  fechaCreacion: string;
  ultimaActualizacion: string;
}

export interface SuscripcionDTO extends SuscripcionGasto {
  // Propiedades derivadas para UI
  diasParaVencimiento?: number;
  vencePronto?: boolean;
  gastosEsteAno?: number;
  gastosEsteMes?: number;
}

/**
 * Request para crear o actualizar suscripción
 */
export interface CrearSuscripcionRequest {
  nombre: string;
  descripcion: string;
  categoria: string;
  monto: number;
  frecuencia: FrecuenciaSuscripcion;
  fechaInicio: string;
}

export interface ActualizarSuscripcionRequest extends CrearSuscripcionRequest {
  id: string;
  estado?: EstadoSuscripcion;
}

/**
 * Response del servidor
 */
export interface SuscripcionApiResponse {
  datos: SuscripcionDTO[];
  total: number;
  pagina: number;
  tamano: number;
}

/**
 * Resumen de suscripciones para dashboard
 */
export interface ResumenSuscripciones {
  totalActivas: number;
  gastoMensualEstimado: number;
  proximoPago: SuscripcionDTO | null;
  cantidadTotal: number;
  proximasFechas: SuscripcionDTO[];
}

/**
 * Categorías disponibles con sus colores
 */
export const CATEGORIAS_SUSCRIPCION = [
  { id: 'food', nombre: 'Comida', color: '#FF7043', icon: 'fa-utensils' },
  { id: 'transport', nombre: 'Transporte', color: '#42A5F5', icon: 'fa-car' },
  { id: 'health', nombre: 'Salud', color: '#26C6DA', icon: 'fa-heartbeat' },
  { id: 'home', nombre: 'Hogar', color: '#FFA726', icon: 'fa-house' },
  { id: 'leisure', nombre: 'Entretenimiento', color: '#AB47BC', icon: 'fa-gamepad' },
  { id: 'study', nombre: 'Educación', color: '#66BB6A', icon: 'fa-graduation-cap' }
];

/**
 * Frecuencias disponibles
 */
export const FRECUENCIAS_SUSCRIPCION: Array<{ id: FrecuenciaSuscripcion; nombre: string; diasAproximado: number }> = [
  { id: 'DIARIO', nombre: 'Diario', diasAproximado: 1 },
  { id: 'SEMANAL', nombre: 'Semanal', diasAproximado: 7 },
  { id: 'QUINCENAL', nombre: 'Quincenal', diasAproximado: 15 },
  { id: 'MENSUAL', nombre: 'Mensual', diasAproximado: 30 },
  { id: 'TRIMESTRAL', nombre: 'Trimestral', diasAproximado: 90 },
  { id: 'SEMESTRAL', nombre: 'Semestral', diasAproximado: 180 },
  { id: 'ANUAL', nombre: 'Anual', diasAproximado: 365 }
];

/**
 * Estados disponibles
 */
export const ESTADOS_SUSCRIPCION = [
  { id: 'ACTIVA', nombre: 'Activa', color: '#22C55E' },
  { id: 'PAUSADA', nombre: 'Pausada', color: '#F59E0B' },
  { id: 'VENCIDA', nombre: 'Vencida', color: '#EF4444' }
];


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\financiero\transaccion.model.ts

import { TipoMovimiento } from './categoria.model';
 

export type MetodoPago = 'EFECTIVO' | 'TARJETA' | 'TRANSFERENCIA' | 'DIGITAL';

export interface TransaccionDTO {
  id:                string;          
  usuarioId?:        string;         
  nombreCliente:     string;         
  monto:             number;          
  tipo:              TipoMovimiento;  
  categoriaId:       string;          
  categoria:         string;          
  categoriaIcono:    string;          
  fechaTransaccion:  string;          
  metodoPago:        MetodoPago;
  etiquetas:         string | null;   
  notas:             string | null;
  descripcion:       string | null;
  fechaRegistro?:    string;          
}
 
// ─── Lo que mandas al backend para crear/editar ───────────────────────────────
export interface TransaccionRequestDTO {
  usuarioId:         string;
  nombreCliente:     string;
  monto:             number;
  tipo:              TipoMovimiento;
  categoriaId:       string;
  fechaTransaccion:  string;          // ISO-8601
  metodoPago:        MetodoPago;
  etiquetas?:        string;          // opcional
  notas?:            string;          // opcional
  descripcion?:      string;          // opcional
}
 
// ─── Filtros para listarHistorial ─────────────────────────────────────────────
export interface TransaccionFiltros {
  usuarioId:    string;
  tipo?:        TipoMovimiento;   // sin tipo = todos (ingresos + gastos)
  categoriaId?: string;
  mes?:         number;           // 1–12
  anio?:        number;
  pagina?:      number;           // default 0
  tamanio?:     number;           // default 20, máx 100
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\ia_coach\ia-base.model.ts

export type TipoSolicitudIa = 'TRANSACCION_RECIENTE' | 'CONSULTA_MODULO';

export type ModuloIa =
  | 'TRANSACCION_AUTOMATICA'
  | 'PREDICCION_GASTOS'
  | 'GASTO_HORMIGA'
  | 'AUTOCLASIFICACION'
  | 'COMPARACION_MENSUAL'
  | 'CAPACIDAD_AHORRO'
  | 'METAS_FINANCIERAS'
  | 'ANOMALIAS'
  | 'ESTACIONALIDAD'
  | 'PRESUPUESTO_DINAMICO'
  | 'REPORTE_COMPLETO'
  | 'HABITOS_FINANCIEROS'
  | 'RETO_AHORRO_DINAMICO'
  | 'ANALISIS_ESTILO_VIDA'
  | 'ESPEJO_TEMPORAL'
  | 'ZONA_ENTRENAMIENTO';

export interface SolicitudIaDTO {
  idUsuario: string;
  tipoSolicitud: TipoSolicitudIa;
  moduloSolicitado?: ModuloIa;
}

// ── DTOs de Entrada para ms-ia ──

export interface PeticionConFiltroFechaDTO {
  usuario_id?: string; // Autocompletado del JWT
  token?: string; // Autocompletado del JWT
  mes?: number; // 1-12
  anio?: number; // 2020-2100
  tamanio_pagina?: number; // 10-1000
  frecuencia?: 'SEMANAL' | 'QUINCENAL' | 'MENSUAL';
}

export interface PeticionSimularMetaDTO {
  usuario_id?: string;
  nombre_meta: string;
  monto_objetivo: number;
  monto_actual_ahorrado?: number;
  aporte_mensual_deseado?: number;
}

export interface PeticionComparacionDTO {
  rangoA_inicio: string;
  rangoA_fin: string;
  rangoB_inicio: string;
  rangoB_fin: string;
}

export interface SolicitudClasificacionDTO {
  id_temporal: string;
  tipo_movimiento: 'INGRESO' | 'GASTO';
  etiquetas?: string;
  notas?: string;
  descripcion?: string;
}

// ── DTOs de Salida de ms-ia ──

export interface PuntoGraficoIaDTO {
  etiqueta: string;
  valor: number;
  color?: string;
}

export interface MetadataGraficoIaDTO {
  tipoGrafico: string;
  titulo: string;
  datos: PuntoGraficoIaDTO[];
  datosAux?: PuntoGraficoIaDTO[];
  unidad?: string;
  metaLinea?: number;
}

export interface KpiWidgetDTO {
  valor: number;
  etiqueta: string;
  tendencia?: string; // "ALZA" | "BAJA" | "ESTABLE"
  variacion_porcentaje?: number;
  unidad?: string;
}

export interface RespuestaModuloDTO {
  id_respuesta: string;
  usuario_id: string;
  modulo: string;
  fecha_generacion: string;
  consejo: any | string | null;
  estado_coach: 'EXITOSO' | 'CUOTA_AGOTADA' | 'AUTH_ERROR' | 'TIMEOUT' | 'NO_DISPONIBLE';
  usando_fallback: boolean;
  insight: any; // Datos analíticos puros devueltos por Pandas
  grafico?: MetadataGraficoIaDTO;
  kpi?: KpiWidgetDTO;
}

export interface CategoriaSugerida {
  categoria: string;
  icono: string;
}

export interface RespuestaClasificacionDTO {
  id_temporal: string;
  sugerencias?: CategoriaSugerida[];
  categorias_sugeridas?: string[];
  consejo?: ConsejoEstructuradoAutoClasificacionDTO;
  usando_fallback: boolean;
}

export interface ConsejoEstructuradoHormiga {
  pensamiento_interno_ia: string;
  introduccion?: string;
  analisis_ia: string;
  conexion_emocional: string;
  plan_accion_titulo: string;
  plan_accion_pasos: string[];
  comentario_positivo: string;
}

export interface ConsejoEstructuradoHabitos {
  pensamiento_interno_ia: string;
  introduccion: string;
  analisis_patron: string;
  habito_atomico_sugerido: string;
  mensaje_motivacional: string;
}

export interface ConsejoEstructuradoPredecir {
  pensamiento_interno_ia: string;
  introduccion: string;
  analisis_tendencia: string;
  impacto_meta: string;
  recomendacion_matematica: string;
  mensaje_motivacional: string;
}

export interface ConsejoEstructuradoSimularMeta {
  pensamiento_interno_ia: string;
  introduccion: string;
  diagnostico_viabilidad: string;
  plan_accion: string;
  tecnica_sugerida?: string;
  mensaje_motivacional: string;
}

export interface ConsejoEstructuradoReto {
  pensamiento_interno_ia: string;
  titulo_mision: string;
  diagnostico: string;
  estrategia: string;
  mensaje_motivacional: string;
}

export interface ConsejoEstructuradoAutoClasificacionDTO {
  pensamiento_interno_ia?: string;
  categorias_sugeridas: string[];
}

export interface RecetaMedicaFinanciera {
  categoria: string;
  diagnostico: string;
  posologia: string;
  pronostico: string;
}

export interface ConsejoEstructuradoEvolucion {
  pensamiento_interno_ia?: string;
  veredicto_narrativo: string;
  recetas_medicas: RecetaMedicaFinanciera[];
}

export interface EjercicioEntrenamiento {
  nombre: string;
  descripcion: string;
  duracion_dias: number;
  frecuencia: string;
  metrica_exito: string;
}

export interface ConsejoEstructuradoEntrenamiento {
  pensamiento_interno_ia?: string;
  estado_fisico: string;
  evaluacion_previa?: string;
  rutina: EjercicioEntrenamiento[];
}

// Compatibilidad heredada
export interface RespuestaIaDTO {
  id: string;
  idUsuario: string;
  consejoTexto: string;
  tipoModulo: string;
  fechaGeneracion: string;
  metadataGrafico?: MetadataGraficoIaDTO;
  kpiPrincipal?: number;
  kpiLabel?: string;
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\ia_coach\ia-espejo.model.ts

export interface DatosPresenteDTO {
  scoreActual: number;
  saldoActual: number;
  metasActivas: number;
}

export interface ProyeccionHitoDTO {
  scoreProyectado: number;
  ahorroAcumulado: number;
  metasCumplidas: string[];
  metasFracasadas: string[];
}

export interface ProyeccionFuturaDTO {
  hitos3Meses: ProyeccionHitoDTO;
  hitos6Meses: ProyeccionHitoDTO;
  hitos12Meses: ProyeccionHitoDTO;
}

export interface NarrativasGeminiDTO {
  cartaContinuidad: string;
  cartaTransformacion: string;
}

export interface InsightEspejoTemporalDTO {
  datosPresente: DatosPresenteDTO;
  proyeccionContinuidad: ProyeccionFuturaDTO;
  proyeccionTransformacion: ProyeccionFuturaDTO;
  narrativasGemini: NarrativasGeminiDTO;
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\ia_coach\ia-estilo-vida.model.ts

export interface ConsejoEstiloVidaDTO {
  pensamiento_interno_ia: string;
  arquetipo: string;
  significado_arquetipo: string;
  descripcion_perfil: string;
  consejo_tactico: string;
  alineacion_meta: string;
  mensaje_estilo_vida: string;
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\ia_coach\ia-gasto-hormiga.model.ts

export interface ConsejoGastoHormigaDTO {
  pensamiento_interno_ia: string;
  analisis_ia: string;
  conexion_emocional: string;
  plan_accion_titulo: string;
  plan_accion_pasos: string[];
  comentario_positivo: string;
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\ia_coach\ia-habitos.model.ts

export interface ConsejoHabitosFinancierosDTO {
  pensamiento_interno_ia: string;
  analisis_patron: string;
  habito_atomico_sugerido: string;
  mensaje_motivacional: string;
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\ia_coach\ia-predecir-gastos.model.ts

export interface ConsejoPredecirGastosDTO {
  pensamiento_interno_ia: string;
  analisis_tendencia: string;
  impacto_meta: string;
  recomendacion_matematica: string;
  mensaje_motivacional: string;
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\ia_coach\ia-reporte-completo.model.ts

export interface ConsejoReporteCompletoDTO {
  pensamiento_interno_ia: string;
  analisis_score: string;
  impacto_meta: string;
  veredicto_final: string;
  mensaje_motivacional: string;
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\ia_coach\ia-reto-ahorro.model.ts

export interface ConsejoRetoAhorroDTO {
    pensamiento_interno_ia: string;
    titulo_mision: string;
    diagnostico: string;
    estrategia: string;
    mensaje_motivacional: string;
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\ia_coach\ia-simular-meta.model.ts

export interface ConsejoSimularMetaDTO {
  pensamiento_interno_ia: string;
  diagnostico_viabilidad: string;
  plan_accion: string;
  tecnica_sugerida?: string;
  mensaje_motivacional: string;
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\ia_coach\ia-zona-entrenamiento.model.ts

export interface EjercicioEntrenamientoDTO {
  nombre: string;
  descripcion: string;
  duracion_dias: number;
  frecuencia: string;
  metrica_exito: string;
}

export interface ConsejoEntrenamientoDTO {
  pensamiento_interno_ia: string;
  estado_fisico: string;
  evaluacion_previa?: string;
  rutina: EjercicioEntrenamientoDTO[];
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\mensajeria\index.ts

export * from './otp.model';



## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\mensajeria\otp.model.ts

export type TipoVerificacion = 'EMAIL' | 'SMS';

export type PropositoCodigo = 'ACTIVACION_CUENTA' | 'RESET_PASSWORD';

export interface SolicitudGenerarCodigo {
  usuarioId: string;
  email: string;
  telefono: string;
  tipo: TipoVerificacion;
  proposito: PropositoCodigo;
}

export interface SolicitudValidarCodigo {
  usuarioId: string;
  codigo: string;
}

export interface RespuestaGeneracion {
  exito: boolean;
  mensaje: string;
  tipo: string;
}

export interface RespuestaValidacion {
  exito: boolean;
  mensaje: string;
}



## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\shared\index.ts

export * from './pagina.model';



## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\models\shared\pagina.model.ts

export interface PaginaDTO<T> {
  content:          T[];
  totalElements:    number;
  totalPages:       number;
  number:           number;
  size:             number;
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\app-event-bus.service.ts

import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { filter, map } from 'rxjs/operators';

export interface AppEvent {
  type: string;
  payload?: any;
}

@Injectable({
  providedIn: 'root'
})
export class AppEventBus {
  private bus$ = new Subject<AppEvent>();

  /**
   * Emite un evento en el bus global.
   * @param event Evento con tipo y payload opcional.
   */
  emit(event: AppEvent): void {
    this.bus$.next(event);
  }

  /**
   * Retorna un observable filtrado por el tipo de evento especificado.
   * @param eventType Tipo del evento a escuchar (ej: 'TRANSACTION_MODIFIED').
   */
  on(eventType: string): Observable<any> {
    return this.bus$.asObservable().pipe(
      filter(event => event.type === eventType),
      map(event => event.payload)
    );
  }
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\auditoria.service.ts

import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../enviroments/environment';
import {
  AuditoriaAccesoDTO,
  AuditoriaAccesoRequestDTO,
  AuditoriaTransaccionalDTO,
  AuditoriaTransaccionalRequestDTO,
  PaginaAuditoriaAcceso,
  PaginaAuditoriaTransaccional,
  PaginaRegistroAuditoria,
  RegistroAuditoriaDTO,
  RegistroAuditoriaRequestDTO,
  RespuestaVerificacionIpDTO
} from '../models/auditoria/auditoria.model';

@Injectable({ providedIn: 'root' })
export class AuditoriaService {
  private base = `${environment.gatewayUrl}/api/v1/auditoria`;

  constructor(private http: HttpClient) {}

  registrarAcceso(payload: AuditoriaAccesoRequestDTO): Observable<AuditoriaAccesoDTO> {
    return this.http.post<AuditoriaAccesoDTO>(`${this.base}/accesos`, payload);
  }

  listarAccesos(pagina = 0, tamanio = 20): Observable<PaginaAuditoriaAcceso> {
    const params = new HttpParams().set('pagina', pagina).set('tamanio', tamanio);
    return this.http.get<PaginaAuditoriaAcceso>(`${this.base}/accesos`, { params });
  }

  verificarIp(ip: string): Observable<RespuestaVerificacionIpDTO> {
    return this.http.get<RespuestaVerificacionIpDTO>(`${this.base}/verificar-ip/${ip}`);
  }

  registrarTransaccion(payload: AuditoriaTransaccionalRequestDTO): Observable<AuditoriaTransaccionalDTO> {
    return this.http.post<AuditoriaTransaccionalDTO>(`${this.base}/transacciones`, payload);
  }

  listarTransacciones(filtros: {
    servicioOrigen?: string;
    desde?: string;
    hasta?: string;
    pagina?: number;
    tamanio?: number;
  } = {}): Observable<PaginaAuditoriaTransaccional> {
    let params = new HttpParams()
      .set('pagina', filtros.pagina ?? 0)
      .set('tamanio', filtros.tamanio ?? 20);

    if (filtros.servicioOrigen) params = params.set('servicioOrigen', filtros.servicioOrigen);
    if (filtros.desde) params = params.set('desde', filtros.desde);
    if (filtros.hasta) params = params.set('hasta', filtros.hasta);

    return this.http.get<PaginaAuditoriaTransaccional>(`${this.base}/transacciones`, { params });
  }

  registrarEvento(payload: RegistroAuditoriaRequestDTO): Observable<RegistroAuditoriaDTO> {
    return this.http.post<RegistroAuditoriaDTO>(`${this.base}/registrar`, payload);
  }

  listarRegistros(filtros: {
    modulo?: string;
    nivel?: string;
    pagina?: number;
    tamanio?: number;
  } = {}): Observable<PaginaRegistroAuditoria> {
    let params = new HttpParams()
      .set('pagina', filtros.pagina ?? 0)
      .set('tamanio', filtros.tamanio ?? 20);

    if (filtros.modulo) params = params.set('modulo', filtros.modulo);
    if (filtros.nivel) params = params.set('nivel', filtros.nivel);

    return this.http.get<PaginaRegistroAuditoria>(`${this.base}/registros`, { params });
  }
}



## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\auth.service.ts

// =============================================
// LUKA - Auth Service
// Conectado a: microservicio-usuarios (puerto 8081)
// Endpoints reales:
//   POST /api/v1/auth/login
//   POST /api/v1/auth/registrar
//   PUT  /api/v1/auth/activar/{usuarioId}
//   POST /api/v1/auth/recuperar-password
//   POST /api/v1/auth/reset-password
// =============================================

import { Injectable, signal, computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { DashboardStateService } from './dashboard-state.service';
import { Observable, ReplaySubject, tap } from 'rxjs';
import { map, take } from 'rxjs/operators';
import { environment } from '../../enviroments/environment';
import {
  SolicitudLogin, SolicitudRegistro,
  RespuestaAutenticacion, UsuarioSesion,
  SolicitudRecuperacion, SolicitudCambioPassword,
  ResultadoApi
} from '../models/auth/user.model';

const TOKEN_KEY = 'luka_token';
const REFRESH_TOKEN_KEY = 'luka_refresh_token';
const USUARIO_KEY = 'luka_usuario';

@Injectable({ providedIn: 'root' })
export class AuthService {

  private base = `${environment.gatewayUrl}/api/v1/auth`;

  // ── Estado reactivo ──
  private _usuario = signal<UsuarioSesion | null>(this.cargarDesdStorage());
  usuario = this._usuario.asReadonly();
  logueado = computed(() => !!this._usuario());
  esPremium = computed(() => this._usuario()?.roles?.some(r => r === 'PREMIUM' || r === 'ROLE_PREMIUM') ?? false);
  esPro = computed(() => this._usuario()?.roles?.some(r => r === 'PRO' || r === 'ROLE_PRO') ?? false);

  private dashboardState = inject(DashboardStateService);

  // ReplaySubject to notify when the initial session check is complete
  private inicializado$ = new ReplaySubject<void>(1);

  constructor(private http: HttpClient, private router: Router) {
    if (this.getToken()) {
      this.obtenerUsuarioActual().subscribe({
        next: (resp) => {
          if (!resp || !resp.exito) {
            console.warn('[AuthService] Sesión no válida al inicializar.');
            this.logout();
          }
          this.inicializado$.next();
        },
        error: (err) => {
          console.error('[AuthService] No se pudo autorefrescar el usuario al inicializar:', err);
          this.logout();
          this.inicializado$.next();
        }
      });
    } else {
      this.inicializado$.next();
    }
  }

  esperarInicializacion(): Observable<boolean> {
    return this.inicializado$.asObservable().pipe(
      map(() => this.logueado()),
      take(1)
    );
  }

  // ── Obtener/Refrescar Usuario Actual ──
  obtenerUsuarioActual(): Observable<ResultadoApi<RespuestaAutenticacion>> {
    return this.http.get<ResultadoApi<RespuestaAutenticacion>>(`${this.base}/me`).pipe(
      tap(resp => {
        if (resp.exito) {
          this.actualizarSesion(resp.datos);
        }
      })
    );
  }

  actualizarSesion(resp: RespuestaAutenticacion): void {
    const sesion: UsuarioSesion = {
      id: resp.idUsuario,
      nombreUsuario: resp.nombreUsuario,
      roles: resp.roles,
      token: resp.tokenAcceso,
      refreshToken: resp.refreshToken,
      expiraEn: resp.expiraEn
    };
    localStorage.setItem(TOKEN_KEY, resp.tokenAcceso);
    if (resp.refreshToken) {
      localStorage.setItem(REFRESH_TOKEN_KEY, resp.refreshToken);
    }
    localStorage.setItem(USUARIO_KEY, JSON.stringify(sesion));
    this._usuario.set(sesion);
    this.dashboardState.marcarForzarRefresco();
  }

  // ── Login ──
  login(solicitud: SolicitudLogin): Observable<ResultadoApi<RespuestaAutenticacion>> {
    return this.http.post<ResultadoApi<RespuestaAutenticacion>>(`${this.base}/login`, solicitud)
      .pipe(tap(resp => {
        if (resp.exito) {
          this.guardarSesion(resp.datos);
        }
      }));
  }

  // ── Registro ──
  registrar(solicitud: SolicitudRegistro): Observable<ResultadoApi<string>> {
    return this.http.post<ResultadoApi<string>>(`${this.base}/registrar`, solicitud);
  }

  // ── Activar cuenta ──
  activarCuenta(usuarioId: string, codigoOtp: string, telefono?: string): Observable<ResultadoApi<string>> {
    const params: any = { codigoOtp };
    if (telefono) params.telefono = telefono;
    return this.http.put<ResultadoApi<string>>(`${this.base}/activar/${usuarioId}`, null, { params });
  }

  // ── Solicitar OTP Activacion ──
  solicitarOtpActivacion(solicitud: { email: string; tipo: 'EMAIL' | 'SMS' | 'WHATSAPP'; telefono?: string }): Observable<ResultadoApi<string>> {
    return this.http.post<ResultadoApi<string>>(`${this.base}/solicitar-otp`, solicitud);
  }

  // ── Recuperar password ──
  solicitarRecuperacion(solicitud: any): Observable<ResultadoApi<string>> {
    return this.http.post<ResultadoApi<string>>(`${this.base}/recuperar-solicitar`, solicitud);
  }

  // ── Reset password ──
  resetPassword(registroId: string, codigoOtp: string, dto: any): Observable<ResultadoApi<string>> {
    const params = { registroId, codigoOtp };
    return this.http.post<ResultadoApi<string>>(`${this.base}/recuperar-confirmar`, dto, { params });
  }

  // ── Cambiar password (usuario autenticado) ──
  cambiarPassword(solicitud: SolicitudCambioPassword): Observable<any> {
    return this.http.put(`${this.base}/cambiar-password`, solicitud);
  }

  // ── Logout backend ──
  cerrarSesionBackend(): Observable<any> {
    return this.http.post(`${this.base}/logout`, {})
  };

  // ── Eliminar cuenta (usuario autenticado) ──
  eliminarMiCuenta(): Observable<any> {
    return this.http.delete(`${this.base}/mi-cuenta`);
  }

  logout(): void {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(REFRESH_TOKEN_KEY);
    localStorage.removeItem(USUARIO_KEY);
    this._usuario.set(null);
    this.dashboardState.limpiarEstado();
    this.router.navigate(['/']);
  }

  // ── Token para el interceptor ──
  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  getRefreshToken(): string | null {
    return localStorage.getItem(REFRESH_TOKEN_KEY);
  }

  refrescarToken(refreshToken: string): Observable<ResultadoApi<RespuestaAutenticacion>> {
    return this.http.post<ResultadoApi<RespuestaAutenticacion>>(`${this.base}/refrescar-token`, { refreshToken }).pipe(
      tap(resp => {
        if (resp.exito) {
          this.actualizarSesion(resp.datos);
        }
      })
    );
  }

  // ── Privados ──
  private guardarSesion(resp: RespuestaAutenticacion): void {
    const sesion: UsuarioSesion = {
      id: resp.idUsuario,
      nombreUsuario: resp.nombreUsuario,
      roles: resp.roles,
      token: resp.tokenAcceso,
      refreshToken: resp.refreshToken,
      expiraEn: resp.expiraEn
    };
    localStorage.setItem(TOKEN_KEY, resp.tokenAcceso);
    if (resp.refreshToken) {
      localStorage.setItem(REFRESH_TOKEN_KEY, resp.refreshToken);
    }
    localStorage.setItem(USUARIO_KEY, JSON.stringify(sesion));
    this._usuario.set(sesion);
    // Forzar refresco limpio del dashboard tras login
    this.dashboardState.marcarForzarRefresco();
  }

  private cargarDesdStorage(): UsuarioSesion | null {
    try {
      const raw = localStorage.getItem(USUARIO_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  }
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\avatar.service.ts

import { Injectable, signal } from '@angular/core';

export interface AvatarConfig {
  figura: string;
  accesorio?: string;
}

@Injectable({ providedIn: 'root' })
export class AvatarService {
  private readonly storageKey = 'lukaapp.avatar.config';

  readonly avatarConfig = signal<AvatarConfig>({
    figura: 'GATO ANDINO',
    accesorio: 'LENTES',
  });

  setAvatar(config: AvatarConfig): void {
    this.avatarConfig.set(config);
    localStorage.setItem(this.storageKey, JSON.stringify(config));
  }

  getAvatar(): AvatarConfig {
    return this.avatarConfig();
  }

  loadAvatar(): void {
    const rawConfig = localStorage.getItem(this.storageKey);
    if (!rawConfig) {
      return;
    }

    try {
      const parsed = JSON.parse(rawConfig) as AvatarConfig;
      if (parsed?.figura) {
        this.avatarConfig.set(parsed);
      }
    } catch {
      localStorage.removeItem(this.storageKey);
    }
  }
}



## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\ayuda.service.ts

import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../enviroments/environment';

export interface RespuestaSoporte {
  exito: boolean;
  mensaje: string;
}

@Injectable({
  providedIn: 'root'
})
export class AyudaService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = `${environment.gatewayUrl}/api/v1/mensajeria/soporte`;

  /**
   * Envía una consulta de soporte al backend.
   * Utiliza FormData para permitir la carga opcional de adjuntos.
   * @param formData Debe contener la parte "solicitud" (JSON Blob) y opcionalmente "adjunto" (File).
   */
  enviarContacto(formData: FormData): Observable<RespuestaSoporte> {
    return this.http.post<RespuestaSoporte>(`${this.baseUrl}/contacto`, formData);
  }

  /**
   * Envía un reporte de problema al backend.
   * Utiliza FormData para permitir la carga opcional de adjuntos.
   * @param formData Debe contener la parte "solicitud" (JSON Blob) y opcionalmente "adjunto" (File).
   */
  enviarReporte(formData: FormData): Observable<RespuestaSoporte> {
    return this.http.post<RespuestaSoporte>(`${this.baseUrl}/reporte`, formData);
  }
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\categorias.spec.ts

import { TestBed } from '@angular/core/testing';

import { Categorias } from './categorias';

describe('Categorias', () => {
  let service: Categorias;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Categorias);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\categorias.ts

import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class Categorias {
  
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\cliente-metas-limites.service.ts

import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../enviroments/environment';
import {
  RespuestaLimiteGasto,
  RespuestaMetaAhorro,
  SolicitudLimiteGasto,
  SolicitudMetaAhorro,
  Pagina
} from '../models/cliente/meta-limite.model';
import { ResultadoApi } from '../models/auth/user.model';

@Injectable({ providedIn: 'root' })
export class ClienteMetasLimitesService {
  private baseMetas = `${environment.gatewayUrl}/api/v1/clientes/metas`;
  private baseLimites = `${environment.gatewayUrl}/api/v1/clientes/limites`;

  constructor(private http: HttpClient) {}

  crearMeta(payload: SolicitudMetaAhorro): Observable<RespuestaMetaAhorro> {
    return this.http.post<ResultadoApi<RespuestaMetaAhorro>>(this.baseMetas, payload).pipe(
      map(res => res.datos)
    );
  }

  actualizarMeta(metaId: string, payload: SolicitudMetaAhorro): Observable<RespuestaMetaAhorro> {
    return this.http.put<ResultadoApi<RespuestaMetaAhorro>>(`${this.baseMetas}/${metaId}`, payload).pipe(
      map(res => res.datos)
    );
  }

  listarMetas(page: number = 0, size: number = 10): Observable<Pagina<RespuestaMetaAhorro>> {
    const params = new HttpParams().set('page', page.toString()).set('size', size.toString());
    return this.http.get<ResultadoApi<any>>(this.baseMetas, { params }).pipe(
      map(res => {
        const datos = res.datos;
        if (!datos) {
          throw new Error('Sin datos en la respuesta de metas');
        }
        const content = datos.contenido || datos.content || [];
        return {
          content: content,
          totalElements: datos.totalElementos !== undefined ? datos.totalElementos : (datos.totalElements || content.length),
          totalPages: datos.totalPaginas !== undefined ? datos.totalPaginas : (datos.totalPages || 1),
          size: datos.tamañoPagina !== undefined ? datos.tamañoPagina : (datos.size || size),
          number: datos.numeroPagina !== undefined ? datos.numeroPagina : (datos.number || page)
        } as Pagina<RespuestaMetaAhorro>;
      }),
      catchError(() => {
        // Fallback a localStorage
        const localMetasStr = localStorage.getItem('luka_mock_metas');
        let list: RespuestaMetaAhorro[] = [];
        if (localMetasStr) {
          try {
            list = JSON.parse(localMetasStr);
          } catch (e) {
            console.error('Error parseando luka_mock_metas:', e);
          }
        }
        
        // Si no hay nada en localStorage, inicializar con mocks por defecto para pruebas fluidas
        if (list.length === 0) {
          list = [
            {
              id: 'mock-meta-1',
              nombre: '[Viaje] Viaje a Cancún',
              montoObjetivo: 2000,
              montoActual: 2000,
              porcentajeProgreso: 100,
              fechaLimite: '2026-11-29',
              completada: true,
              fechaCreacion: '2025-01-15',
              fechaActualizacion: '2026-11-29'
            },
            {
              id: 'mock-meta-2',
              nombre: '[Tecnología] Laptop',
              montoObjetivo: 300,
              montoActual: 300,
              porcentajeProgreso: 100,
              fechaLimite: '2025-08-15',
              completada: true,
              fechaCreacion: '2024-10-10',
              fechaActualizacion: '2025-08-15'
            },
            {
              id: 'mock-meta-3',
              nombre: '[Auto] Auto',
              montoObjetivo: 5000,
              montoActual: 1700,
              porcentajeProgreso: 34,
              fechaLimite: '2026-03-10',
              completada: false,
              fechaCreacion: '2025-02-01',
              fechaActualizacion: '2025-02-01'
            },
            {
              id: 'mock-meta-4',
              nombre: '[Estudios] Estudios',
              montoObjetivo: 5100,
              montoActual: 1700,
              porcentajeProgreso: 33,
              fechaLimite: '2027-04-20',
              completada: false,
              fechaCreacion: '2025-01-20',
              fechaActualizacion: '2025-01-20'
            },
            {
              id: 'mock-meta-5',
              nombre: '[Tecnología] Nuevo Celular',
              montoObjetivo: 1500,
              montoActual: 850,
              porcentajeProgreso: 57,
              fechaLimite: '2026-05-05',
              completada: false,
              fechaCreacion: '2025-03-01',
              fechaActualizacion: '2025-03-01'
            },
            {
              id: 'mock-meta-6',
              nombre: '[Otros] Muebles',
              montoObjetivo: 2500,
              montoActual: 250,
              porcentajeProgreso: 10,
              fechaLimite: '2025-09-20',
              completada: false,
              fechaCreacion: '2024-12-01',
              fechaActualizacion: '2024-12-01'
            },
            {
              id: 'mock-meta-7',
              nombre: '[Emergencia] Fondo de Emergencia',
              montoObjetivo: 1000,
              montoActual: 300,
              porcentajeProgreso: 30,
              fechaLimite: '2026-12-31',
              completada: false,
              fechaCreacion: '2025-04-10',
              fechaActualizacion: '2025-04-10'
            }
          ];
          localStorage.setItem('luka_mock_metas', JSON.stringify(list));
        }

        const start = page * size;
        const end = start + size;
        const paginatedList = list.slice(start, end);

        return of({
          content: paginatedList,
          totalElements: list.length,
          totalPages: Math.ceil(list.length / size),
          size: size,
          number: page
        } as Pagina<RespuestaMetaAhorro>);
      })
    );
  }

  listarMetasActivas(page: number = 0, size: number = 10): Observable<Pagina<RespuestaMetaAhorro>> {
    const params = new HttpParams().set('page', page.toString()).set('size', size.toString());
    return this.http.get<ResultadoApi<any>>(`${this.baseMetas}/activas`, { params }).pipe(
      map(res => {
        const datos = res.datos;
        if (!datos) {
          throw new Error('Sin datos en la respuesta de metas activas');
        }
        const content = datos.contenido || datos.content || [];
        return {
          content: content,
          totalElements: datos.totalElementos !== undefined ? datos.totalElementos : (datos.totalElements || content.length),
          totalPages: datos.totalPaginas !== undefined ? datos.totalPaginas : (datos.totalPages || 1),
          size: datos.tamañoPagina !== undefined ? datos.tamañoPagina : (datos.size || size),
          number: datos.numeroPagina !== undefined ? datos.numeroPagina : (datos.number || page)
        } as Pagina<RespuestaMetaAhorro>;
      }),
      catchError(() => {
        // Fallback a localStorage
        const localMetasStr = localStorage.getItem('luka_mock_metas');
        let list: RespuestaMetaAhorro[] = [];
        if (localMetasStr) {
          try {
            list = JSON.parse(localMetasStr).filter((m: any) => !m.completada);
          } catch (e) {
            console.error('Error parseando metas activas:', e);
          }
        }
        const start = page * size;
        const end = start + size;
        const paginatedList = list.slice(start, end);
        return of({
          content: paginatedList,
          totalElements: list.length,
          totalPages: Math.ceil(list.length / size),
          size: size,
          number: page
        } as Pagina<RespuestaMetaAhorro>);
      })
    );
  }

  obtenerMeta(metaId: string): Observable<RespuestaMetaAhorro> {
    return this.http.get<ResultadoApi<RespuestaMetaAhorro>>(`${this.baseMetas}/${metaId}`).pipe(
      map(res => res.datos)
    );
  }

  actualizarProgresoMeta(metaId: string, montoActual: number): Observable<RespuestaMetaAhorro> {
    return this.http.patch<ResultadoApi<RespuestaMetaAhorro>>(`${this.baseMetas}/${metaId}/progreso`, { montoActual }).pipe(
      map(res => res.datos)
    );
  }

  eliminarMeta(metaId: string): Observable<void> {
    return this.http.delete<ResultadoApi<void>>(`${this.baseMetas}/${metaId}`).pipe(
      map(() => undefined)
    );
  }

  crearLimite(payload: SolicitudLimiteGasto): Observable<RespuestaLimiteGasto> {
    return this.http.post<ResultadoApi<RespuestaLimiteGasto>>(this.baseLimites, payload).pipe(
      map(res => res.datos)
    );
  }

  obtenerLimiteActivo(): Observable<RespuestaLimiteGasto> {
    return this.http.get<ResultadoApi<RespuestaLimiteGasto>>(`${this.baseLimites}/activo`).pipe(
      map(res => res.datos)
    );
  }

  actualizarLimite(payload: SolicitudLimiteGasto): Observable<RespuestaLimiteGasto> {
    return this.http.patch<ResultadoApi<RespuestaLimiteGasto>>(this.baseLimites, payload).pipe(
      map(res => res.datos)
    );
  }

  listarHistorialLimites(): Observable<RespuestaLimiteGasto[]> {
    return this.http.get<ResultadoApi<RespuestaLimiteGasto[]>>(this.baseLimites).pipe(
      map(res => res.datos)
    );
  }

  desactivarLimiteActivo(): Observable<void> {
    return this.http.delete<ResultadoApi<void>>(this.baseLimites).pipe(
      map(() => undefined)
    );
  }
}



## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\cliente-perfil.service.ts

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../enviroments/environment';
import {
  RespuestaDatosPersonales,
  RespuestaPerfilFinanciero,
  SolicitudDatosPersonales,
  SolicitudPerfilFinanciero
} from '../models/cliente/perfil-cliente.model';
import { ResultadoApi } from '../models/auth/user.model';

@Injectable({ providedIn: 'root' })
export class ClientePerfilService {
  private basePerfil = `${environment.gatewayUrl}/api/v1/clientes/perfil`;
  private basePerfilFinanciero = `${environment.gatewayUrl}/api/v1/clientes/perfil-financiero`;

  constructor(private http: HttpClient) {}

  crearPerfilInicial(usuarioId: string): Observable<RespuestaDatosPersonales> {
    return this.http.post<ResultadoApi<RespuestaDatosPersonales>>(`${this.basePerfil}/inicial?usuarioId=${usuarioId}`, {}).pipe(
      map(res => res.datos)
    );
  }

  consultarPerfil(usuarioId: string): Observable<RespuestaDatosPersonales> {
    return this.http.get<ResultadoApi<RespuestaDatosPersonales>>(`${this.basePerfil}/${usuarioId}`).pipe(
      map(res => res.datos)
    );
  }

  obtenerPerfil(usuarioId: string): Observable<RespuestaDatosPersonales> {
    return this.consultarPerfil(usuarioId);
  }

  actualizarPerfil(usuarioId: string, payload: SolicitudDatosPersonales): Observable<RespuestaDatosPersonales> {
    return this.http.put<ResultadoApi<RespuestaDatosPersonales>>(`${this.basePerfil}/${usuarioId}`, payload).pipe(
      map(res => res.datos)
    );
  }

  eliminarCuenta(usuarioId: string): Observable<void> {
    return this.http.delete<ResultadoApi<void>>(`${this.basePerfil}/${usuarioId}`).pipe(
      map(() => undefined)
    );
  }

  consultarPerfilFinanciero(usuarioId: string): Observable<RespuestaPerfilFinanciero> {
    return this.http.get<ResultadoApi<RespuestaPerfilFinanciero>>(`${this.basePerfilFinanciero}/${usuarioId}`).pipe(
      map(res => res.datos)
    );
  }

  guardarPerfilFinanciero(usuarioId: string, payload: SolicitudPerfilFinanciero): Observable<RespuestaPerfilFinanciero> {
    return this.http.put<ResultadoApi<RespuestaPerfilFinanciero>>(`${this.basePerfilFinanciero}/${usuarioId}`, payload).pipe(
      map(res => res.datos)
    );
  }
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\dashboard-state.service.ts

import { Injectable, signal, computed } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../enviroments/environment';
import { ResultadoApi } from '../models/auth/user.model';
import { 
  DashboardResumenDTO, 
  CashflowPointDTO, 
  CategoriaDistribucionDTO,
  HeatmapPointDTO,
  MetaProgressDTO,
  ComparativaMensualDTO,
  DashboardAnaliticaDTO
} from '../models/dashboard/dashboard.model';

export interface DashboardFiltros {
  fechaInicio?: string;
  fechaFin?: string;
  metodoPago?: string;
  tipoMovimiento?: string;
}

@Injectable({
  providedIn: 'root'
})
export class DashboardStateService {
  private base = `${environment.gatewayUrl}/api/v1/dashboard`;

  // ── Angular Signals de Estado ──
  readonly resumen = signal<DashboardResumenDTO | null>(null);
  readonly flujoCaja = signal<CashflowPointDTO[]>([]);
  readonly distribucionGastos = signal<CategoriaDistribucionDTO[]>([]);
  readonly heatmap = signal<HeatmapPointDTO[]>([]);
  readonly metas = signal<MetaProgressDTO[]>([]);
  readonly comparativa = signal<ComparativaMensualDTO[]>([]);
  readonly transaccionesMetodo = signal<{ metodo: string, cantidad: number, color: string }[]>([]);

  // ── Filtros Actuales ──
  readonly filtrosActuales = signal<DashboardFiltros>({});

  // ── Estados Auxiliares ──
  readonly loading = signal<boolean>(false);
  readonly error = signal<string | null>(null);

  constructor(private http: HttpClient) {}

  marcarForzarRefresco(): void {
    // Deprecated o ignorado para V2, retenido por compatibilidad con Auth
  }

  private initialLoadDone = false;

  /**
   * Carga los datos analíticos enriquecidos pasando los filtros al backend.
   */
  cargarAnalitica(filtros?: DashboardFiltros): void {
    // Si ya cargó y no se enviaron filtros nuevos, evitamos múltiples llamadas innecesarias
    if (this.initialLoadDone && !filtros) {
      return;
    }

    this.loading.set(true);
    this.error.set(null);

    // Actualizamos el signal de filtros si vienen nuevos
    if (filtros) {
      // Comparar si son iguales (simplificado) para evitar re-fetch si no cambiaron
      const actuales = this.filtrosActuales();
      if (
        actuales.fechaInicio === filtros.fechaInicio &&
        actuales.fechaFin === filtros.fechaFin &&
        actuales.metodoPago === filtros.metodoPago &&
        actuales.tipoMovimiento === filtros.tipoMovimiento &&
        this.initialLoadDone
      ) {
        this.loading.set(false);
        return;
      }
      this.filtrosActuales.set(filtros);
    }

    let params = new HttpParams();
    const currentFilters = this.filtrosActuales();
    
    if (currentFilters.fechaInicio) params = params.set('fechaInicio', currentFilters.fechaInicio);
    if (currentFilters.fechaFin) params = params.set('fechaFin', currentFilters.fechaFin);
    if (currentFilters.metodoPago) params = params.set('metodoPago', currentFilters.metodoPago);
    if (currentFilters.tipoMovimiento) params = params.set('tipoMovimiento', currentFilters.tipoMovimiento);

    this.http.get<ResultadoApi<DashboardAnaliticaDTO>>(`${this.base}/analitica-avanzada`, { params }).subscribe({
      next: (resp) => {
        if (resp.exito && resp.datos) {
          const d = resp.datos;
          this.resumen.set(d.resumen);
          this.flujoCaja.set(d.flujoCaja || []);
          
          // Tomar solo los 5 gastos más importantes (ordenados)
          const dist = (d.distribucionGastos || [])
            .sort((a, b) => b.total - a.total)
            .slice(0, 5);
          this.distribucionGastos.set(dist);

          this.heatmap.set(d.heatmap || []);
          this.metas.set(d.metas || []);
          this.comparativa.set(d.comparativa || []);
          this.transaccionesMetodo.set(d.transaccionesMetodo || []);
        } else {
          this.error.set(resp.mensaje || 'Error al cargar analítica avanzada');
        }
        this.loading.set(false);
        this.initialLoadDone = true;
      },
      error: (err) => {
        console.warn('[DashboardStateService] Fallback a mock de analítica avanzada:', err);
        // Mock fallback temporal para frontend dev
        this.cargarMock();
        this.loading.set(false);
        this.initialLoadDone = true;
      }
    });
  }

  /**
   * Invalida los datos y fuerza una recarga.
   */
  invalidarCache(): void {
    this.initialLoadDone = false; // Permitir recarga al ser evento de sincronización
    this.cargarAnalitica(this.filtrosActuales());
  }

  /**
   * Limpia el estado.
   */
  limpiarEstado(): void {
    this.resumen.set(null);
    this.flujoCaja.set([]);
    this.distribucionGastos.set([]);
    this.heatmap.set([]);
    this.metas.set([]);
    this.comparativa.set([]);
    this.transaccionesMetodo.set([]);
    this.filtrosActuales.set({});
    this.loading.set(false);
    this.error.set(null);
  }

  // --- MOCK FALLBACK ---
  private cargarMock(): void {
    const filtros = this.filtrosActuales();
    
    // Base numbers that we can scale or filter
    let ingresosBase = 3200;
    let gastosBase = 2500;
    let ahorroBase = 15.5;
    let promedioDiario = 85.50;
    let presupuestoCumplimiento = 78.2;
    let proyeccionFin = 1250.00;
    
    // Adjust based on Movement Type
    let showIngresos = true;
    let showGastos = true;
    
    if (filtros.tipoMovimiento === 'INGRESO') {
      showGastos = false;
      gastosBase = 0;
      ahorroBase = 100;
      promedioDiario = 0;
      presupuestoCumplimiento = 0;
      proyeccionFin = 0;
    } else if (filtros.tipoMovimiento === 'EGRESO') {
      showIngresos = false;
      ingresosBase = 0;
      ahorroBase = -100;
    }

    // Adjust based on Payment Method (just change the data slightly to show it works)
    let multiplier = 1.0;
    if (filtros.metodoPago === 'EFECTIVO') multiplier = 0.3;
    else if (filtros.metodoPago === 'TARJETA') multiplier = 0.55;
    else if (filtros.metodoPago === 'TRANSFERENCIA') multiplier = 0.75;
    else if (filtros.metodoPago === 'DIGITAL') multiplier = 0.45;

    ingresosBase *= multiplier;
    gastosBase *= multiplier;
    promedioDiario *= multiplier;
    proyeccionFin *= multiplier;

    // Adjust based on Date Range
    let cashflowData = [
      { mes: 'Ene', ingresos: 3000, gastos: 2500 },
      { mes: 'Feb', ingresos: 3200, gastos: 2600 },
      { mes: 'Mar', ingresos: 3100, gastos: 2800 },
      { mes: 'Abr', ingresos: 3500, gastos: 2400 },
      { mes: 'May', ingresos: 3400, gastos: 2700 },
      { mes: 'Jun', ingresos: 3600, gastos: 2900 },
      { mes: 'Jul', ingresos: 3800, gastos: 3100 },
      { mes: 'Ago', ingresos: 3700, gastos: 3000 },
      { mes: 'Sep', ingresos: 3900, gastos: 3200 },
      { mes: 'Oct', ingresos: 4000, gastos: 3300 },
      { mes: 'Nov', ingresos: 4200, gastos: 3400 },
      { mes: 'Dic', ingresos: 4500, gastos: 3600 }
    ];

    let comparativaData = [
      { mes: 'Ene', actual: 3000, anterior: 2800 },
      { mes: 'Feb', actual: 3200, anterior: 2900 },
      { mes: 'Mar', actual: 3100, anterior: 3000 },
      { mes: 'Abr', actual: 3500, anterior: 3200 },
      { mes: 'May', actual: 3400, anterior: 3100 },
      { mes: 'Jun', actual: 3600, anterior: 3300 },
      { mes: 'Jul', actual: 3800, anterior: 3500 },
      { mes: 'Ago', actual: 3700, anterior: 3400 },
      { mes: 'Sep', actual: 3900, anterior: 3600 },
      { mes: 'Oct', actual: 4000, anterior: 3700 },
      { mes: 'Nov', actual: 4200, anterior: 3800 },
      { mes: 'Dic', actual: 4500, anterior: 4000 }
    ];

    if (filtros.fechaInicio || filtros.fechaFin) {
      // If we filtered by a range, let's change labels or cut data points to reflect filtering
      const start = filtros.fechaInicio ? new Date(filtros.fechaInicio) : null;
      const end = filtros.fechaFin ? new Date(filtros.fechaFin) : null;
      
      if (start && end) {
        const diffTime = Math.abs(end.getTime() - start.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays <= 7) {
          // Weekly: Show daily cashflow points for each day of the week
          cashflowData = [
            { mes: 'Lun', ingresos: Math.round(450 * multiplier), gastos: Math.round(380 * multiplier) },
            { mes: 'Mar', ingresos: Math.round(520 * multiplier), gastos: Math.round(410 * multiplier) },
            { mes: 'Mié', ingresos: Math.round(380 * multiplier), gastos: Math.round(350 * multiplier) },
            { mes: 'Jue', ingresos: Math.round(610 * multiplier), gastos: Math.round(490 * multiplier) },
            { mes: 'Vie', ingresos: Math.round(700 * multiplier), gastos: Math.round(650 * multiplier) },
            { mes: 'Sáb', ingresos: Math.round(550 * multiplier), gastos: Math.round(720 * multiplier) },
            { mes: 'Dom', ingresos: Math.round(300 * multiplier), gastos: Math.round(250 * multiplier) }
          ];
          comparativaData = [
            { mes: 'Lun', actual: Math.round(120 * multiplier), anterior: Math.round(100 * multiplier) },
            { mes: 'Mar', actual: Math.round(150 * multiplier), anterior: Math.round(130 * multiplier) },
            { mes: 'Mié', actual: Math.round(80 * multiplier),  anterior: Math.round(95 * multiplier) },
            { mes: 'Jue', actual: Math.round(200 * multiplier), anterior: Math.round(150 * multiplier) },
            { mes: 'Vie', actual: Math.round(350 * multiplier), anterior: Math.round(300 * multiplier) },
            { mes: 'Sáb', actual: Math.round(400 * multiplier), anterior: Math.round(380 * multiplier) },
            { mes: 'Dom', actual: Math.round(180 * multiplier), anterior: Math.round(200 * multiplier) }
          ];
          promedioDiario = gastosBase / 7;
        } else if (diffDays <= 31) {
          // Monthly: Show current month + previous month with dynamic names
          const mesesNombres = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
          const mesActual = end.getMonth();
          const mesAnterior = mesActual === 0 ? 11 : mesActual - 1;
          cashflowData = [
            { mes: mesesNombres[mesAnterior], ingresos: ingresosBase * 0.9, gastos: gastosBase * 1.1 },
            { mes: mesesNombres[mesActual], ingresos: ingresosBase, gastos: gastosBase }
          ];
          comparativaData = [
            { mes: mesesNombres[mesAnterior], actual: gastosBase * 0.9, anterior: gastosBase * 0.95 },
            { mes: mesesNombres[mesActual], actual: gastosBase, anterior: gastosBase * 0.9 }
          ];
        } else if (diffDays <= 100) {
          // ~3 months: Show 3 months
          const mesesNombres = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
          const mesActual = end.getMonth();
          const mes1 = mesActual >= 2 ? mesActual - 2 : mesActual + 10;
          const mes2 = mesActual >= 1 ? mesActual - 1 : 11;
          cashflowData = [
            { mes: mesesNombres[mes1], ingresos: ingresosBase * 0.85, gastos: gastosBase * 1.05 },
            { mes: mesesNombres[mes2], ingresos: ingresosBase * 0.95, gastos: gastosBase * 0.95 },
            { mes: mesesNombres[mesActual], ingresos: ingresosBase, gastos: gastosBase }
          ];
          comparativaData = [
            { mes: mesesNombres[mes1], actual: gastosBase * 0.85, anterior: gastosBase * 0.8 },
            { mes: mesesNombres[mes2], actual: gastosBase * 0.95, anterior: gastosBase * 0.9 },
            { mes: mesesNombres[mesActual], actual: gastosBase, anterior: gastosBase * 0.95 }
          ];
        }
      }
    }

    // Apply movement filters to cashflow values
    cashflowData = cashflowData.map(d => ({
      mes: d.mes,
      ingresos: showIngresos ? Math.round(d.ingresos * multiplier) : 0,
      gastos: showGastos ? Math.round(d.gastos * multiplier) : 0
    }));

    comparativaData = comparativaData.map(d => ({
      mes: d.mes,
      actual: showGastos ? Math.round(d.actual * multiplier) : 0,
      anterior: showGastos ? Math.round(d.anterior * multiplier) : 0
    }));

    // Update state signals
    this.resumen.set({
      desde: filtros.fechaInicio || new Date().toISOString(),
      hasta: filtros.fechaFin || new Date().toISOString(),
      tasaAhorro: showIngresos && showGastos ? ahorroBase : (showIngresos ? 100 : -100),
      gastoPromedioDiario: Math.round(promedioDiario * 100) / 100,
      cumplimientoPresupuesto: showGastos ? Math.round(presupuestoCumplimiento * multiplier * 10) / 10 : 0,
      proyeccionFinDeMes: Math.round(proyeccionFin * 100) / 100
    });

    this.flujoCaja.set(cashflowData);
    
    // Scale distributions
    this.distribucionGastos.set(showGastos ? [
      { categoria: 'Alimentación', total: Math.round(800 * multiplier), porcentaje: 35, color: '#f59e0b' },
      { categoria: 'Vivienda', total: Math.round(600 * multiplier), porcentaje: 25, color: '#3b82f6' },
      { categoria: 'Transporte', total: Math.round(400 * multiplier), porcentaje: 15, color: '#10b981' },
      { categoria: 'Entretenimiento', total: Math.round(300 * multiplier), porcentaje: 15, color: '#8b5cf6' },
      { categoria: 'Otros', total: Math.round(200 * multiplier), porcentaje: 10, color: '#64748b' }
    ].slice(0, 5) : []);


    this.heatmap.set(showGastos ? [
      { dia: 'Lunes', intensidad: Math.round(4 * multiplier) || 1 },
      { dia: 'Martes', intensidad: Math.round(6 * multiplier) || 1 },
      { dia: 'Miércoles', intensidad: Math.round(3 * multiplier) || 1 },
      { dia: 'Jueves', intensidad: Math.round(5 * multiplier) || 1 },
      { dia: 'Viernes', intensidad: Math.round(9 * multiplier) || 2 },
      { dia: 'Sábado', intensidad: Math.round(10 * multiplier) || 2 },
      { dia: 'Domingo', intensidad: Math.round(7 * multiplier) || 1 }
    ] : []);

    this.metas.set([
      { nombre: 'Fondo de Emergencia', objetivo: 5000, actual: Math.round(3500 * (showIngresos ? multiplier : 0.5)), porcentaje: 70, color: '#10b981' },
      { nombre: 'Viaje Fin de Año', objetivo: 2000, actual: Math.round(500 * (showIngresos ? multiplier : 0.5)), porcentaje: 25, color: '#3b82f6' }
    ]);

    this.transaccionesMetodo.set([
      { metodo: 'Tarjeta', cantidad: Math.round(25 * multiplier) || 2, color: '#3b82f6' },
      { metodo: 'Efectivo', cantidad: Math.round(15 * multiplier) || 1, color: '#10b981' },
      { metodo: 'Transferencia', cantidad: Math.round(18 * multiplier) || 1, color: '#a855f7' },
      { metodo: 'Digital', cantidad: Math.round(12 * multiplier) || 1, color: '#f59e0b' }
    ]);

    this.comparativa.set(comparativaData);
  }
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\Financiero.service.ts

import { Injectable, signal } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../enviroments/environment';
import { ResumenFinancieroDTO}  from '../models/financiero/resumen.model';
import { CategoriaDTO, CategoriaRequestDTO, TipoMovimiento } from '../models/financiero/categoria.model';
import { AuthService } from './auth.service';
import { ResultadoApi } from '../models/auth/user.model';
 
@Injectable({ providedIn: 'root' })
export class FinancieroService {
 
  private baseTransacciones = `${environment.gatewayUrl}/api/v1/financiero/transacciones`;
  private baseCategorias    = `${environment.gatewayUrl}/api/v1/financiero/categorias`;
 
  // ── Estado reactivo ──
  resumen    = signal<ResumenFinancieroDTO | null>(null);
  categorias = signal<CategoriaDTO[]>([]);
  cargando   = signal<boolean>(false);
 
  constructor(private http: HttpClient, private auth: AuthService) {}
 
  // ── Resumen financiero del mes actual ──
  getResumen(mes?: number, anio?: number): Observable<ResumenFinancieroDTO> {
    const usuarioId = this.auth.usuario()?.id;
    let params = new HttpParams().set('usuarioId', usuarioId ?? '');
    if (mes)  params = params.set('mes',  mes);
    if (anio) params = params.set('anio', anio);
 
    return this.http.get<ResultadoApi<ResumenFinancieroDTO>>(`${this.baseTransacciones}/resumen`, { params }).pipe(
      map(resp => resp.datos),
      catchError(() => {
        // Fallback a mock dinámico según el mes y año si falla el backend
        const finalMes = mes ?? new Date().getMonth() + 1;
        const finalAnio = anio ?? new Date().getFullYear();
        
        // Simular valores variables pero deterministas para que el filtro "Mayo 2025" y otros muestren datos diferentes
        const factorMes = finalMes * 230;
        const factorAnio = (finalAnio % 10) * 120;
        const totalIngresos = 3800 + (factorMes % 1500) + factorAnio;
        const totalGastos = 2200 + (factorMes % 900) + (factorAnio % 400);
        const balance = totalIngresos - totalGastos;
        const cantIng = 2 + (finalMes % 3);
        const cantGas = 10 + (finalMes % 8);

        return of({
          desde: new Date(finalAnio, finalMes - 1, 1).toISOString(),
          hasta: new Date(finalAnio, finalMes, 0).toISOString(),
          totalIngresos,
          totalGastos,
          balance,
          cantidadIngresos: cantIng,
          cantidadGastos: cantGas,
          totalTransacciones: cantIng + cantGas,
          promedioIngreso: Math.round(totalIngresos / cantIng),
          promedioGasto: Math.round(totalGastos / cantGas)
        } as ResumenFinancieroDTO);
      })
    );
  }
 
  // ── Categorías ──
  getCategorias(tipo?: TipoMovimiento): Observable<CategoriaDTO[]> {
    let params = new HttpParams();
    if (tipo) params = params.set('tipo', tipo);
    return this.http.get<ResultadoApi<CategoriaDTO[]>>(this.baseCategorias, { params }).pipe(
      map(resp => resp.datos)
    );
  }

  crearCategoria(request: CategoriaRequestDTO): Observable<CategoriaDTO> {
    return this.http.post<ResultadoApi<CategoriaDTO>>(this.baseCategorias, request).pipe(
      map(resp => resp.datos)
    );
  }
 
  cargarResumen(): void {
    this.cargando.set(true);
    this.getResumen().subscribe({
      next:  r  => { this.resumen.set(r); this.cargando.set(false); },
      error: () => this.cargando.set(false)
    });
  }
 
  cargarCategorias(): void {
    this.getCategorias().subscribe({
      next: cats => this.categorias.set(cats)
    });
  }
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\gastos-state.service.ts

import { Injectable, signal } from '@angular/core';
import { forkJoin, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Transacciones } from './transacciones';
import { FinancieroService } from './Financiero.service';
import { TransaccionDTO } from '../models/financiero/transaccion.model';
import { ResumenFinancieroDTO } from '../models/financiero/resumen.model';
import { CategoriaDTO } from '../models/financiero/categoria.model';

@Injectable({
  providedIn: 'root'
})
export class GastosStateService {
  // ── Angular Signals for State ──
  readonly gastos = signal<TransaccionDTO[]>([]);
  readonly resumenActual = signal<ResumenFinancieroDTO | null>(null);
  readonly resumenAnterior = signal<ResumenFinancieroDTO | null>(null);
  readonly categorias = signal<CategoriaDTO[]>([]);

  // ── Loading state ──
  readonly cargando = signal<boolean>(false);
  readonly error = signal<string | null>(null);

  // Cache timestamps (ms)
  private ultimoRefrescoTransacciones = 0;
  private readonly CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes for transaction/current month summary

  constructor(
    private transaccionesService: Transacciones,
    private financieroService: FinancieroService
  ) {}

  /**
   * Loads all required data for the Gastos section.
   * Leverages caching for static datasets (previous month and categories) and time-based TTL for volatile data.
   */
  cargarDatos(forzar: boolean = false): void {
    const ahora = Date.now();
    const necesitaRefrescoVolatil = forzar || !this.ultimoRefrescoTransacciones || (ahora - this.ultimoRefrescoTransacciones > this.CACHE_TTL_MS);

    const necesitaCategorias = this.categorias().length === 0;
    const necesitaResumenAnterior = this.resumenAnterior() === null;

    if (!necesitaRefrescoVolatil && !necesitaCategorias && !necesitaResumenAnterior) {
      // Everything is already cached
      return;
    }

    this.cargando.set(true);
    this.error.set(null);

    const hoy = new Date();
    const mesActual = hoy.getMonth() + 1;
    const anioActual = hoy.getFullYear();
    const anterior = new Date(anioActual, hoy.getMonth() - 1, 1);
    const mesAnterior = anterior.getMonth() + 1;
    const anioAnterior = anterior.getFullYear();

    // Build calls conditionally
    const llamadas: Record<string, any> = {};

    if (necesitaRefrescoVolatil) {
      llamadas['historial'] = this.transaccionesService.listarHistorial({ tipo: 'GASTO', pagina: 0, tamanio: 50 }).pipe(
        catchError(() => of({ content: [] }))
      );
      llamadas['resumenActual'] = this.financieroService.getResumen(mesActual, anioActual).pipe(
        catchError(() => of(null))
      );
    } else {
      llamadas['historial'] = of(null);
      llamadas['resumenActual'] = of(null);
    }

    if (necesitaResumenAnterior) {
      llamadas['resumenAnterior'] = this.financieroService.getResumen(mesAnterior, anioAnterior).pipe(
        catchError(() => of(null))
      );
    } else {
      llamadas['resumenAnterior'] = of(null);
    }

    if (necesitaCategorias) {
      llamadas['categorias'] = this.financieroService.getCategorias('GASTO').pipe(
        catchError(() => of([]))
      );
    } else {
      llamadas['categorias'] = of(null);
    }

    forkJoin(llamadas).subscribe({
      next: (res: any) => {
        if (res.historial !== null) {
          this.gastos.set(res.historial.content || []);
          this.ultimoRefrescoTransacciones = Date.now();
        }
        if (res.resumenActual !== null) {
          this.resumenActual.set(res.resumenActual);
        }
        if (res.resumenAnterior !== null) {
          this.resumenAnterior.set(res.resumenAnterior);
        }
        if (res.categorias !== null) {
          this.categorias.set(res.categorias || []);
        }
        this.cargando.set(false);
      },
      error: (err) => {
        console.error('[GastosStateService] Error loading page data:', err);
        this.error.set('Error al sincronizar datos financieros.');
        this.cargando.set(false);
      }
    });
  }

  /**
   * Invalidates caches and forces a clean refetch.
   */
  invalidarCache(): void {
    this.ultimoRefrescoTransacciones = 0;
    this.cargarDatos(true);
  }
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\ia.service.ts

import { Injectable, inject, signal, effect } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { environment } from '../../enviroments/environment';
import { ResultadoApi } from '../models/auth/user.model';
import { AuthService } from './auth.service';
import {
  PeticionConFiltroFechaDTO,
  PeticionSimularMetaDTO,
  PeticionComparacionDTO,
  SolicitudClasificacionDTO,
  RespuestaModuloDTO,
  RespuestaClasificacionDTO,
  RespuestaIaDTO,
  SolicitudIaDTO
} from '../models/ia_coach/ia-base.model';

@Injectable({ providedIn: 'root' })
export class IaService {
  private base = `${environment.gatewayUrl}/api/v1/ia`;

  private readonly authService = inject(AuthService);

  readonly consultasRestantes = signal<number>(5);
  readonly consultasMaximas = signal<number>(5);
  readonly clasificacionesRestantes = signal<number>(2);
  readonly clasificacionesMaximas = signal<number>(2);

  constructor(private http: HttpClient) {
    effect(() => {
      const user = this.authService.usuario();
      if (user) {
        this.inicializarCuotasDesdePlan();
      } else {
        this.resetearCuotas();
      }
    });
  }

  private getPlanKey(idUsuario: string): string {
    return `luka_quota_plan_${idUsuario}`;
  }

  inicializarCuotasDesdePlan(): void {
    const user = this.authService.usuario();
    if (!user) return;

    let maxConsultas = 5;
    let maxClasificaciones = 2;

    if (this.authService.esPremium()) {
      maxConsultas = 50;
      maxClasificaciones = 20;
    } else if (this.authService.esPro()) {
      maxConsultas = 20;
      maxClasificaciones = 10;
    }

    this.consultasMaximas.set(maxConsultas);
    this.clasificacionesMaximas.set(maxClasificaciones);

    const planKey = this.getPlanKey(user.id);
    const cachedPlan = localStorage.getItem(planKey);
    const currentPlanName = this.authService.esPremium() ? 'PREMIUM' : (this.authService.esPro() ? 'PRO' : 'FREE');

    if (cachedPlan !== currentPlanName) {
      this.consultasRestantes.set(maxConsultas);
      this.clasificacionesRestantes.set(maxClasificaciones);
      localStorage.setItem(planKey, currentPlanName);
      this.guardarCuotasEnStorage(user.id);
    } else {
      const savedConsultas = localStorage.getItem(`luka_quota_consultas_${user.id}`);
      const savedClasificaciones = localStorage.getItem(`luka_quota_clasificaciones_${user.id}`);

      if (savedConsultas !== null) {
        this.consultasRestantes.set(Math.min(parseInt(savedConsultas, 10), maxConsultas));
      } else {
        this.consultasRestantes.set(maxConsultas);
      }

      if (savedClasificaciones !== null) {
        this.clasificacionesRestantes.set(Math.min(parseInt(savedClasificaciones, 10), maxClasificaciones));
      } else {
        this.clasificacionesRestantes.set(maxClasificaciones);
      }
    }
  }

  descontarConsulta(): void {
    const user = this.authService.usuario();
    if (!user) return;
    const current = this.consultasRestantes();
    if (current > 0) {
      this.consultasRestantes.set(current - 1);
      this.guardarCuotasEnStorage(user.id);
    }
  }

  descontarClasificacion(): void {
    const user = this.authService.usuario();
    if (!user) return;
    const current = this.clasificacionesRestantes();
    if (current > 0) {
      this.clasificacionesRestantes.set(current - 1);
      this.guardarCuotasEnStorage(user.id);
    }
  }

  private guardarCuotasEnStorage(userId: string): void {
    localStorage.setItem(`luka_quota_consultas_${userId}`, this.consultasRestantes().toString());
    localStorage.setItem(`luka_quota_clasificaciones_${userId}`, this.clasificacionesRestantes().toString());
  }

  private resetearCuotas(): void {
    this.consultasRestantes.set(5);
    this.consultasMaximas.set(5);
    this.clasificacionesRestantes.set(2);
    this.clasificacionesMaximas.set(2);
  }

  private enriquecerPayload<T>(payload: T): T & { usuario_id?: string; token?: string } {
    const user = this.authService.usuario();
    if (!user) return payload as any;
    return {
      ...payload,
      usuario_id: user.id,
      token: user.token
    };
  }

  // Compatibilidad con código antiguo si lo hubiera
  consultar(payload: SolicitudIaDTO): Observable<RespuestaIaDTO> {
    const p = this.enriquecerPayload(payload);
    return this.http.post<RespuestaIaDTO>(`${this.base}/consultar`, p).pipe(
      tap(() => this.descontarConsulta())
    );
  }

  // ── Módulo de Análisis ──
  
  getGastoHormiga(payload: PeticionConFiltroFechaDTO): Observable<ResultadoApi<RespuestaModuloDTO>> {
    const p = this.enriquecerPayload(payload);
    return this.http.post<ResultadoApi<RespuestaModuloDTO>>(`${this.base}/gasto-hormiga`, p).pipe(
      tap(() => this.descontarConsulta())
    );
  }

  getPredecirGastos(payload: PeticionConFiltroFechaDTO): Observable<ResultadoApi<RespuestaModuloDTO>> {
    const p = this.enriquecerPayload(payload);
    return this.http.post<ResultadoApi<RespuestaModuloDTO>>(`${this.base}/predecir-gastos`, p).pipe(
      tap(() => this.descontarConsulta())
    );
  }

  getHabitosFinancieros(payload: PeticionConFiltroFechaDTO): Observable<ResultadoApi<RespuestaModuloDTO>> {
    const p = this.enriquecerPayload(payload);
    return this.http.post<ResultadoApi<RespuestaModuloDTO>>(`${this.base}/habitos-financieros`, p).pipe(
      tap(() => this.descontarConsulta())
    );
  }

  getEstiloVida(payload: PeticionConFiltroFechaDTO): Observable<ResultadoApi<RespuestaModuloDTO>> {
    const p = this.enriquecerPayload(payload);
    return this.http.post<ResultadoApi<RespuestaModuloDTO>>(`${this.base}/estilo-vida`, p).pipe(
      tap(() => this.descontarConsulta())
    );
  }

  getReporteCompleto(payload: PeticionConFiltroFechaDTO): Observable<ResultadoApi<RespuestaModuloDTO>> {
    const p = this.enriquecerPayload(payload);
    return this.http.post<ResultadoApi<RespuestaModuloDTO>>(`${this.base}/reporte-completo`, p).pipe(
      tap(() => this.descontarConsulta())
    );
  }

  getComprobadorEvolucion(payload: PeticionComparacionDTO): Observable<ResultadoApi<RespuestaModuloDTO>> {
    const p = this.enriquecerPayload(payload);
    return this.http.post<ResultadoApi<RespuestaModuloDTO>>(`${this.base}/comprobador-evolucion`, p).pipe(
      tap(() => this.descontarConsulta())
    );
  }

  getZonaEntrenamiento(payload: PeticionConFiltroFechaDTO): Observable<ResultadoApi<RespuestaModuloDTO>> {
    const p = this.enriquecerPayload(payload);
    return this.http.post<ResultadoApi<RespuestaModuloDTO>>(`${this.base}/zona-entrenamiento`, p).pipe(
      tap(() => this.descontarConsulta())
    );
  }

  // ── Módulo de Coach ──

  getSimularMeta(payload: PeticionSimularMetaDTO): Observable<ResultadoApi<RespuestaModuloDTO>> {
    const p = this.enriquecerPayload(payload);
    return this.http.post<ResultadoApi<RespuestaModuloDTO>>(`${this.base}/simular-meta`, p).pipe(
      tap(() => this.descontarConsulta())
    );
  }

  getRetoAhorro(payload: PeticionConFiltroFechaDTO): Observable<ResultadoApi<RespuestaModuloDTO>> {
    const p = this.enriquecerPayload(payload);
    return this.http.post<ResultadoApi<RespuestaModuloDTO>>(`${this.base}/reto-ahorro`, p).pipe(
      tap(() => this.descontarConsulta())
    );
  }

  getEspejoTemporal(payload: PeticionConFiltroFechaDTO): Observable<ResultadoApi<RespuestaModuloDTO>> {
    const p = this.enriquecerPayload(payload);
    return this.http.post<ResultadoApi<RespuestaModuloDTO>>(`${this.base}/espejo-tiempo`, p).pipe(
      tap(() => this.descontarConsulta())
    );
  }

  // ── Módulo de Clasificación ──

  getClasificarTransaccion(payload: SolicitudClasificacionDTO): Observable<ResultadoApi<RespuestaClasificacionDTO>> {
    const p = this.enriquecerPayload(payload);
    return this.http.post<ResultadoApi<RespuestaClasificacionDTO>>(`${this.base}/clasificar-transaccion`, p).pipe(
      tap(() => this.descontarClasificacion())
    );
  }
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\index.ts

export * from './auditoria.service';
export * from './avatar.service';
export * from './auth.service';
export * from './ayuda.service';
export * from './categorias';
export * from './cliente-metas-limites.service';
export * from './cliente-perfil.service';
export * from './Financiero.service';
export * from './ia.service';
export * from './Jwt.interceptor';
export * from './otp.service';
export * from './presupuesto.service';
export * from './sidebar-state.service';
export * from './transacciones';
export * from './notificacion.service';


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\ingresos-state.service.ts

import { Injectable, signal } from '@angular/core';
import { forkJoin, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Transacciones } from './transacciones';
import { FinancieroService } from './Financiero.service';
import { TransaccionDTO } from '../models/financiero/transaccion.model';
import { ResumenFinancieroDTO } from '../models/financiero/resumen.model';
import { CategoriaDTO } from '../models/financiero/categoria.model';

export interface IngresosFiltrosVista {
  mes?: number;
  anio?: number;
  categoriaId?: string;
}

@Injectable({
  providedIn: 'root'
})
export class IngresosStateService {
  // â”€â”€ Angular Signals for State â”€â”€
  readonly ingresos = signal<TransaccionDTO[]>([]);
  readonly resumenActual = signal<ResumenFinancieroDTO | null>(null);
  readonly resumenAnterior = signal<ResumenFinancieroDTO | null>(null);
  readonly categorias = signal<CategoriaDTO[]>([]);

  // â”€â”€ Loading state â”€â”€
  readonly cargando = signal<boolean>(false);
  readonly error = signal<string | null>(null);

  // Cache timestamps (ms)
  private ultimoRefrescoTransacciones = 0;
  private readonly CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes for transaction/current month summary

  constructor(
    private transaccionesService: Transacciones,
    private financieroService: FinancieroService
  ) {}

  /**
   * Loads all required data for the Ingresos section.
   * Leverages caching for static datasets (previous month and categories) and time-based TTL for volatile data.
   */
  cargarDatos(forzar: boolean = false, filtros: IngresosFiltrosVista = {}): void {
    const ahora = Date.now();
    const hayFiltrosVista = filtros.mes != null || filtros.anio != null || !!filtros.categoriaId;
    const necesitaRefrescoVolatil = hayFiltrosVista || forzar || !this.ultimoRefrescoTransacciones || (ahora - this.ultimoRefrescoTransacciones > this.CACHE_TTL_MS);

    const necesitaCategorias = this.categorias().length === 0;
    const necesitaResumenAnterior = this.resumenAnterior() === null;

    if (!necesitaRefrescoVolatil && !necesitaCategorias && !necesitaResumenAnterior) {
      // Everything is already cached
      return;
    }

    this.cargando.set(true);
    this.error.set(null);

    const hoy = new Date();
    const mesActual = filtros.mes ?? hoy.getMonth() + 1;
    const anioActual = filtros.anio ?? hoy.getFullYear();
    const anterior = new Date(anioActual, hoy.getMonth() - 1, 1);
    const mesAnterior = anterior.getMonth() + 1;
    const anioAnterior = anterior.getFullYear();

    // Build calls conditionally
    const llamadas: Record<string, any> = {};

    if (necesitaRefrescoVolatil) {
      llamadas['historial'] = this.transaccionesService.listarHistorial({
        tipo: 'INGRESO',
        categoriaId: filtros.categoriaId,
        mes: mesActual,
        anio: anioActual,
        pagina: 0,
        tamanio: 50
      }).pipe(
        catchError(() => of({ content: [] }))
      );
      llamadas['resumenActual'] = this.financieroService.getResumen(mesActual, anioActual).pipe(
        catchError(() => of(null))
      );
    } else {
      llamadas['historial'] = of(null);
      llamadas['resumenActual'] = of(null);
    }

    if (necesitaResumenAnterior) {
      llamadas['resumenAnterior'] = this.financieroService.getResumen(mesAnterior, anioAnterior).pipe(
        catchError(() => of(null))
      );
    } else {
      llamadas['resumenAnterior'] = of(null);
    }

    if (necesitaCategorias) {
      llamadas['categorias'] = this.financieroService.getCategorias('INGRESO').pipe(
        catchError(() => of([]))
      );
    } else {
      llamadas['categorias'] = of(null);
    }

    forkJoin(llamadas).subscribe({
      next: (res: any) => {
        if (res.historial !== null) {
          this.ingresos.set(res.historial.content || []);
          if (!hayFiltrosVista) {
            this.ultimoRefrescoTransacciones = Date.now();
          }
        }
        if (res.resumenActual !== null) {
          this.resumenActual.set(res.resumenActual);
        }
        if (res.resumenAnterior !== null) {
          this.resumenAnterior.set(res.resumenAnterior);
        }
        if (res.categorias !== null) {
          this.categorias.set(res.categorias || []);
        }
        this.cargando.set(false);
      },
      error: (err) => {
        console.error('[IngresosStateService] Error loading page data:', err);
        this.error.set('Error al sincronizar datos financieros.');
        this.cargando.set(false);
      }
    });
  }

  /**
   * Invalidates caches and forces a clean refetch.
   */
  invalidarCache(): void {
    this.ultimoRefrescoTransacciones = 0;
    this.cargarDatos(true);
  }
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\Jwt.interceptor.ts

import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthService } from './auth.service';
import { catchError, filter, switchMap, take } from 'rxjs/operators';
import { throwError, BehaviorSubject, Observable } from 'rxjs';

let isRefreshing = false;
let refreshTokenSubject = new BehaviorSubject<string | null>(null);

export const jwtInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const token = auth.getToken();

  let authReq = req;
  if (token) {
    authReq = req.clone({
      setHeaders: { Authorization: `Bearer ${token}` }
    });
  }

  return next(authReq).pipe(
    catchError((error: HttpErrorResponse) => {
      if (error.status === 401 && !req.url.includes('/auth/login') && !req.url.includes('/auth/refrescar-token')) {
        return handle401Error(authReq, next, auth);
      }
      return throwError(() => error);
    })
  );
};

const handle401Error = (req: any, next: any, auth: AuthService): Observable<any> => {
  if (!isRefreshing) {
    isRefreshing = true;
    refreshTokenSubject.next(null);

    const refreshToken = auth.getRefreshToken();

    if (refreshToken) {
      return auth.refrescarToken(refreshToken).pipe(
        switchMap((respuesta) => {
          isRefreshing = false;
          if (respuesta && respuesta.exito) {
            const newToken = respuesta.datos.tokenAcceso;
            refreshTokenSubject.next(newToken);
            return next(req.clone({
              setHeaders: { Authorization: `Bearer ${newToken}` }
            }));
          }
          auth.logout();
          return throwError(() => new Error('No se pudo refrescar la sesión'));
        }),
        catchError((err) => {
          isRefreshing = false;
          auth.logout();
          return throwError(() => err);
        })
      );
    } else {
      isRefreshing = false;
      auth.logout();
      return throwError(() => new Error('No hay token de refresco disponible'));
    }
  } else {
    return refreshTokenSubject.pipe(
      filter(token => token !== null),
      take(1),
      switchMap(jwt => {
        return next(req.clone({
          setHeaders: { Authorization: `Bearer ${jwt}` }
        }));
      })
    );
  }
};


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\notificacion.service.ts

import { Injectable, signal } from '@angular/core';

export interface NotificacionInfo {
  titulo: string;
  mensaje: string;
  tipo: 'gasto' | 'ingreso' | 'login' | 'meta' | 'presupuesto' | 'guardado';
  icono: string;
  duracion: number;
}

@Injectable({
  providedIn: 'root'
})
export class NotificacionService {
  readonly activa = signal<NotificacionInfo | null>(null);
  private timeoutId: any = null;

  mostrar(
    titulo: string,
    mensaje: string,
    tipo: NotificacionInfo['tipo'],
    icono: string,
    duracionMs: number = 3000
  ): void {
    // Cancelar el timeout anterior si existiera uno activo
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
    }

    this.activa.set({
      titulo,
      mensaje,
      tipo,
      icono,
      duracion: duracionMs
    });

    this.timeoutId = setTimeout(() => {
      this.cerrar();
    }, duracionMs);
  }

  cerrar(): void {
    this.activa.set(null);
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
      this.timeoutId = null;
    }
  }

  // --- MÉTODOS MODULARES / WRAPPERS DE ACCESO RÁPIDO ---

  mostrarGastoRegistrado(monto: number, categoria: string): void {
    this.mostrar(
      'Gasto Registrado',
      `Se registró un egreso de S/ ${monto.toFixed(2)} en la categoría ${categoria}.`,
      'gasto',
      'arrow-down-long',
      3500
    );
  }

  mostrarIngresoRegistrado(monto: number, categoria: string): void {
    this.mostrar(
      'Ingreso Registrado',
      `Se registró un ingreso de S/ ${monto.toFixed(2)} en la categoría ${categoria}.`,
      'ingreso',
      'arrow-up-long',
      3500
    );
  }

  mostrarLoginExitoso(usuario: string): void {
    this.mostrar(
      '¡Bienvenido de nuevo!',
      `Hola ${usuario}, has iniciado sesión correctamente en Luka.`,
      'login',
      'user-check',
      3500
    );
  }

  mostrarMetaCreada(nombre: string): void {
    this.mostrar(
      'Meta de Ahorro Creada',
      `¡Genial! Has establecido una nueva meta de ahorro: "${nombre}".`,
      'meta',
      'bullseye',
      4000
    );
  }

  mostrarPresupuestoCreado(nombre: string): void {
    this.mostrar(
      'Presupuesto Configurado',
      `El límite de presupuesto para "${nombre}" ha sido actualizado.`,
      'presupuesto',
      'scale-balanced',
      4000
    );
  }

  mostrarDatosGuardados(detalle: string = 'Tus cambios han sido guardados con éxito.'): void {
    this.mostrar(
      'Datos Actualizados',
      detalle,
      'guardado',
      'floppy-disk',
      3000
    );
  }
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\otp.service.ts

import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../enviroments/environment';
import {
  RespuestaGeneracion,
  RespuestaValidacion,
  SolicitudGenerarCodigo,
  SolicitudValidarCodigo
} from '../models/mensajeria/otp.model';

@Injectable({ providedIn: 'root' })
export class OtpService {
  private base = `${environment.gatewayUrl}/api/v1/mensajeria/otp`;

  constructor(private http: HttpClient) {}

  generarCodigo(payload: SolicitudGenerarCodigo): Observable<RespuestaGeneracion> {
    return this.http.post<RespuestaGeneracion>(`${this.base}/generar`, payload);
  }

  validarActivacion(payload: SolicitudValidarCodigo): Observable<RespuestaValidacion> {
    return this.http.post<RespuestaValidacion>(`${this.base}/validar-activacion`, payload);
  }

  validarRecuperacion(usuarioId: string, codigo: string): Observable<string> {
    const params = new HttpParams().set('usuarioId', usuarioId).set('codigo', codigo);
    return this.http.get(`${this.base}/validar-recuperacion`, { params, responseType: 'text' });
  }

  validarLimite(payload: SolicitudGenerarCodigo): Observable<void> {
    return this.http.post<void>(`${this.base}/validar-limite`, payload);
  }
}



## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\presupuesto.service.ts

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../enviroments/environment';
import { PresupuestoDTO, SolicitudPresupuesto } from '../models/financiero/presupuesto.model';
import { ResultadoApi } from '../models/auth/user.model';

@Injectable({ providedIn: 'root' })
export class PresupuestoService {
  private base = `${environment.gatewayUrl}/api/v1/clientes/limites`;

  constructor(private http: HttpClient) {}

  crear(payload: SolicitudPresupuesto): Observable<PresupuestoDTO> {
    return this.http.post<ResultadoApi<PresupuestoDTO>>(this.base, payload).pipe(
      map(res => res.datos)
    );
  }

  obtenerActivo(): Observable<PresupuestoDTO> {
    return this.http.get<ResultadoApi<PresupuestoDTO>>(`${this.base}/activo`).pipe(
      map(res => res.datos)
    );
  }

  actualizar(payload: SolicitudPresupuesto): Observable<PresupuestoDTO> {
    return this.http.patch<ResultadoApi<PresupuestoDTO>>(this.base, payload).pipe(
      map(res => res.datos)
    );
  }

  listarHistorial(): Observable<PresupuestoDTO[]> {
    return this.http.get<ResultadoApi<PresupuestoDTO[]>>(this.base).pipe(
      map(res => res.datos),
      catchError(() => of([]))
    );
  }

  eliminarActivo(): Observable<void> {
    return this.http.delete<ResultadoApi<void>>(this.base).pipe(
      map(() => undefined)
    );
  }
}



## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\servicio-tema.ts

import { Injectable, signal, effect } from '@angular/core';

/**
 * Servicio global para gestionar el tema visual (oscuro/claro) de toda la app.
 * Persiste la preferencia del usuario en localStorage.
 */
@Injectable({ providedIn: 'root' })
export class ServicioTema {
  private readonly STORAGE_KEY = 'luka-theme';
  /** Signal reactivo: true = tema oscuro, false = tema claro */
  temaOscuro = signal(false);

  constructor() {
    // Leer preferencia guardada
    const guardado = localStorage.getItem(this.STORAGE_KEY);
    // Migración de clave legacy
    const legacy = localStorage.getItem('luka-tema');
    if (!guardado && legacy) {
      localStorage.setItem(this.STORAGE_KEY, legacy);
      localStorage.removeItem('luka-tema');
    }

    const temaGuardado = localStorage.getItem(this.STORAGE_KEY);
    console.debug('[TemaDebug][ServicioTema] localStorage luka-theme =', temaGuardado);
    if (temaGuardado) {
      this.temaOscuro.set(temaGuardado === 'oscuro');
    }

    // Efecto reactivo: sincronizar clase CSS del body
    effect(() => {
      const esOscuro = this.temaOscuro();
      document.body.classList.toggle('theme-dark', esOscuro);
      document.body.classList.toggle('dark', esOscuro);
      document.body.classList.toggle('tema-claro', !esOscuro);
      localStorage.setItem(this.STORAGE_KEY, esOscuro ? 'oscuro' : 'claro');
      console.debug('[TemaDebug][ServicioTema] apply =>', {
        esOscuro,
        bodyThemeDark: document.body.classList.contains('theme-dark'),
        bodyDark: document.body.classList.contains('dark'),
        bodyTemaClaro: document.body.classList.contains('tema-claro'),
        persisted: localStorage.getItem(this.STORAGE_KEY)
      });
    });
  }

  /** Alternar entre tema oscuro y claro */
  alternar(): void {
    this.temaOscuro.update(v => !v);
  }

  setTema(tema: 'oscuro' | 'claro'): void {
    this.temaOscuro.set(tema === 'oscuro');
  }
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\sidebar-state.service.ts

// =============================================
// LUKA - Sidebar State Service
// Maneja el estado collapsed/expanded del sidebar.
// Lo leen tanto Sidebar como Layout para sincronizarse.
// =============================================

import { Injectable, signal, computed } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class SidebarStateService {

  private readonly STORAGE_KEY = 'luka_sidebar_collapsed';

  // ── Estado interno ──
  private _collapsed = signal<boolean>(this.loadFromStorage());
  private _mobileOpen = signal<boolean>(false);

  // ── Público (solo lectura) ──
  collapsed  = this._collapsed.asReadonly();
  expanded   = computed(() => !this._collapsed());
  mobileOpen = this._mobileOpen.asReadonly();

  // ── Acciones ──
  toggle(): void {
    this._collapsed.update(v => !v);
    localStorage.setItem(this.STORAGE_KEY, String(this._collapsed()));
  }

  collapse(): void {
    this._collapsed.set(true);
    localStorage.setItem(this.STORAGE_KEY, 'true');
  }

  expand(): void {
    this._collapsed.set(false);
    localStorage.setItem(this.STORAGE_KEY, 'false');
  }

  toggleMobile(): void {
    this._mobileOpen.update(v => !v);
  }

  openMobile(): void {
    this._mobileOpen.set(true);
  }

  closeMobile(): void {
    this._mobileOpen.set(false);
  }

  // ── Privado ──
  private loadFromStorage(): boolean {
    return localStorage.getItem(this.STORAGE_KEY) === 'true';
  }
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\suscripcion-gastos.service.ts

import { Injectable, signal, computed, effect } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { 
  SuscripcionDTO, 
  SuscripcionGasto, 
  CrearSuscripcionRequest,
  ActualizarSuscripcionRequest,
  ResumenSuscripciones,
  FrecuenciaSuscripcion 
} from '../models/financiero/suscripcion-gasto.model';

/**
 * ServicioSuscripcionGastos
 * Gestiona las suscripciones recurrentes (Netflix, Spotify, Gimnasio, etc.)
 * Utiliza datos MOCK para desarrollo y pruebas
 */
@Injectable({ providedIn: 'root' })
export class SuscripcionGastosService {
  // Estado local con signals
  private suscripciones = signal<SuscripcionDTO[]>([]);
  private cargando = signal(false);
  private error = signal<string | null>(null);

  // Computed signals
  readonly suscripcionesActivas = computed(() =>
    this.suscripciones().filter(s => s.estado === 'ACTIVA')
  );

  readonly suscripcionesPausadas = computed(() =>
    this.suscripciones().filter(s => s.estado === 'PAUSADA')
  );

  readonly suscripcionesProximas = computed(() => {
    const hoy = new Date();
    const proximas30 = new Date(hoy.getTime() + 30 * 24 * 60 * 60 * 1000);
    
    return this.suscripciones()
      .filter(s => {
        const vencimiento = new Date(s.proximoVencimiento);
        return vencimiento >= hoy && vencimiento <= proximas30 && s.estado === 'ACTIVA';
      })
      .sort((a, b) => new Date(a.proximoVencimiento).getTime() - new Date(b.proximoVencimiento).getTime());
  });

  readonly proximoPago = computed(() => this.suscripcionesProximas()[0] || null);

  readonly gastoMensualEstimado = computed(() => {
    return this.suscripcionesActivas().reduce((total, suscripcion) => {
      const gastosAlMes = this.calcularGastosAlMes(suscripcion.monto, suscripcion.frecuencia);
      return total + gastosAlMes;
    }, 0);
  });

  readonly resumenSuscripciones = computed<ResumenSuscripciones>(() => ({
    totalActivas: this.suscripcionesActivas().length,
    gastoMensualEstimado: this.gastoMensualEstimado(),
    proximoPago: this.proximoPago(),
    cantidadTotal: this.suscripciones().length,
    proximasFechas: this.suscripcionesProximas()
  }));

  constructor(private http: HttpClient) {
    // Cargar datos al inicializar
    this.cargarSuscripcionesMock();
  }

  /**
   * Cargar todas las suscripciones
   */
  cargarSuscripciones(): Observable<SuscripcionDTO[]> {
    this.cargando.set(true);
    this.error.set(null);
    
    return of(this.suscripciones()).pipe(
      map(data => {
        this.cargando.set(false);
        return data;
      })
    );
  }

  /**
   * Obtener suscripción por ID
   */
  obtenerSuscripcion(id: string): Observable<SuscripcionDTO | undefined> {
    return of(this.suscripciones().find(s => s.id === id));
  }

  /**
   * Crear nueva suscripción
   */
  crearSuscripcion(request: CrearSuscripcionRequest): Observable<SuscripcionDTO> {
    const ahora = new Date().toISOString();
    const proximoVencimiento = this.calcularProximoVencimiento(request.fechaInicio, request.frecuencia);
    
    const nuevaSuscripcion: SuscripcionDTO = {
      id: this.generarId(),
      ...request,
      proximoVencimiento,
      estado: 'ACTIVA',
      fechaCreacion: ahora,
      ultimaActualizacion: ahora,
      diasParaVencimiento: this.calcularDiasAlVencimiento(proximoVencimiento),
      vencePronto: this.calcularDiasAlVencimiento(proximoVencimiento) <= 5
    };

    this.suscripciones.update(sus => [...sus, nuevaSuscripcion]);
    return of(nuevaSuscripcion);
  }

  /**
   * Actualizar suscripción existente
   */
  actualizarSuscripcion(request: ActualizarSuscripcionRequest): Observable<SuscripcionDTO> {
    const ahora = new Date().toISOString();
    
    this.suscripciones.update(sus =>
      sus.map(s => {
        if (s.id === request.id) {
          const proximoVencimiento = this.calcularProximoVencimiento(
            request.fechaInicio,
            request.frecuencia
          );
          return {
            ...s,
            nombre: request.nombre,
            descripcion: request.descripcion,
            categoria: request.categoria,
            monto: request.monto,
            frecuencia: request.frecuencia,
            fechaInicio: request.fechaInicio,
            proximoVencimiento,
            estado: request.estado || s.estado,
            ultimaActualizacion: ahora,
            diasParaVencimiento: this.calcularDiasAlVencimiento(proximoVencimiento),
            vencePronto: this.calcularDiasAlVencimiento(proximoVencimiento) <= 5
          };
        }
        return s;
      })
    );

    const actualizada = this.suscripciones().find(s => s.id === request.id)!;
    return of(actualizada);
  }

  /**
   * Eliminar suscripción
   */
  eliminarSuscripcion(id: string): Observable<boolean> {
    this.suscripciones.update(sus => sus.filter(s => s.id !== id));
    return of(true);
  }

  /**
   * Cambiar estado de suscripción
   */
  cambiarEstado(id: string, estado: 'ACTIVA' | 'PAUSADA' | 'VENCIDA'): Observable<SuscripcionDTO> {
    const ahora = new Date().toISOString();
    
    this.suscripciones.update(sus =>
      sus.map(s => s.id === id ? { ...s, estado, ultimaActualizacion: ahora } : s)
    );

    const actualizada = this.suscripciones().find(s => s.id === id)!;
    return of(actualizada);
  }

  /**
   * Filtrar suscripciones
   */
  filtrarSuscripciones(filtros: {
    busqueda?: string;
    categoria?: string;
    frecuencia?: FrecuenciaSuscripcion;
    estado?: string;
    montoMin?: number;
    montoMax?: number;
  }): SuscripcionDTO[] {
    let resultado = this.suscripciones();

    if (filtros.busqueda) {
      const busqueda = filtros.busqueda.toLowerCase();
      resultado = resultado.filter(s =>
        s.nombre.toLowerCase().includes(busqueda) ||
        s.descripcion.toLowerCase().includes(busqueda)
      );
    }

    if (filtros.categoria) {
      resultado = resultado.filter(s => s.categoria === filtros.categoria);
    }

    if (filtros.frecuencia) {
      resultado = resultado.filter(s => s.frecuencia === filtros.frecuencia);
    }

    if (filtros.estado) {
      resultado = resultado.filter(s => s.estado === filtros.estado);
    }

    if (filtros.montoMin !== undefined) {
      resultado = resultado.filter(s => s.monto >= filtros.montoMin!);
    }

    if (filtros.montoMax !== undefined) {
      resultado = resultado.filter(s => s.monto <= filtros.montoMax!);
    }

    return resultado;
  }

  /**
   * ── MÉTODOS PRIVADOS ──
   */
private cargarSuscripcionesMock(): void {
    const mockData: SuscripcionDTO[] = [
      {
        id: '1',
        nombre: 'Netflix',
        descripcion: 'Servicio de streaming de películas y series',
        categoria: 'leisure',
        monto: 99,
        frecuencia: 'MENSUAL',
        fechaInicio: '2026-06-15',
        proximoVencimiento: '2026-07-15',
        estado: 'ACTIVA',
        fechaCreacion: '2026-01-15T00:00:00Z',
        ultimaActualizacion: '2026-01-15T00:00:00Z',
        diasParaVencimiento: this.calcularDiasAlVencimiento('2026-07-15'),
        vencePronto: this.calcularDiasAlVencimiento('2026-07-15') <= 5
      },
      {
        id: '2',
        nombre: 'Spotify',
        descripcion: 'Servicio de streaming de música',
        categoria: 'leisure',
        monto: 119,
        frecuencia: 'MENSUAL',
        fechaInicio: '2026-06-20',
        proximoVencimiento: '2026-07-20',
        estado: 'ACTIVA',
        fechaCreacion: '2026-02-20T00:00:00Z',
        ultimaActualizacion: '2026-02-20T00:00:00Z',
        diasParaVencimiento: this.calcularDiasAlVencimiento('2026-07-20'),
        vencePronto: this.calcularDiasAlVencimiento('2026-07-20') <= 5
      },
      {
        id: '3',
        nombre: 'Internet Fibra Óptica',
        descripcion: 'Servicio de internet residencial',
        categoria: 'home',
        monto: 149,
        frecuencia: 'MENSUAL',
        fechaInicio: '2026-06-01',
        proximoVencimiento: '2026-07-01',
        estado: 'ACTIVA',
        fechaCreacion: '2025-12-01T00:00:00Z',
        ultimaActualizacion: '2025-12-01T00:00:00Z',
        diasParaVencimiento: this.calcularDiasAlVencimiento('2026-07-01'),
        vencePronto: this.calcularDiasAlVencimiento('2026-07-01') <= 5
      },
      {
        id: '4',
        nombre: 'Gimnasio PowerFit',
        descripcion: 'Membresía mensual al gimnasio',
        categoria: 'health',
        monto: 89,
        frecuencia: 'MENSUAL',
        fechaInicio: '2026-06-10',
        proximoVencimiento: '2026-07-10',
        estado: 'ACTIVA',
        fechaCreacion: '2026-03-10T00:00:00Z',
        ultimaActualizacion: '2026-03-10T00:00:00Z',
        diasParaVencimiento: this.calcularDiasAlVencimiento('2026-07-10'),
        vencePronto: this.calcularDiasAlVencimiento('2026-07-10') <= 5
      },
      {
        id: '5',
        nombre: 'Seguro de Auto',
        descripcion: 'Póliza anual de seguros',
        categoria: 'transport',
        monto: 599,
        frecuencia: 'ANUAL',
        fechaInicio: '2026-06-15',
        proximoVencimiento: '2027-06-15',
        estado: 'ACTIVA',
        fechaCreacion: '2025-06-15T00:00:00Z',
        ultimaActualizacion: '2025-06-15T00:00:00Z',
        diasParaVencimiento: this.calcularDiasAlVencimiento('2027-06-15'),
        vencePronto: this.calcularDiasAlVencimiento('2027-06-15') <= 5
      },
      {
        id: '6',
        nombre: 'Software Adobe',
        descripcion: 'Suscripción Creative Cloud',
        categoria: 'study',
        monto: 299,
        frecuencia: 'MENSUAL',
        fechaInicio: '2026-06-01',
        proximoVencimiento: '2026-07-01',
        estado: 'PAUSADA',
        fechaCreacion: '2026-04-01T00:00:00Z',
        ultimaActualizacion: '2026-05-10T00:00:00Z',
        diasParaVencimiento: this.calcularDiasAlVencimiento('2026-07-01'),
        vencePronto: false
      }
    ];

    this.suscripciones.set(mockData);
  }

  private calcularDiasAlVencimiento(fechaVencimiento: string): number {
    const hoy = new Date();
    const vencimiento = new Date(fechaVencimiento);
    const diferenciaTiempo = vencimiento.getTime() - hoy.getTime();
    return Math.ceil(diferenciaTiempo / (1000 * 60 * 60 * 24));
  }

  private calcularProximoVencimiento(fechaInicio: string, frecuencia: FrecuenciaSuscripcion): string {
    const fecha = new Date(fechaInicio);
    
    switch (frecuencia) {
      case 'DIARIO':
        fecha.setDate(fecha.getDate() + 1);
        break;
      case 'SEMANAL':
        fecha.setDate(fecha.getDate() + 7);
        break;
      case 'QUINCENAL':
        fecha.setDate(fecha.getDate() + 15);
        break;
      case 'MENSUAL':
        fecha.setMonth(fecha.getMonth() + 1);
        break;
      case 'TRIMESTRAL':
        fecha.setMonth(fecha.getMonth() + 3);
        break;
      case 'SEMESTRAL':
        fecha.setMonth(fecha.getMonth() + 6);
        break;
      case 'ANUAL':
        fecha.setFullYear(fecha.getFullYear() + 1);
        break;
    }
    
    return fecha.toISOString().split('T')[0];
  }

  private calcularGastosAlMes(monto: number, frecuencia: FrecuenciaSuscripcion): number {
    switch (frecuencia) {
      case 'DIARIO':
        return monto * 30;
      case 'SEMANAL':
        return (monto / 7) * 30;
      case 'QUINCENAL':
        return (monto / 15) * 30;
      case 'MENSUAL':
        return monto;
      case 'TRIMESTRAL':
        return monto / 3;
      case 'SEMESTRAL':
        return monto / 6;
      case 'ANUAL':
        return monto / 12;
      default:
        return 0;
    }
  }

  private generarId(): string {
    return 'sus_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\suscripcion.service.ts

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../enviroments/environment';
import { ResultadoApi } from '../models/auth/user.model';

export interface RespuestaCheckoutDTO {
  pagoId: string;
  urlCheckout: string;
  plan: string;
  monto: number;
  moneda: string;
}

export interface RespuestaSuscripcionDTO {
  plan: string;
  estado: string;
  monto: number;
  moneda: string;
  fechaVencimiento: string | null;
  activo: boolean;
}

@Injectable({ providedIn: 'root' })
export class SuscripcionService {
  private base = `${environment.gatewayUrl}/api/v1/pagos`;

  constructor(private http: HttpClient) {}

  crearSesionCheckout(plan: 'PRO' | 'PREMIUM'): Observable<RespuestaCheckoutDTO> {
    return this.http.post<ResultadoApi<RespuestaCheckoutDTO>>(`${this.base}/checkout`, { plan }).pipe(
      map(res => res.datos)
    );
  }

  obtenerMiSuscripcion(): Observable<RespuestaSuscripcionDTO> {
    return this.http.get<ResultadoApi<RespuestaSuscripcionDTO>>(`${this.base}/mi-suscripcion`).pipe(
      map(res => res.datos)
    );
  }
}


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\transacciones.spec.ts

import { TestBed } from '@angular/core/testing';

import { Transacciones } from './transacciones';

describe('Transacciones', () => {
  let service: Transacciones;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Transacciones);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});


## D:\CURSOS\7MO\INTEGRADOR\plataforma-de-microservicios-financieros\estructura-frontend\frontend\src\app\core\services\transacciones.ts

import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../enviroments/environment';
import { AuthService } from './auth.service';
import {
  TransaccionDTO,
  TransaccionRequestDTO,
  TransaccionFiltros,
} from '../models/financiero/transaccion.model';
import { PaginaDTO } from '../models/shared/pagina.model';
import { ResultadoApi } from '../models/auth/user.model';

@Injectable({ providedIn: 'root' })
export class Transacciones {

  private base = `${environment.gatewayUrl}/api/v1/financiero/transacciones`;

  constructor(private http: HttpClient, private auth: AuthService) {}

  /* Registrar una transacción (ingreso o gasto) */
  registrar(request: TransaccionRequestDTO): Observable<TransaccionDTO> {
    return this.http.post<ResultadoApi<TransaccionDTO>>(this.base, request).pipe(
      map(res => res.datos)
    );
  }

  /* Registrar varias transacciones a la vez */
  registrarLote(requests: TransaccionRequestDTO[]): Observable<TransaccionDTO[]> {
    return this.http.post<ResultadoApi<TransaccionDTO[]>>(`${this.base}/lote`, requests).pipe(
      map(res => res.datos)
    );
  }

  /**
   * Historial paginado con filtros opcionales.
   * — Módulo Gastos:
   *     listarHistorial({ tipo: 'GASTO' })
   * — Módulo Ingresos:
   *     listarHistorial({ tipo: 'INGRESO' })
   * — Dashboard (todos del mes):
   *     listarHistorial({ mes: 5, anio: 2025 })
   */
  listarHistorial(filtros: Partial<TransaccionFiltros> = {}): Observable<PaginaDTO<TransaccionDTO>> {
    const usuarioId = filtros.usuarioId ?? this.auth.usuario()?.id ?? '';
    let params = new HttpParams().set('usuarioId', usuarioId);

    if (filtros.tipo)         params = params.set('tipo',        filtros.tipo);
    if (filtros.categoriaId)  params = params.set('categoriaId', filtros.categoriaId);
    if (filtros.mes  != null) params = params.set('mes',         filtros.mes);
    if (filtros.anio != null) params = params.set('anio',        filtros.anio);
    params = params
      .set('pagina',  filtros.pagina  ?? 0)
      .set('tamanio', filtros.tamanio ?? 20);

    return this.http.get<ResultadoApi<TransaccionDTO[]>>(`${this.base}/historial`, { params }).pipe(
      map(resp => {
        const content = resp.datos || [];
        const pag = resp.pagina;
        return {
          content: content,
          totalElements: pag ? pag.totalElementos : content.length,
          totalPages: pag ? pag.totalPaginas : 1,
          number: pag ? pag.numeroPagina : 0,
          size: pag ? pag.tamañoPagina : content.length
        } as PaginaDTO<TransaccionDTO>;
      })
    );
  }

  /* Detalle de una transacción por ID */
  obtenerPorId(id: string): Observable<TransaccionDTO> {
    return this.http.get<ResultadoApi<TransaccionDTO>>(`${this.base}/${id}`).pipe(
      map(res => res.datos)
    );
  }

  /* Actualizar transacción */
  actualizar(id: string, request: TransaccionRequestDTO): Observable<TransaccionDTO> {
    return this.http.put<ResultadoApi<TransaccionDTO>>(`${this.base}/${id}`, request).pipe(
      map(res => res.datos)
    );
  }

  /* Eliminar transacción */
  eliminar(id: string): Observable<void> {
    return this.http.delete<ResultadoApi<void>>(`${this.base}/${id}`).pipe(
      map(() => undefined)
    );
  }
}
